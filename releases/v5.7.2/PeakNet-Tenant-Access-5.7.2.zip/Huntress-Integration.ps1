[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)][string]$SharedDataRoot,
    [Parameter(Mandatory=$false)][string]$CatalogRoot,
    [switch]$Worker,
    [string]$ResultPath,
    [string]$ProgressPath,
    [switch]$SelfTest
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:ApiBase = 'https://api.huntress.io/v1'
$script:LocalRoot = Join-Path $env:LOCALAPPDATA 'PeakNet\TenantAccess\Huntress'
$script:CredentialPath = Join-Path $script:LocalRoot 'credentials.dpapi'
$script:HuntressRoot = if ([string]::IsNullOrWhiteSpace($SharedDataRoot)) { Join-Path $script:LocalRoot 'SharedData' } else { Join-Path $SharedDataRoot 'Huntress' }
$script:SettingsPath = Join-Path $script:HuntressRoot 'huntress-settings.json'
$script:CachePath = Join-Path $script:HuntressRoot 'huntress-cache.json'
$script:ExportRoot = Join-Path $script:HuntressRoot 'Exports'
$script:SnapshotRoot = Join-Path $script:HuntressRoot 'BillingSnapshots'
New-Item -ItemType Directory -Force -Path $script:LocalRoot,$script:HuntressRoot,$script:ExportRoot,$script:SnapshotRoot | Out-Null

function Write-JsonAtomic([string]$Path,$Value,[int]$Depth=20) {
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory)) { New-Item -ItemType Directory -Force -Path $directory | Out-Null }
    $temporary = Join-Path $directory ('.{0}.{1}.tmp' -f ([IO.Path]::GetFileName($Path)),[guid]::NewGuid().ToString('N'))
    [IO.File]::WriteAllText($temporary,($Value | ConvertTo-Json -Depth $Depth),[Text.UTF8Encoding]::new($false))
    Move-Item -LiteralPath $temporary -Destination $Path -Force
}

function Get-DefaultSettings {
    [pscustomobject][ordered]@{
        version = 1
        currency = 'DKK'
        dsPrefix = 'DS'
        products = @(
            [pscustomobject][ordered]@{code='edr';name='EDR';unit='endpoint';cost=0.0;sale=0.0}
            [pscustomobject][ordered]@{code='itdr';name='ITDR';unit='identity';cost=0.0;sale=0.0}
            [pscustomobject][ordered]@{code='siem';name='SIEM';unit='log source';cost=0.0;sale=0.0}
            [pscustomobject][ordered]@{code='espm';name='ESPM / Email Security';unit='protected user';cost=0.0;sale=0.0}
            [pscustomobject][ordered]@{code='ispm';name='ISPM';unit='identity';cost=0.0;sale=0.0}
        )
    }
}

function Get-HuntressSettings {
    $defaults = Get-DefaultSettings
    if (-not (Test-Path -LiteralPath $script:SettingsPath)) { Write-JsonAtomic $script:SettingsPath $defaults; return $defaults }
    try {
        $loaded = Get-Content -LiteralPath $script:SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if (-not $loaded.products) { throw 'Pricing table missing.' }
        foreach ($product in @($defaults.products)) {
            if (-not (@($loaded.products | Where-Object { [string]$_.code -eq [string]$product.code }).Count)) { $loaded.products += $product }
        }
        if (-not $loaded.currency) { $loaded | Add-Member NoteProperty currency 'DKK' -Force }
        if (-not $loaded.dsPrefix) { $loaded | Add-Member NoteProperty dsPrefix 'DS' -Force }
        return $loaded
    } catch {
        $backup = $script:SettingsPath + '.invalid-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss')
        Copy-Item -LiteralPath $script:SettingsPath -Destination $backup -Force -ErrorAction SilentlyContinue
        Write-JsonAtomic $script:SettingsPath $defaults
        return $defaults
    }
}

function Save-HuntressCredential([string]$PublicKey,[string]$PrivateKey) {
    if ([string]::IsNullOrWhiteSpace($PublicKey) -or [string]::IsNullOrWhiteSpace($PrivateKey)) { throw 'Both API Key and API Secret are required.' }
    Add-Type -AssemblyName System.Security
    $plain = [Text.Encoding]::UTF8.GetBytes(($PublicKey.Trim()+"`n"+$PrivateKey.Trim()))
    try {
        $protected = [Security.Cryptography.ProtectedData]::Protect($plain,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
        [IO.File]::WriteAllBytes($script:CredentialPath,$protected)
    } finally { [Array]::Clear($plain,0,$plain.Length) }
}

function Get-HuntressCredential {
    if (-not (Test-Path -LiteralPath $script:CredentialPath)) { return $null }
    Add-Type -AssemblyName System.Security
    $protected = [IO.File]::ReadAllBytes($script:CredentialPath)
    $plain = [Security.Cryptography.ProtectedData]::Unprotect($protected,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
    try {
        $parts = [Text.Encoding]::UTF8.GetString($plain) -split "`n",2
        if ($parts.Count -ne 2) { throw 'Stored Huntress credential is invalid.' }
        return [pscustomobject]@{PublicKey=$parts[0].Trim();PrivateKey=$parts[1].Trim()}
    } finally { [Array]::Clear($plain,0,$plain.Length) }
}

function Get-ApiHeader {
    $credential = Get-HuntressCredential
    if (-not $credential) { throw 'Huntress API credentials have not been configured on this computer.' }
    $bytes = [Text.Encoding]::UTF8.GetBytes(([string]$credential.PublicKey+':'+[string]$credential.PrivateKey))
    try { return @{Authorization='Basic '+[Convert]::ToBase64String($bytes);Accept='application/json'} }
    finally { [Array]::Clear($bytes,0,$bytes.Length) }
}

function Invoke-HuntressGet([string]$Url) {
    try { Invoke-RestMethod -Method Get -Uri $Url -Headers (Get-ApiHeader) -TimeoutSec 60 -ErrorAction Stop }
    catch {
        $status = try { [int]$_.Exception.Response.StatusCode } catch { 0 }
        if ($status -eq 401) { throw 'Huntress rejected the API key or secret (HTTP 401).' }
        if ($status -eq 403) { throw 'The Huntress user API key does not have permission for this data (HTTP 403).' }
        if ($status -eq 429) { throw 'Huntress rate limit reached. Wait one minute and synchronize again.' }
        throw $_.Exception
    }
}

function Invoke-HuntressCollection([string]$Path,[string]$PropertyName,[hashtable]$Query) {
    $items = [Collections.Generic.List[object]]::new()
    $url = $script:ApiBase + $Path
    if ($Query -and $Query.Count) {
        $pairs = foreach ($key in $Query.Keys) { [Uri]::EscapeDataString([string]$key)+'='+[Uri]::EscapeDataString([string]$Query[$key]) }
        $url += '?' + ($pairs -join '&')
    }
    do {
        $response = Invoke-HuntressGet $url
        foreach ($item in @($response.$PropertyName)) { $items.Add($item) }
        $url = Get-HuntressNextPageUrl $response
    } while ($url)
    return @($items)
}

function Write-WorkerProgress([int]$Percent,[string]$Message) {
    if ([string]::IsNullOrWhiteSpace($ProgressPath)) { return }
    Write-JsonAtomic $ProgressPath ([pscustomobject]@{percent=$Percent;message=$Message;updatedUtc=[DateTime]::UtcNow.ToString('o')}) 5
}

function Get-PropertyValue($Object,[string[]]$Names) {
    if ($null -eq $Object) { return $null }
    foreach ($name in $Names) {
        $property = $Object.PSObject.Properties[$name]
        if ($property) { return $property.Value }
    }
    return $null
}

function Get-HuntressNextPageUrl($Response) {
    $pagination = Get-PropertyValue $Response @('pagination')
    $nextPageUrl = Get-PropertyValue $pagination @('next_page_url')
    if ([string]::IsNullOrWhiteSpace([string]$nextPageUrl)) { return $null }
    return [string]$nextPageUrl
}

function Sum-UsageArray($Value) {
    $sum = 0.0
    foreach ($entry in @($Value)) {
        $count = Get-PropertyValue $entry @('billable_identities_count','billable_users_count','protected_users_count','users_count','billable_count','count')
        if ($null -ne $count) { $sum += [double]$count }
    }
    return [int][Math]::Round($sum)
}

function ConvertTo-HuntressUsage($Organization) {
    $actual = Get-PropertyValue $Organization @('actual_usages','actual_usage')
    $edrObject = Get-PropertyValue $actual @('edr')
    $siemObject = Get-PropertyValue $actual @('siem')
    $espmObject = Get-PropertyValue $actual @('espm','email_security','emailSecurity')
    $edrValue = Get-PropertyValue $edrObject @('billable_agents_count','agents_count','billable_count','count')
    $siemValue = Get-PropertyValue $siemObject @('billable_log_sources_count','log_sources_count','billable_count','count')
    $espmValue = Get-PropertyValue $espmObject @('billable_identities_count','billable_users_count','protected_users_count','users_count','billable_count','count')
    [pscustomobject][ordered]@{
        EDR = if ($null -eq $edrValue) { [int](Get-PropertyValue $Organization @('agents_count')) } else { [int]$edrValue }
        ITDR = Sum-UsageArray (Get-PropertyValue $actual @('itdr'))
        SIEM = if ($null -eq $siemValue) { [int](Get-PropertyValue $Organization @('logs_sources_count','log_sources_count')) } else { [int]$siemValue }
        ESPM = if ($null -eq $espmValue) { 0 } else { [int]$espmValue }
        ISPM = Sum-UsageArray (Get-PropertyValue $actual @('ispm'))
        ESPMAvailable = ($null -ne $espmObject)
    }
}

function Normalize-Name([string]$Value) {
    if ([string]::IsNullOrWhiteSpace($Value)) { return '' }
    return (($Value.ToLowerInvariant() -replace '^\s*ds(?=\s|[-_:]|[a-z])','' -replace '[^a-z0-9]','').Trim())
}

function Read-TenantCatalog {
    if ([string]::IsNullOrWhiteSpace($CatalogRoot) -or -not (Test-Path -LiteralPath $CatalogRoot)) { return @() }
    $latest = @{}
    foreach ($file in @(Get-ChildItem -LiteralPath $CatalogRoot -Filter 'tenants-*.json' -File -ErrorAction SilentlyContinue)) {
        try {
            foreach ($item in @(Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json)) {
                $key = ([string]$item.tenant).Trim().ToLowerInvariant()
                if (-not $key) { continue }
                $modified = try { [DateTime]::Parse([string]$item.modifiedUtc).ToUniversalTime() } catch { $file.LastWriteTimeUtc }
                if (-not $latest.ContainsKey($key) -or $modified -gt $latest[$key].Modified) { $latest[$key]=[pscustomobject]@{Item=$item;Modified=$modified} }
            }
        } catch {}
    }
    return @($latest.Values | ForEach-Object Item)
}

function Add-CustomerMatches([array]$Organizations,[array]$Tenants,[string]$DsPrefix) {
    $byTenant = @{}; $byName = @{}
    foreach ($tenant in $Tenants) {
        $id = ([string]$tenant.tenant).Trim().ToLowerInvariant(); if ($id) { $byTenant[$id]=$tenant }
        $nameKey = Normalize-Name ([string]$tenant.name); if ($nameKey -and -not $byName.ContainsKey($nameKey)) { $byName[$nameKey]=$tenant }
    }
    foreach ($organization in $Organizations) {
        $match = $null
        $providerId = ([string](Get-PropertyValue $organization @('identity_provider_tenant_id'))).Trim().ToLowerInvariant()
        if ($providerId -and $byTenant.ContainsKey($providerId)) { $match=$byTenant[$providerId] }
        if (-not $match) { $nameKey=Normalize-Name ([string]$organization.name); if ($byName.ContainsKey($nameKey)) { $match=$byName[$nameKey] } }
        $customerName = if ($match) { [string]$match.name } else { [string]$organization.name }
        $isDs = $false
        if ($match) { $isDs = $customerName -match ('(?i)^\s*'+[regex]::Escape($DsPrefix)+'(?=\s|[-_:]|[A-Z]|$)') }
        $organization | Add-Member NoteProperty customer_name $customerName -Force
        $organization | Add-Member NoteProperty tenant_id $(if ($match) { [string]$match.tenant } else { $providerId }) -Force
        $organization | Add-Member NoteProperty owner $(if ($isDs) { 'DSData' } else { 'PeakNet' }) -Force
        $organization | Add-Member NoteProperty matched ([bool]$match) -Force
    }
    return $Organizations
}

function Get-PriceMap($Settings) {
    $map=@{}; foreach($product in @($Settings.products)){$map[[string]$product.code.ToLowerInvariant()]=$product}; return $map
}

function ConvertTo-BillingRows([array]$Organizations,$Settings) {
    $prices=Get-PriceMap $Settings
    foreach($organization in $Organizations) {
        $usage=ConvertTo-HuntressUsage $organization
        $cost=0.0;$sale=0.0
        foreach($pair in @(@('edr',$usage.EDR),@('itdr',$usage.ITDR),@('siem',$usage.SIEM),@('espm',$usage.ESPM),@('ispm',$usage.ISPM))) {
            if($prices.ContainsKey($pair[0])){$cost += [double]$pair[1]*[double]$prices[$pair[0]].cost;$sale += [double]$pair[1]*[double]$prices[$pair[0]].sale}
        }
        [pscustomobject][ordered]@{Customer=[string]$organization.customer_name;Owner=[string]$organization.owner;EDR=$usage.EDR;ITDR=$usage.ITDR;SIEM=$usage.SIEM;ESPM=if($usage.ESPMAvailable){[string]$usage.ESPM}else{'N/A'};ISPM=$usage.ISPM;Cost=[Math]::Round($cost,2);Sales=[Math]::Round($sale,2);Margin=[Math]::Round($sale-$cost,2);Matched=if([bool]$organization.matched){'Matched'}else{'Huntress only'};OrganizationId=[int64]$organization.id}
    }
}

function Invoke-HuntressSyncWorker {
    Write-WorkerProgress 2 'Connecting securely to Huntress...'
    $null=Get-HuntressCredential
    $organizations=@(Invoke-HuntressCollection '/organizations' 'organizations' @{limit=500;sort_field='name';sort_direction='asc'})
    Write-WorkerProgress 8 ("Found {0} Huntress organizations." -f $organizations.Count)
    $detailed=[Collections.Generic.List[object]]::new();$windowStarted=[DateTime]::UtcNow;$requestsInWindow=1
    for($i=0;$i -lt $organizations.Count;$i++) {
        if($requestsInWindow -ge 55) {
            $remaining=61-([DateTime]::UtcNow-$windowStarted).TotalSeconds
            if($remaining -gt 0){Write-WorkerProgress (8+[int](72*($i/[Math]::Max(1,$organizations.Count)))) ("Respecting Huntress rate limit ({0}s)..." -f [Math]::Ceiling($remaining));Start-Sleep -Seconds ([int][Math]::Ceiling($remaining))}
            $windowStarted=[DateTime]::UtcNow;$requestsInWindow=0
        }
        $detail=(Invoke-HuntressGet ($script:ApiBase+'/organizations/'+[string]$organizations[$i].id)).organization
        if($detail){$detailed.Add($detail)}else{$detailed.Add($organizations[$i])}
        $requestsInWindow++
        Write-WorkerProgress (8+[int](72*(($i+1)/[Math]::Max(1,$organizations.Count)))) ("Reading product usage {0}/{1}: {2}" -f ($i+1),$organizations.Count,[string]$organizations[$i].name)
    }
    $incidents=@(Invoke-HuntressCollection '/incident_reports' 'incident_reports' @{limit=500;sort_field='updated_at';sort_direction='desc'})
    Write-WorkerProgress 88 ("Matching {0} incident reports to customers..." -f $incidents.Count)
    $settings=Get-HuntressSettings;$tenants=@(Read-TenantCatalog);$matched=@(Add-CustomerMatches @($detailed) $tenants ([string]$settings.dsPrefix))
    $nameById=@{};foreach($org in $matched){$nameById[[string]$org.id]=[string]$org.customer_name}
    foreach($incident in $incidents){$incident|Add-Member NoteProperty customer_name $(if($nameById.ContainsKey([string]$incident.organization_id)){$nameById[[string]$incident.organization_id]}else{"Organization $([string]$incident.organization_id)"}) -Force}
    $cache=[pscustomobject][ordered]@{version=1;syncedUtc=[DateTime]::UtcNow.ToString('o');organizations=$matched;incidents=$incidents;api='Huntress Platform API v1'}
    Write-JsonAtomic $script:CachePath $cache 30
    $monthKey=[DateTime]::Now.ToString('yyyy-MM')
    $snapshot=[pscustomobject][ordered]@{version=1;month=$monthKey;syncedUtc=$cache.syncedUtc;currency=[string]$settings.currency;rows=@(ConvertTo-BillingRows $matched $settings)}
    Write-JsonAtomic (Join-Path $script:SnapshotRoot ('billing-'+$monthKey+'.json')) $snapshot 20
    Write-JsonAtomic $ResultPath ([pscustomobject]@{success=$true;organizations=$matched.Count;incidents=$incidents.Count;syncedUtc=$cache.syncedUtc}) 8
    Write-WorkerProgress 100 'Huntress synchronization complete.'
}

function Invoke-SelfTest {
    $lastPage=[pscustomobject]@{pagination=[pscustomobject]@{}}
    if($null-ne(Get-HuntressNextPageUrl $lastPage)){throw 'Final-page pagination test failed.'}
    $nextPage=[pscustomobject]@{pagination=[pscustomobject]@{next_page_url='https://api.huntress.io/v1/organizations?page_token=test'}}
    if((Get-HuntressNextPageUrl $nextPage)-notlike'*page_token=test'){throw 'Next-page pagination test failed.'}
    $org=[pscustomobject]@{id=1;name='Acme';identity_provider_tenant_id='abc';actual_usages=[pscustomobject]@{edr=[pscustomobject]@{billable_agents_count=12};itdr=@([pscustomobject]@{billable_identities_count=24});siem=[pscustomobject]@{billable_log_sources_count=3};ispm=@([pscustomobject]@{billable_identities_count=21})}}
    $usage=ConvertTo-HuntressUsage $org
    if($usage.EDR-ne12-or$usage.ITDR-ne24-or$usage.SIEM-ne3-or$usage.ISPM-ne21-or$usage.ESPMAvailable){throw 'Usage parsing test failed.'}
    $tenant=[pscustomobject]@{name='DS Acme';tenant='abc'}
    $matched=@(Add-CustomerMatches @($org) @($tenant) 'DS')
    if($matched[0].owner-ne'DSData'-or-not$matched[0].matched){throw 'DSData matching test failed.'}
    $settings=Get-DefaultSettings;($settings.products|Where-Object { $_.code -eq 'edr' }).cost=10;($settings.products|Where-Object { $_.code -eq 'edr' }).sale=20
    $billing=@(ConvertTo-BillingRows $matched $settings)
    if($billing[0].Cost-ne120-or$billing[0].Sales-ne240-or$billing[0].Margin-ne120){throw 'Billing calculation test failed.'}
    if($billing[0].ESPM-ne'N/A'){throw 'Encoding-safe unavailable marker test failed.'}
    'Huntress integration self-test passed.'
}

if($SelfTest){Invoke-SelfTest;return}
if($Worker){try{Invoke-HuntressSyncWorker}catch{if($ResultPath){Write-JsonAtomic $ResultPath ([pscustomobject]@{success=$false;error=$_.Exception.Message}) 5};Write-WorkerProgress 100 ('Synchronization failed: '+$_.Exception.Message);exit 1};return}

Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase,System.Xaml,System.Windows.Forms
$settings=Get-HuntressSettings
$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="PeakNet | Huntress security and billing" Width="1420" Height="900" MinWidth="1120" MinHeight="720" WindowStartupLocation="CenterScreen" Background="#F4F6F4" FontFamily="Segoe UI">
<Window.Resources>
 <SolidColorBrush x:Key="Ink" Color="#142926"/><SolidColorBrush x:Key="Muted" Color="#60706D"/><SolidColorBrush x:Key="Teal" Color="#197782"/><SolidColorBrush x:Key="Line" Color="#D8DFDC"/>
 <Style TargetType="Button"><Setter Property="Background" Value="White"/><Setter Property="Foreground" Value="{StaticResource Ink}"/><Setter Property="BorderBrush" Value="{StaticResource Line}"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="15,9"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="b" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="b" Property="Background" Value="#EEF5F3"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter Property="Opacity" Value="0.45"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
 <Style x:Key="Primary" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Background" Value="#197782"/><Setter Property="Foreground" Value="White"/><Setter Property="BorderBrush" Value="#197782"/><Setter Property="Padding" Value="18,10"/></Style>
 <Style TargetType="DataGrid"><Setter Property="AutoGenerateColumns" Value="True"/><Setter Property="IsReadOnly" Value="True"/><Setter Property="CanUserAddRows" Value="False"/><Setter Property="GridLinesVisibility" Value="Horizontal"/><Setter Property="HeadersVisibility" Value="Column"/><Setter Property="RowHeaderWidth" Value="0"/><Setter Property="BorderThickness" Value="0"/><Setter Property="Background" Value="White"/><Setter Property="AlternationCount" Value="2"/><Setter Property="EnableRowVirtualization" Value="True"/></Style>
 <Style TargetType="DataGridColumnHeader"><Setter Property="Background" Value="#E8ECE9"/><Setter Property="Foreground" Value="#60706D"/><Setter Property="Padding" Value="12,10"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="BorderThickness" Value="0,0,0,1"/><Setter Property="BorderBrush" Value="#D8DFDC"/></Style>
 <Style TargetType="DataGridCell"><Setter Property="Padding" Value="10,7"/><Setter Property="BorderBrush" Value="#E5EAE7"/><Setter Property="BorderThickness" Value="0,0,0,1"/></Style>
 <Style TargetType="TabItem"><Setter Property="Padding" Value="18,10"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Foreground" Value="{StaticResource Muted}"/></Style>
</Window.Resources>
<Grid><Grid.RowDefinitions><RowDefinition Height="82"/><RowDefinition Height="106"/><RowDefinition Height="*"/><RowDefinition Height="42"/></Grid.RowDefinitions>
 <Border Background="White" BorderBrush="{StaticResource Line}" BorderThickness="0,0,0,1" Padding="24,13"><Grid><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel VerticalAlignment="Center"><TextBlock Text="Huntress security &amp; billing" FontSize="25" FontWeight="Bold" Foreground="{StaticResource Ink}"/><TextBlock Text="Incidents, product usage, margin and DSData license reconciliation" Foreground="{StaticResource Muted}" Margin="0,4,0,0"/></StackPanel><StackPanel Grid.Column="1" Orientation="Horizontal" VerticalAlignment="Center"><Border Background="#EEF5F3" CornerRadius="15" Padding="12,7" Margin="0,0,10,0"><TextBlock x:Name="ConnectionBadge" Text="NOT CONNECTED" FontSize="10" FontWeight="Bold" Foreground="{StaticResource Muted}"/></Border><Button x:Name="SyncButton" Content="Synchronize Huntress" Style="{StaticResource Primary}"/></StackPanel></Grid></Border>
 <Grid Grid.Row="1" Margin="20,14"><Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
  <Border Grid.Column="0" Background="White" BorderBrush="{StaticResource Line}" BorderThickness="1" CornerRadius="10" Margin="0,0,8,0" Padding="15"><StackPanel><TextBlock Text="CUSTOMERS" Foreground="{StaticResource Muted}" FontSize="10" FontWeight="Bold"/><TextBlock x:Name="CustomerKpi" Text="0" FontSize="27" FontWeight="Bold" Foreground="{StaticResource Ink}"/></StackPanel></Border>
  <Border Grid.Column="1" Background="White" BorderBrush="{StaticResource Line}" BorderThickness="1" CornerRadius="10" Margin="4,0" Padding="15"><StackPanel><TextBlock Text="OPEN INCIDENTS" Foreground="{StaticResource Muted}" FontSize="10" FontWeight="Bold"/><TextBlock x:Name="IncidentKpi" Text="0" FontSize="27" FontWeight="Bold" Foreground="#C54D38"/></StackPanel></Border>
  <Border Grid.Column="2" Background="White" BorderBrush="{StaticResource Line}" BorderThickness="1" CornerRadius="10" Margin="4,0" Padding="15"><StackPanel><TextBlock Text="MONTHLY SALES" Foreground="{StaticResource Muted}" FontSize="10" FontWeight="Bold"/><TextBlock x:Name="SalesKpi" Text="0 DKK" FontSize="27" FontWeight="Bold" Foreground="#26775E"/></StackPanel></Border>
  <Border Grid.Column="3" Background="White" BorderBrush="{StaticResource Line}" BorderThickness="1" CornerRadius="10" Margin="8,0,0,0" Padding="15"><StackPanel><TextBlock Text="DSDATA LICENSES" Foreground="{StaticResource Muted}" FontSize="10" FontWeight="Bold"/><TextBlock x:Name="DsKpi" Text="0" FontSize="27" FontWeight="Bold" Foreground="#197782"/></StackPanel></Border>
 </Grid>
 <TabControl x:Name="Tabs" Grid.Row="2" Margin="20,0,20,12" Background="White" BorderBrush="{StaticResource Line}">
  <TabItem Header="Customer overview"><Grid Margin="14"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><TextBlock Text="Live Huntress consumption by customer" FontSize="17" FontWeight="SemiBold" Margin="0,0,0,10"/><DataGrid x:Name="OverviewGrid" Grid.Row="1"/></Grid></TabItem>
  <TabItem Header="Incidents"><Grid Margin="14"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><StackPanel Orientation="Horizontal" Margin="0,0,0,10"><TextBlock Text="Problem incidents" FontSize="17" FontWeight="SemiBold"/><TextBlock Text="Open, sent and auto-remediating reports" Foreground="{StaticResource Muted}" Margin="12,4,0,0"/></StackPanel><DataGrid x:Name="IncidentGrid" Grid.Row="1"/></Grid></TabItem>
  <TabItem Header="Billing"><Grid Margin="14"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><StackPanel Orientation="Horizontal" Margin="0,0,0,10"><TextBlock Text="Monthly billing basis" FontSize="17" FontWeight="SemiBold"/><Button x:Name="ExportButton" Content="Export billing CSV" Margin="18,0,0,0"/></StackPanel><DataGrid x:Name="BillingGrid" Grid.Row="1"/></Grid></TabItem>
  <TabItem Header="DSData"><Grid Margin="14"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions><StackPanel Margin="0,0,0,10"><TextBlock Text="DSData license statement" FontSize="17" FontWeight="SemiBold"/><TextBlock Text="Customers matched to local tenant names beginning with DS" Foreground="{StaticResource Muted}" Margin="0,3,0,0"/></StackPanel><DataGrid x:Name="DsGrid" Grid.Row="1"/></Grid></TabItem>
  <TabItem Header="Settings"><ScrollViewer VerticalScrollBarVisibility="Auto"><Grid Margin="18" MaxWidth="940" HorizontalAlignment="Left"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
    <Border Background="#EEF5F3" BorderBrush="{StaticResource Line}" BorderThickness="1" CornerRadius="10" Padding="18"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="180"/><ColumnDefinition Width="360"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Grid.RowDefinitions><RowDefinition/><RowDefinition/><RowDefinition/></Grid.RowDefinitions><TextBlock Text="Huntress API Key" VerticalAlignment="Center"/><TextBox x:Name="ApiKeyBox" Grid.Column="1" Margin="0,5" Padding="8"/><TextBlock Grid.Column="2" Text="Stored only on this PC, encrypted for your Windows user." Foreground="{StaticResource Muted}" TextWrapping="Wrap" Margin="15,8,0,0"/><TextBlock Grid.Row="1" Text="Huntress API Secret" VerticalAlignment="Center"/><PasswordBox x:Name="ApiSecretBox" Grid.Row="1" Grid.Column="1" Margin="0,5" Padding="8"/><StackPanel Grid.Row="2" Grid.Column="1" Orientation="Horizontal" Margin="0,10,0,0"><Button x:Name="SaveCredentialButton" Content="Save credentials" Style="{StaticResource Primary}"/><Button x:Name="DeleteCredentialButton" Content="Remove" Margin="8,0,0,0"/></StackPanel></Grid></Border>
    <Border Grid.Row="1" Background="White" BorderBrush="{StaticResource Line}" BorderThickness="1" CornerRadius="10" Padding="18" Margin="0,14,0,0"><StackPanel><TextBlock Text="Pricing per unit / month" FontSize="17" FontWeight="SemiBold"/><TextBlock Text="Prices are shared between your computers. Enter your own net cost and customer sales price in DKK." Foreground="{StaticResource Muted}" Margin="0,3,0,10"/><DataGrid x:Name="PriceGrid" IsReadOnly="False" AutoGenerateColumns="False" Height="235"><DataGrid.Columns><DataGridTextColumn Header="PRODUCT" Binding="{Binding name}" IsReadOnly="True" Width="2*"/><DataGridTextColumn Header="UNIT" Binding="{Binding unit}" IsReadOnly="True" Width="1.4*"/><DataGridTextColumn Header="COST DKK" Binding="{Binding cost, UpdateSourceTrigger=PropertyChanged}" Width="*"/><DataGridTextColumn Header="SALES DKK" Binding="{Binding sale, UpdateSourceTrigger=PropertyChanged}" Width="*"/></DataGrid.Columns></DataGrid><Button x:Name="SavePricesButton" Content="Save prices" Style="{StaticResource Primary}" HorizontalAlignment="Left" Margin="0,12,0,0"/></StackPanel></Border>
    <Border Grid.Row="2" Background="#FFF7E8" BorderBrush="#E6D6B8" BorderThickness="1" CornerRadius="10" Padding="18" Margin="0,14,0,0"><StackPanel><TextBlock Text="API coverage" FontWeight="SemiBold"/><TextBlock Text="EDR, ITDR, SIEM and ISPM are read from Huntress actual product usage. ESPM / Email Security is used automatically when Huntress exposes it; otherwise it is shown as N/A and excluded from billing. A user-based, read-only API key is recommended." Foreground="#6D5B38" TextWrapping="Wrap" Margin="0,5,0,0"/></StackPanel></Border>
  </Grid></ScrollViewer></TabItem>
 </TabControl>
 <Border Grid.Row="3" Background="White" BorderBrush="{StaticResource Line}" BorderThickness="0,1,0,0" Padding="20,0"><Grid><TextBlock x:Name="StatusText" Text="Ready. Configure a Huntress API key in Settings." VerticalAlignment="Center" Foreground="{StaticResource Muted}"/><ProgressBar x:Name="Progress" Height="4" VerticalAlignment="Bottom" Minimum="0" Maximum="100" Value="0" Foreground="#197782" Background="#E8ECE9"/></Grid></Border>
</Grid></Window>
'@

$window=[Windows.Markup.XamlReader]::Parse($xaml)
$icon=Join-Path $PSScriptRoot 'PeakNet-Tenant-Access.ico';if(Test-Path $icon){$window.Icon=$icon}
$script:Cache=$null;$script:BillingRows=@();$script:SyncProcess=$null;$script:SyncDir=$null

function Format-Money([double]$Value){return ('{0:N2} {1}' -f $Value,[string](Get-HuntressSettings).currency)}
function Load-HuntressCache { if(Test-Path $script:CachePath){try{return Get-Content $script:CachePath -Raw -Encoding UTF8|ConvertFrom-Json}catch{}};return $null }
function Refresh-HuntressDashboard {
    $script:Cache=Load-HuntressCache;$currentSettings=Get-HuntressSettings
    if(-not$script:Cache){$window.FindName('StatusText').Text='No Huntress data yet. Configure credentials and synchronize.';return}
    $organizations=@($script:Cache.organizations);$allIncidents=@($script:Cache.incidents);$openIncidents=@($allIncidents|Where-Object{[string]$_.status-notin@('closed','dismissed','partner_dismissed')})
    $script:BillingRows=@(ConvertTo-BillingRows $organizations $currentSettings|Sort-Object Owner,Customer)
    $overview=@();foreach($row in $script:BillingRows){$incidentCount=@($openIncidents|Where-Object{[string]$_.customer_name-eq[string]$row.Customer}).Count;$overview+=[pscustomobject][ordered]@{Customer=$row.Customer;Owner=$row.Owner;EDR=$row.EDR;ITDR=$row.ITDR;SIEM=$row.SIEM;ESPM=$row.ESPM;ISPM=$row.ISPM;'Open incidents'=$incidentCount;Match=$row.Matched}}
    $incidentRows=@($openIncidents|ForEach-Object{[pscustomobject][ordered]@{Severity=([string]$_.severity).ToUpperInvariant();Customer=[string]$_.customer_name;Subject=[string]$_.subject;Status=[string]$_.status;Platform=[string]$_.platform;Updated=try{([DateTime]$_.updated_at).ToLocalTime().ToString('yyyy-MM-dd HH:mm')}catch{[string]$_.updated_at};'PSA ticket'=(@($_.psa_ticket_eids)-join', ');Id=[string]$_.id}})
    $window.FindName('OverviewGrid').ItemsSource=$overview;$window.FindName('IncidentGrid').ItemsSource=$incidentRows;$window.FindName('BillingGrid').ItemsSource=$script:BillingRows;$dsRows=@($script:BillingRows|Where-Object { $_.Owner -eq 'DSData' });$window.FindName('DsGrid').ItemsSource=$dsRows
    $dsLicenseTotal=0;foreach($row in $dsRows){$dsLicenseTotal += [int]$row.EDR+[int]$row.ITDR+[int]$row.SIEM+[int]$row.ISPM;if([string]$row.ESPM-ne'N/A'){$dsLicenseTotal += [int]$row.ESPM}}
    $window.FindName('CustomerKpi').Text=[string]$organizations.Count;$window.FindName('IncidentKpi').Text=[string]$openIncidents.Count;$window.FindName('SalesKpi').Text=Format-Money (($script:BillingRows|Measure-Object Sales -Sum).Sum);$window.FindName('DsKpi').Text=[string]$dsLicenseTotal
    $lastSync=try{([DateTime]$script:Cache.syncedUtc).ToLocalTime().ToString('yyyy-MM-dd HH:mm')}catch{[string]$script:Cache.syncedUtc}
    $window.FindName('ConnectionBadge').Text='CONNECTED / CACHED';$window.FindName('StatusText').Text='Last synchronized: '+$lastSync
}

$priceCollection=[Collections.ObjectModel.ObservableCollection[object]]::new();foreach($p in @($settings.products)){$priceCollection.Add([pscustomobject]@{code=[string]$p.code;name=[string]$p.name;unit=[string]$p.unit;cost=[double]$p.cost;sale=[double]$p.sale})};$window.FindName('PriceGrid').ItemsSource=$priceCollection
if(Test-Path $script:CredentialPath){$window.FindName('ApiKeyBox').Text='Stored on this computer';$window.FindName('ConnectionBadge').Text='CREDENTIAL READY'}

$timer=[Windows.Threading.DispatcherTimer]::new();$timer.Interval=[TimeSpan]::FromMilliseconds(700);$timer.Add_Tick({
    if(-not$script:SyncDir){return};$progressPath=Join-Path $script:SyncDir 'progress.json';$resultPath=Join-Path $script:SyncDir 'result.json'
    if(Test-Path $progressPath){try{$p=Get-Content $progressPath -Raw|ConvertFrom-Json;$window.FindName('Progress').Value=[double]$p.percent;$window.FindName('StatusText').Text=[string]$p.message}catch{}}
    if(Test-Path $resultPath){$timer.Stop();try{$r=Get-Content $resultPath -Raw|ConvertFrom-Json;if($r.success){Refresh-HuntressDashboard}else{[Windows.MessageBox]::Show([string]$r.error,'Huntress synchronization failed','OK','Error')|Out-Null}}catch{};$window.FindName('SyncButton').IsEnabled=$true;$window.FindName('Progress').Value=0;try{Remove-Item $script:SyncDir -Recurse -Force -ErrorAction SilentlyContinue}catch{};$script:SyncDir=$null}
})

$window.FindName('SyncButton').Add_Click({
    if(-not(Test-Path $script:CredentialPath)){$window.FindName('Tabs').SelectedIndex=4;[Windows.MessageBox]::Show('Enter a Huntress user API Key and Secret in Settings first.','Huntress setup','OK','Information')|Out-Null;return}
    $script:SyncDir=Join-Path $script:LocalRoot ('sync-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force $script:SyncDir|Out-Null;$result=Join-Path $script:SyncDir 'result.json';$progress=Join-Path $script:SyncDir 'progress.json';$hostPath=try{(Get-Process -Id $PID).Path}catch{'powershell.exe'}
    $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=$hostPath;$psi.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$PSCommandPath+'" -Worker -SharedDataRoot "'+$SharedDataRoot+'" -CatalogRoot "'+$CatalogRoot+'" -ResultPath "'+$result+'" -ProgressPath "'+$progress+'"';$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.WindowStyle='Hidden';$script:SyncProcess=[Diagnostics.Process]::Start($psi);$window.FindName('SyncButton').IsEnabled=$false;$timer.Start()
})
$window.FindName('SaveCredentialButton').Add_Click({try{Save-HuntressCredential $window.FindName('ApiKeyBox').Text $window.FindName('ApiSecretBox').Password;$window.FindName('ApiKeyBox').Text='Stored on this computer';$window.FindName('ApiSecretBox').Clear();$window.FindName('ConnectionBadge').Text='CREDENTIAL READY';[Windows.MessageBox]::Show('Huntress credentials were encrypted for this Windows user. They are not stored in the shared folder.','Credentials saved','OK','Information')|Out-Null}catch{[Windows.MessageBox]::Show($_.Exception.Message,'Could not save credentials','OK','Error')|Out-Null}})
$window.FindName('DeleteCredentialButton').Add_Click({if(Test-Path $script:CredentialPath){Remove-Item -LiteralPath $script:CredentialPath -Force};$window.FindName('ApiKeyBox').Clear();$window.FindName('ApiSecretBox').Clear();$window.FindName('ConnectionBadge').Text='NOT CONNECTED'})
$window.FindName('SavePricesButton').Add_Click({try{$newSettings=Get-HuntressSettings;$newSettings.products=@($priceCollection|ForEach-Object{[pscustomobject][ordered]@{code=$_.code;name=$_.name;unit=$_.unit;cost=[double]$_.cost;sale=[double]$_.sale}});Write-JsonAtomic $script:SettingsPath $newSettings;Refresh-HuntressDashboard;[Windows.MessageBox]::Show('Shared Huntress prices were saved.','Pricing saved','OK','Information')|Out-Null}catch{[Windows.MessageBox]::Show($_.Exception.Message,'Invalid prices','OK','Error')|Out-Null}})
$window.FindName('ExportButton').Add_Click({if(-not$script:BillingRows.Count){return};$path=Join-Path $script:ExportRoot ('Huntress-billing-'+[DateTime]::Now.ToString('yyyy-MM')+'.csv');$script:BillingRows|Export-Csv -LiteralPath $path -NoTypeInformation -Encoding UTF8;Start-Process explorer.exe -ArgumentList ('/select,"'+$path+'"')})
$window.Add_Closed({$timer.Stop();if($script:SyncProcess-and-not$script:SyncProcess.HasExited){try{$script:SyncProcess.Kill()}catch{}}})
Refresh-HuntressDashboard
[void]$window.ShowDialog()
