# Crayon Microsoft 365 licensing and billing

PeakNet Tenant Access 6.0 adds a read-only Crayon Cloud-iQ integration for Microsoft 365 subscription, renewal and profitability reporting.

## Create the API access

1. Ask the PeakNet Crayon contact to provide a tenant administrator account if one is not already available.
2. Sign in to `https://cloudiq.crayon.com/clients/` and register an API client. Copy its Client ID and Client Secret.
3. Sign in to `https://cloudiq.crayon.com/users/` and create a dedicated API user with read access to the relevant organizations, customer tenants, subscriptions and prices.
4. In PeakNet Tenant Access, choose **Microsoft 365 licensing & billing**, open **Settings**, and save the four values.
5. Repeat the credential step on the second computer. Credentials are encrypted locally with Windows DPAPI and are never synchronized.

## What is synchronized

The module reads customer tenants and Microsoft subscriptions from Crayon, then retrieves subscription details, current unit prices and current reseller sales-price rules. It calculates monthly-equivalent cost, known revenue and known profit and shows renewal dates, automatic renewal, billing cycle, term and quantity.

Customers whose Crayon name or matching local tenant name begins with `DS` are assigned to **DSData**. All other customers are assigned to **PeakNet**. Cached reports and CSV exports are stored under `Clients\_PeakNet Tenant Access\Crayon`, while API credentials remain only on the current PC.

Revenue is shown only when Crayon returns an applicable reseller sales-price rule. A missing rule is displayed as **Not configured** instead of inventing a sales price.

The integration is read-only. It does not order, cancel, suspend, renew or change subscriptions.
