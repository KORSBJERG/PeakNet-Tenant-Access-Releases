# PeakNet Microsoft 365 MSP connection

This one-time setup allows PeakNet Tenant Access to read the customer list and GDAP relationship metadata from Microsoft Graph. It cannot create, modify, approve, or delete GDAP relationships.

## Register the desktop application

1. Sign in to the Microsoft Entra admin center using the PeakNet partner tenant—not a customer tenant.
2. Open **Identity > Applications > App registrations** and select **New registration**.
3. Name it `PeakNet Tenant Access`.
4. Select **Accounts in this organizational directory only**.
5. After registration, open **Authentication**, add the **Mobile and desktop applications** platform, and add the redirect URI `http://localhost`.
6. Do not create a client secret. This is a local public-client application using authorization-code flow with PKCE.
7. Open **API permissions**, select **Microsoft Graph > Delegated permissions**, and add:
   - `User.Read`
   - `DelegatedAdminRelationship.Read.All`
8. Grant administrator consent for the PeakNet partner tenant.
9. Copy the **Directory (tenant) ID** and **Application (client) ID** from the app registration Overview page.

## Connect the launcher

1. Restart PeakNet Tenant Access and select **Connect MSP**.
2. Enter the partner Tenant ID and Application ID.
3. Complete Microsoft account selection and MFA in the browser.
4. Return to the launcher after the browser confirms completion.
5. The launcher reads `tenantRelationships/delegatedAdminCustomers` and `tenantRelationships/delegatedAdminRelationships`, then merges the results into the local catalog by Tenant ID.

Use **Sync GDAP** whenever Partner Center relationships change. Customers no longer returned by Microsoft are retained locally but marked `Not returned by latest sync` so their local notes and time history are not destroyed.

## Security boundaries

- Microsoft receives the password and MFA response; the launcher never does.
- The OAuth callback listens on a random localhost port for a maximum of four minutes and validates a cryptographically random state value and PKCE verifier.
- Tokens remain only in process memory and are cleared on disconnect or application exit.
- The local configuration contains only the partner Tenant ID, public Application ID, and last UPN.
- The Graph permission is read-only. Actual customer administration remains governed by GDAP relationships, access assignments, security-group membership, Conditional Access, and the signed-in technician's permissions.
- Relationship roles displayed by the launcher describe the roles available in that GDAP relationship. They do not prove that the signed-in technician is assigned every displayed role.
