[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$PackagePath,
    [Parameter(Mandatory)][string]$InstallRoot,
    [Parameter(Mandatory)][string]$ExpectedSha256,
    [Parameter(Mandatory)][string]$ExpectedVersion,
    [int]$ParentProcessId = 0,
    [switch]$NoRestart
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$localRoot = Join-Path $env:LOCALAPPDATA 'MSPTenantLauncher\Updates'
$logRoot = Join-Path $localRoot 'Logs'
$backupRoot = Join-Path $localRoot 'Rollback'
New-Item -ItemType Directory -Force -Path $localRoot,$logRoot,$backupRoot | Out-Null
$logPath = Join-Path $logRoot ("update-{0}.log" -f [DateTime]::Now.ToString('yyyyMMdd-HHmmss'))

function Write-UpdateLog([string]$Message) {
    Add-Content -LiteralPath $logPath -Value ("{0:o} {1}" -f [DateTime]::UtcNow,$Message) -Encoding UTF8
}
function Assert-SafeRelativePath([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or [IO.Path]::IsPathRooted($Path) -or $Path -match '(^|[\\/])\.\.([\\/]|$)') { throw "Unsafe package path: $Path" }
}
function Test-PowerShellSyntax([string]$Path) {
    $tokens=$null;$errors=$null
    [void][Management.Automation.Language.Parser]::ParseFile($Path,[ref]$tokens,[ref]$errors)
    if (@($errors).Count) { throw "PowerShell syntax validation failed for $(Split-Path $Path -Leaf): $($errors[0].Message)" }
}

$stage = Join-Path $localRoot ("stage-{0}" -f [guid]::NewGuid().ToString('N'))
$backup = Join-Path $backupRoot ("{0}-{1}" -f $ExpectedVersion,[DateTime]::Now.ToString('yyyyMMdd-HHmmss'))
$installed = $false
try {
    Write-UpdateLog "Starting update to $ExpectedVersion"
    if ($ParentProcessId -gt 0) {
        try { Wait-Process -Id $ParentProcessId -Timeout 60 -ErrorAction Stop } catch {
            if (Get-Process -Id $ParentProcessId -ErrorAction SilentlyContinue) { throw 'PeakNet Tenant Access did not close in time.' }
        }
    }
    if (-not (Test-Path -LiteralPath $PackagePath -PathType Leaf)) { throw 'Downloaded update package was not found.' }
    $actualPackageHash=(Get-FileHash -LiteralPath $PackagePath -Algorithm SHA256).Hash
    if ($actualPackageHash -ne $ExpectedSha256.Trim().ToUpperInvariant()) { throw 'The downloaded package hash does not match the signed update feed.' }

    New-Item -ItemType Directory -Force -Path $stage,$backup | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive=[IO.Compression.ZipFile]::OpenRead($PackagePath)
    try { foreach($entry in $archive.Entries) { Assert-SafeRelativePath $entry.FullName } } finally { $archive.Dispose() }
    [IO.Compression.ZipFile]::ExtractToDirectory($PackagePath,$stage)

    $manifestPath=Join-Path $stage 'release-manifest.json'
    if (-not (Test-Path -LiteralPath $manifestPath)) { throw 'The package has no release manifest.' }
    $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([string]$manifest.product -ne 'PeakNet Tenant Access' -or [string]$manifest.version -ne $ExpectedVersion) { throw 'Package identity or version does not match the signed update feed.' }
    if (-not ($manifest.PSObject.Properties.Name -contains 'files')) { throw 'The package manifest has no file inventory.' }

    $files=@($manifest.files)
    if ($files.Count -lt 5) { throw 'The package manifest is incomplete.' }
    foreach($item in $files) {
        $relative=[string]$item.path; Assert-SafeRelativePath $relative
        $source=Join-Path $stage $relative
        if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Package file is missing: $relative" }
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne ([string]$item.sha256).ToUpperInvariant()) { throw "Package file hash failed: $relative" }
        if ([IO.Path]::GetExtension($source) -ieq '.ps1') { Test-PowerShellSyntax $source }
    }
    $required=@('MSP-Tenant-Launcher.ps1','PeakNet-Updater.ps1','Start-MSP-Tenant-Launcher.vbs','Update-Config.json','PeakNet-Update-Publisher.cer')
    foreach($name in $required) { if (-not ($files.path -contains $name)) { throw "Required application file is missing: $name" } }

    foreach($item in $files) {
        $relative=[string]$item.path;$current=Join-Path $InstallRoot $relative
        if (Test-Path -LiteralPath $current -PathType Leaf) {
            $backupTarget=Join-Path $backup $relative
            New-Item -ItemType Directory -Force -Path (Split-Path $backupTarget -Parent) | Out-Null
            Copy-Item -LiteralPath $current -Destination $backupTarget -Force
        }
    }
    if (Test-Path -LiteralPath (Join-Path $InstallRoot 'release-manifest.json')) { Copy-Item -LiteralPath (Join-Path $InstallRoot 'release-manifest.json') -Destination (Join-Path $backup 'release-manifest.json') -Force }

    foreach($item in $files) {
        $relative=[string]$item.path;$source=Join-Path $stage $relative;$target=Join-Path $InstallRoot $relative
        New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent) | Out-Null
        $temporary="$target.new";Copy-Item -LiteralPath $source -Destination $temporary -Force;Move-Item -LiteralPath $temporary -Destination $target -Force
    }
    Copy-Item -LiteralPath $manifestPath -Destination (Join-Path $InstallRoot 'release-manifest.json') -Force
    $installed=$true;Write-UpdateLog "Update $ExpectedVersion installed successfully. Rollback: $backup"
} catch {
    $failure=$_.Exception.Message;Write-UpdateLog "FAILED: $failure"
    if (Test-Path -LiteralPath $backup) {
        try {
            Get-ChildItem -LiteralPath $backup -File -Recurse | ForEach-Object {
                $relative=$_.FullName.Substring($backup.Length).TrimStart('\');$target=Join-Path $InstallRoot $relative
                New-Item -ItemType Directory -Force -Path (Split-Path $target -Parent) | Out-Null;Copy-Item -LiteralPath $_.FullName -Destination $target -Force
            }
            Write-UpdateLog 'Previous version restored.'
        } catch { Write-UpdateLog "ROLLBACK FAILED: $($_.Exception.Message)" }
    }
    [Windows.Forms.MessageBox]::Show("PeakNet Tenant Access could not be updated.`n`n$failure`n`nThe previous version was restored. Log:`n$logPath",'Update failed','OK','Error') | Out-Null
} finally {
    Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $PackagePath -Force -ErrorAction SilentlyContinue
}
if ($installed) { Write-UpdateLog 'Restarting PeakNet Tenant Access.' }
$launcher=Join-Path $InstallRoot 'Start-MSP-Tenant-Launcher.vbs'
if (-not $NoRestart -and (Test-Path -LiteralPath $launcher)) { Start-Process -FilePath 'wscript.exe' -ArgumentList ('"{0}"' -f $launcher) }