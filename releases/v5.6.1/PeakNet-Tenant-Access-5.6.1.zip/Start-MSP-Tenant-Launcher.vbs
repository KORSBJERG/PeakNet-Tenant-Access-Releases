Option Explicit

Dim shell, fileSystem, appFolder, scriptPath, command
Set shell = CreateObject("WScript.Shell")
Set fileSystem = CreateObject("Scripting.FileSystemObject")

appFolder = fileSystem.GetParentFolderName(WScript.ScriptFullName)
scriptPath = fileSystem.BuildPath(appFolder, "MSP-Tenant-Launcher.ps1")
command = "powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -STA -File " & Chr(34) & scriptPath & Chr(34)

shell.Run command, 0, False
