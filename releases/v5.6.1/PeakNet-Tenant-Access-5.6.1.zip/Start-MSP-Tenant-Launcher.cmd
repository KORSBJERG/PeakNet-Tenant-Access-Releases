@echo off
wscript.exe "%~dp0Start-MSP-Tenant-Launcher.vbs"
