Set-StrictMode -Version Latest

function ConvertTo-SvgNumber([string]$Value,[double]$Fallback=0) {
    if([string]::IsNullOrWhiteSpace($Value)){return $Fallback}
    $match=[regex]::Match($Value,'[-+]?(?:\d*\.)?\d+(?:[eE][-+]?\d+)?')
    if(-not$match.Success){return $Fallback}
    $number=0.0
    if([double]::TryParse($match.Value,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$number)){return $number}
    return $Fallback
}

function Get-SvgStyleValue($Node,[string]$Name,[string]$Inherited='') {
    if($Node.Attributes -and $Node.Attributes[$Name]){return [string]$Node.Attributes[$Name].Value}
    if($Node.Attributes -and $Node.Attributes['style']){foreach($part in ([string]$Node.Attributes['style'].Value).Split(';')){$pair=$part.Split(':',2);if($pair.Count -eq 2 -and $pair[0].Trim() -eq $Name){return $pair[1].Trim()}}}
    return $Inherited
}

function Get-SvgBrush([string]$Value,[double]$Opacity=1) {
    if([string]::IsNullOrWhiteSpace($Value)){$Value='#000000'}
    if($Value -eq 'none'){return $null};if($Value -eq 'currentColor'){$Value='#000000'}
    try{$color=[Windows.Media.ColorConverter]::ConvertFromString($Value);$color.A=[byte]([Math]::Max(0,[Math]::Min(255,[int](255*$Opacity))));$brush=[Windows.Media.SolidColorBrush]::new($color);$brush.Freeze();return $brush}catch{return $null}
}

function Get-SvgNodeTransform($Node) {
    if(-not $Node.Attributes -or -not $Node.Attributes['transform']){return $null}
    $value=[string]$Node.Attributes['transform'].Value;$matrix=[Windows.Media.Matrix]::Identity
    foreach($match in [regex]::Matches($value,'(?i)(matrix|translate|scale|rotate)\s*\(([^)]*)\)')){
        $numbers=@([regex]::Matches($match.Groups[2].Value,'[-+]?(?:\d*\.)?\d+(?:[eE][-+]?\d+)?')|ForEach-Object{[double]::Parse($_.Value,[Globalization.CultureInfo]::InvariantCulture)})
        switch($match.Groups[1].Value.ToLowerInvariant()){
            'matrix'{if($numbers.Count -ge 6){$next=[Windows.Media.Matrix]::new($numbers[0],$numbers[1],$numbers[2],$numbers[3],$numbers[4],$numbers[5]);$matrix.Append($next)}}
            'translate'{if($numbers.Count){$ty=if($numbers.Count -gt 1){$numbers[1]}else{0};$matrix.Translate($numbers[0],$ty)}}
            'scale'{if($numbers.Count){$sy=if($numbers.Count -gt 1){$numbers[1]}else{$numbers[0]};$matrix.Scale($numbers[0],$sy)}}
            'rotate'{if($numbers.Count -ge 3){$matrix.RotateAt($numbers[0],$numbers[1],$numbers[2])}elseif($numbers.Count){$matrix.Rotate($numbers[0])}}
        }
    }
    return [Windows.Media.MatrixTransform]::new($matrix)
}

function Draw-SvgXmlNode($Node,[Windows.Media.DrawingContext]$Context,[string]$InheritedFill='#000000',[double]$InheritedOpacity=1) {
    if($Node.NodeType -ne [Xml.XmlNodeType]::Element){return}
    $fill=Get-SvgStyleValue $Node 'fill' $InheritedFill;$opacity=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'opacity' ([string]$InheritedOpacity)) $InheritedOpacity;$transform=Get-SvgNodeTransform $Node
    if($transform){$Context.PushTransform($transform)}
    try{
        $geometry=$null
        switch($Node.LocalName.ToLowerInvariant()){
            'path'{if($Node.Attributes['d']){try{$geometry=[Windows.Media.Geometry]::Parse([string]$Node.Attributes['d'].Value)}catch{}}}
            'rect'{$x=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'x');$y=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'y');$w=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'width');$h=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'height');$rx=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'rx');$geometry=[Windows.Media.RectangleGeometry]::new([Windows.Rect]::new($x,$y,$w,$h),$rx,$rx)}
            'circle'{$cx=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'cx');$cy=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'cy');$r=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'r');$geometry=[Windows.Media.EllipseGeometry]::new([Windows.Point]::new($cx,$cy),$r,$r)}
            'ellipse'{$cx=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'cx');$cy=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'cy');$rx=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'rx');$ry=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'ry');$geometry=[Windows.Media.EllipseGeometry]::new([Windows.Point]::new($cx,$cy),$rx,$ry)}
            'line'{$geometry=[Windows.Media.LineGeometry]::new([Windows.Point]::new((ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'x1')),(ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'y1'))),[Windows.Point]::new((ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'x2')),(ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'y2'))))}
            {$_ -in @('polygon','polyline')}{$points=@([regex]::Matches((Get-SvgStyleValue $Node 'points'),'[-+]?(?:\d*\.)?\d+(?:[eE][-+]?\d+)?')|ForEach-Object{[double]::Parse($_.Value,[Globalization.CultureInfo]::InvariantCulture)});if($points.Count -ge 4){$streamGeometry=[Windows.Media.StreamGeometry]::new();$ctx=$streamGeometry.Open();try{$ctx.BeginFigure([Windows.Point]::new($points[0],$points[1]),$true,($Node.LocalName -eq 'polygon'));for($i=2;$i -lt $points.Count-1;$i+=2){$ctx.LineTo([Windows.Point]::new($points[$i],$points[$i+1]),$true,$false)}}finally{$ctx.Close()};$geometry=$streamGeometry}}
        }
        if($geometry){$brush=Get-SvgBrush $fill $opacity;$strokeValue=Get-SvgStyleValue $Node 'stroke';$pen=$null;if($strokeValue -and $strokeValue -ne 'none'){$strokeBrush=Get-SvgBrush $strokeValue $opacity;$strokeWidth=ConvertTo-SvgNumber (Get-SvgStyleValue $Node 'stroke-width') 1;if($strokeBrush){$pen=[Windows.Media.Pen]::new($strokeBrush,$strokeWidth)}};$Context.DrawGeometry($brush,$pen,$geometry)}
        foreach($child in $Node.ChildNodes){Draw-SvgXmlNode $child $Context $fill $opacity}
    }finally{if($transform){$Context.Pop()}}
}

function Convert-SvgToPngWpf([string]$SvgPath,[string]$OutputPath) {
    try{
        [xml]$document=Get-Content -Raw -LiteralPath $SvgPath;$root=$document.DocumentElement;if(-not $root){return $null};$viewBox=@()
        if($root.Attributes['viewBox']){$viewBox=@([regex]::Matches([string]$root.Attributes['viewBox'].Value,'[-+]?(?:\d*\.)?\d+(?:[eE][-+]?\d+)?')|ForEach-Object{[double]::Parse($_.Value,[Globalization.CultureInfo]::InvariantCulture)})}
        if($viewBox.Count -ge 4){$minX=$viewBox[0];$minY=$viewBox[1];$sourceWidth=$viewBox[2];$sourceHeight=$viewBox[3]}else{$minX=0;$minY=0;$sourceWidth=ConvertTo-SvgNumber ([string]$root.width) 800;$sourceHeight=ConvertTo-SvgNumber ([string]$root.height) 400}
        if($sourceWidth -le 0 -or $sourceHeight -le 0){return $null};$aspect=$sourceWidth/$sourceHeight;if($aspect -ge (16/9)){$width=1600;$height=[int](1600/$aspect)}else{$height=900;$width=[int](900*$aspect)}
        $visual=[Windows.Media.DrawingVisual]::new();$context=$visual.RenderOpen();try{$scale=[Math]::Min($width/$sourceWidth,$height/$sourceHeight);$matrix=[Windows.Media.Matrix]::Identity;$matrix.Scale($scale,$scale);$matrix.Translate(-$minX,-$minY);$context.PushTransform([Windows.Media.MatrixTransform]::new($matrix));Draw-SvgXmlNode $root $context '#000000' 1;$context.Pop()}finally{$context.Close()}
        $bitmap=[Windows.Media.Imaging.RenderTargetBitmap]::new($width,$height,96,96,[Windows.Media.PixelFormats]::Pbgra32);$bitmap.Render($visual);$encoder=[Windows.Media.Imaging.PngBitmapEncoder]::new();$encoder.Frames.Add([Windows.Media.Imaging.BitmapFrame]::Create($bitmap));$stream=[IO.File]::Create($OutputPath);try{$encoder.Save($stream)}finally{$stream.Dispose()};if((Get-Item -LiteralPath $OutputPath).Length -gt 32){return $OutputPath}
    }catch{}
    return $null
}

function Get-EdgeExecutable {
    foreach ($path in @(
        (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe')
    )) { if ($path -and (Test-Path -LiteralPath $path)) { return $path } }
    return $null
}

function Convert-SvgToPng([string]$SvgPath, [string]$OutputPath) {
    $wpfResult=Convert-SvgToPngWpf $SvgPath $OutputPath
    if ($wpfResult) { return $wpfResult }
    $edge = Get-EdgeExecutable
    if (-not $edge) { return $null }
    $fileUri = [Uri]::new($SvgPath).AbsoluteUri
    $profile = Join-Path ([IO.Path]::GetTempPath()) ('PeakNetBrandingEdge-' + [guid]::NewGuid().ToString('N'))
    New-Item -ItemType Directory -Path $profile -Force | Out-Null
    try {
        $arguments = "--headless=new --disable-gpu --hide-scrollbars --run-all-compositor-stages-before-draw --default-background-color=00000000 --window-size=1600,900 --user-data-dir=`"$profile`" --screenshot=`"$OutputPath`" `"$fileUri`""
        $process = Start-Process -FilePath $edge -ArgumentList $arguments -WindowStyle Hidden -Wait -PassThru
        $deadline = [DateTime]::UtcNow.AddSeconds(8)
        while (-not (Test-Path -LiteralPath $OutputPath) -and [DateTime]::UtcNow -lt $deadline) { Start-Sleep -Milliseconds 200 }
        if ($process.ExitCode -eq 0 -and (Test-Path -LiteralPath $OutputPath)) { return $OutputPath }
    } catch {} finally {
        if (Test-Path -LiteralPath $profile) { Remove-Item -LiteralPath $profile -Recurse -Force -ErrorAction SilentlyContinue }
    }
    return $null
}

function Get-ImageCandidates([string]$Html, [Uri]$BaseUri) {
    $items = [Collections.Generic.List[object]]::new()
    foreach ($tagMatch in [regex]::Matches($Html, '(?is)<img\b[^>]*>')) {
        $tag = $tagMatch.Value
        $descriptor = ((Get-HtmlAttributeValue $tag 'alt') + ' ' + (Get-HtmlAttributeValue $tag 'class') + ' ' + (Get-HtmlAttributeValue $tag 'id')).ToLowerInvariant()
        $sources = [Collections.Generic.List[string]]::new()
        $src = Get-HtmlAttributeValue $tag 'src'; if ($src) { $sources.Add($src) }
        $srcset = Get-HtmlAttributeValue $tag 'srcset'
        if ($srcset) {
            foreach ($entry in $srcset.Split(',')) {
                $candidate = $entry.Trim().Split(' ')[0]
                if ($candidate) { $sources.Add($candidate) }
            }
        }
        foreach ($source in $sources) {
            $uri = Get-AbsoluteCandidateUri $BaseUri $source
            if ($uri) {
                $score = if ($descriptor -match 'logo|brand') { 100 } else { 25 }
                if ($source -match '(?i)logo|brand') { $score += 35 }
                if ($source -match '(?i)\.svg(?:\?|$)') { $score += 25 }
                if ($source -match '(?i)(large|2x|3x|@2|@3)') { $score += 12 }
                $items.Add([pscustomobject]@{ Uri=$uri; Kind='logo'; Score=$score })
            }
        }
    }
    foreach ($match in [regex]::Matches($Html, '(?is)"logo"\s*:\s*(?:\{[^}]*?"url"\s*:\s*)?["'']([^"'']+)["'']')) {
        $uri = Get-AbsoluteCandidateUri $BaseUri $match.Groups[1].Value
        if ($uri) { $items.Add([pscustomobject]@{ Uri=$uri; Kind='logo'; Score=145 }) }
    }
    foreach ($tagMatch in [regex]::Matches($Html, '(?is)<meta\b[^>]*>')) {
        $tag = $tagMatch.Value
        $property = ((Get-HtmlAttributeValue $tag 'property') + ' ' + (Get-HtmlAttributeValue $tag 'name')).ToLowerInvariant()
        $uri = Get-AbsoluteCandidateUri $BaseUri (Get-HtmlAttributeValue $tag 'content')
        if (-not $uri) { continue }
        if ($property -match 'og:image|twitter:image') { $items.Add([pscustomobject]@{ Uri=$uri; Kind='hero'; Score=80 }) }
        elseif ($property -match 'logo') { $items.Add([pscustomobject]@{ Uri=$uri; Kind='logo'; Score=110 }) }
    }
    foreach ($tagMatch in [regex]::Matches($Html, '(?is)<link\b[^>]*>')) {
        $tag = $tagMatch.Value
        $rel = Get-HtmlAttributeValue $tag 'rel'
        if ($rel -match '(?i)icon|apple-touch-icon') {
            $uri = Get-AbsoluteCandidateUri $BaseUri (Get-HtmlAttributeValue $tag 'href')
            if ($uri) { $items.Add([pscustomobject]@{ Uri=$uri; Kind='icon'; Score=10 }) }
        }
    }
    foreach ($match in [regex]::Matches($Html, '(?is)background(?:-image)?\s*:[^;}]*(?:url\()?\s*["'']?([^"'')\s]+)')) {
        $uri = Get-AbsoluteCandidateUri $BaseUri $match.Groups[1].Value
        if ($uri) { $items.Add([pscustomobject]@{ Uri=$uri; Kind='hero'; Score=35 }) }
    }
    $items.Add([pscustomobject]@{ Uri=[Uri]::new($BaseUri,'/favicon.ico'); Kind='icon'; Score=1 })
    return @($items | Sort-Object Score -Descending)
}

function Save-WebCandidate($Candidate, [string]$CacheFolder, [int]$Index) {
    if (-not (Test-PublicWebUri $Candidate.Uri)) { return $null }
    $extension = [IO.Path]::GetExtension($Candidate.Uri.AbsolutePath)
    if ([string]::IsNullOrWhiteSpace($extension) -or $extension.Length -gt 6) { $extension = '.img' }
    $path = Join-Path $CacheFolder ("asset-{0:D3}{1}" -f $Index,$extension)
    try {
        $response = Invoke-WebRequest -Uri $Candidate.Uri.AbsoluteUri -UseBasicParsing -TimeoutSec 20 -MaximumRedirection 4 -OutFile $path -PassThru -Headers @{ 'User-Agent'='Mozilla/5.0 PeakNet-Branding-Studio/2.0' }
        $finalUri = if ($response.BaseResponse.ResponseUri) { [Uri]$response.BaseResponse.ResponseUri } else { $Candidate.Uri }
        if (-not (Test-PublicWebUri $finalUri)) { return $null }
        $length = (Get-Item -LiteralPath $path).Length
        if ($length -lt 32 -or $length -gt 12MB) { return $null }
        $contentType = [string]$response.Headers['Content-Type']
        $isSvg = $contentType -match 'svg' -or $extension -eq '.svg'
        if (-not $isSvg) {
            $firstBytes = [IO.File]::ReadAllBytes($path)
            if ($firstBytes.Length -gt 5) {
                $prefix = [Text.Encoding]::UTF8.GetString($firstBytes,0,[Math]::Min(256,$firstBytes.Length))
                $isSvg = $prefix -match '(?i)<svg\b'
            }
        }
        if ($isSvg) {
            $svgPath = [IO.Path]::ChangeExtension($path,'.svg')
            if ($svgPath -ne $path) { Move-Item -LiteralPath $path -Destination $svgPath -Force }
            $pngPath = [IO.Path]::ChangeExtension($svgPath,'.png')
            $converted = Convert-SvgToPng $svgPath $pngPath
            if ($converted) { return [pscustomobject]@{ RasterPath=$converted; OriginalPath=$svgPath; Uri=$finalUri; Kind=$Candidate.Kind; Vector=$true } }
            return $null
        }
        $stream = [IO.File]::OpenRead($path); $image = $null
        try {
            $image = [Drawing.Image]::FromStream($stream,$true,$true)
            if ($image.Width -lt 24 -or $image.Height -lt 24) { return $null }
        } finally { if ($image) { $image.Dispose() }; $stream.Dispose() }
        return [pscustomobject]@{ RasterPath=$path; OriginalPath=$path; Uri=$finalUri; Kind=$Candidate.Kind; Vector=$false }
    } catch { return $null }
}

function Get-LogoPalette([string]$Path) {
    $image = Get-LoadedBitmap $Path
    $buckets = @{}
    try {
        $step = [Math]::Max(1,[int]([Math]::Max($image.Width,$image.Height)/120))
        for ($y=0;$y-lt$image.Height;$y+=$step) {
            for ($x=0;$x-lt$image.Width;$x+=$step) {
                $pixel=$image.GetPixel($x,$y)
                if ($pixel.A-lt128) { continue }
                $max=[Math]::Max($pixel.R,[Math]::Max($pixel.G,$pixel.B));$min=[Math]::Min($pixel.R,[Math]::Min($pixel.G,$pixel.B))
                $brightness=($pixel.R+$pixel.G+$pixel.B)/3
                if (($max-$min)-lt22 -or $brightness-lt28 -or $brightness-gt232) { continue }
                $r=[int]([Math]::Floor($pixel.R/32)*32);$g=[int]([Math]::Floor($pixel.G/32)*32);$b=[int]([Math]::Floor($pixel.B/32)*32)
                $key='#{0:X2}{1:X2}{2:X2}' -f $r,$g,$b
                if($buckets.ContainsKey($key)){$buckets[$key]++}else{$buckets[$key]=1}
            }
        }
    } finally { $image.Dispose() }
    $palette=@($buckets.GetEnumerator()|Sort-Object Value -Descending|Select-Object -First 6|ForEach-Object{$_.Key})
    if(-not$palette.Count){$palette=@('#197782','#142926')}
    elseif($palette.Count-lt2){$palette+= '#142926'}
    return $palette
}

function Get-ContrastRatio([Drawing.Color]$A,[Drawing.Color]$B) {
    function Get-Luminance([Drawing.Color]$C) {
        $parts=@(([double]$C.R/255),([double]$C.G/255),([double]$C.B/255))|ForEach-Object{if($_-le.03928){$_/12.92}else{[Math]::Pow(($_+.055)/1.055,2.4)}}
        return .2126*$parts[0]+.7152*$parts[1]+.0722*$parts[2]
    }
    $aLum=Get-Luminance $A;$bLum=Get-Luminance $B
    return ([Math]::Max($aLum,$bLum)+.05)/([Math]::Min($aLum,$bLum)+.05)
}

function Get-WebsiteSupportInfo([string]$Html,[Uri]$BaseUri) {
    $email='';$phone='';$privacy='';$terms=''
    $emailMatch=[regex]::Match($Html,'(?i)mailto:([^"''?\s>]+)');if($emailMatch.Success){$email=[Net.WebUtility]::HtmlDecode($emailMatch.Groups[1].Value)}
    $phoneMatch=[regex]::Match($Html,'(?i)tel:([^"''?\s>]+)');if($phoneMatch.Success){$phone=[Net.WebUtility]::HtmlDecode($phoneMatch.Groups[1].Value)}
    foreach($anchor in [regex]::Matches($Html,'(?is)<a\b[^>]*>.*?</a>')){$href=Get-HtmlAttributeValue $anchor.Value 'href';if(-not$href){continue};$text=([regex]::Replace($anchor.Value,'<[^>]+>',' ')).Trim();$absolute=Get-AbsoluteCandidateUri $BaseUri $href;if(-not$absolute){continue};if(-not$privacy-and$text-match'(?i)privacy|privatliv|persondata'){$privacy=$absolute.AbsoluteUri};if(-not$terms-and$text-match'(?i)terms|vilkår|betingelser'){$terms=$absolute.AbsoluteUri}}
    return [pscustomobject]@{Email=$email;Phone=$phone;PrivacyUrl=$privacy;TermsUrl=$terms}
}

function Get-WebsiteAnalysis([string]$Website,[string]$CacheFolder) {
    $uri=Resolve-PublicUri $Website
    $response=Invoke-WebRequest -Uri $uri.AbsoluteUri -UseBasicParsing -TimeoutSec 25 -MaximumRedirection 5 -Headers @{'User-Agent'='Mozilla/5.0 PeakNet-Branding-Studio/2.0'}
    $finalUri=if($response.BaseResponse.ResponseUri){[Uri]$response.BaseResponse.ResponseUri}else{$uri}
    if(-not(Test-PublicWebUri $finalUri)){throw 'The website redirected to a local or private address.'}
    $html=[string]$response.Content
    if(Test-Path -LiteralPath $CacheFolder){Get-ChildItem -LiteralPath $CacheFolder -File -ErrorAction SilentlyContinue|Where-Object LastWriteTime -lt (Get-Date).AddDays(-2)|Remove-Item -Force -ErrorAction SilentlyContinue}
    New-Item -ItemType Directory -Force -Path $CacheFolder|Out-Null
    $candidates=Get-ImageCandidates $html $finalUri
    $logo=$null;$hero=$null;$index=0
    foreach($candidate in $candidates){$index++;$asset=Save-WebCandidate $candidate $CacheFolder $index;if(-not$asset){continue};if(-not$logo-and$candidate.Kind-in@('logo','icon')){$logo=$asset};if(-not$hero-and$candidate.Kind-eq'hero'){$hero=$asset};if($logo-and$hero){break}}
    $colors=@()
    if($logo){$colors=@(Get-LogoPalette $logo.RasterPath)}
    if(-not$colors.Count){foreach($m in [regex]::Matches($html,'(?i)#[0-9a-f]{6}\b')|ForEach-Object{$_.Value.ToUpperInvariant()}|Group-Object|Sort-Object Count -Descending|Select-Object -First 6){$colors+=$m.Name}}
    if(-not$colors.Count){$colors=@('#197782','#142926')};if($colors.Count-lt2){$colors+='#142926'}
    return [pscustomobject]@{Website=$finalUri.AbsoluteUri;LogoPath=if($logo){$logo.RasterPath}else{''};LogoOriginalPath=if($logo){$logo.OriginalPath}else{''};LogoUri=if($logo){$logo.Uri.AbsoluteUri}else{''};HeroPath=if($hero){$hero.RasterPath}else{''};Colors=@($colors);Support=(Get-WebsiteSupportInfo $html $finalUri);CandidateCount=$candidates.Count;VectorLogo=[bool]($logo-and$logo.Vector)}
}

function New-TransparentLogoCanvas([int]$Width,[int]$Height,[Drawing.Image]$Logo,[float]$PaddingRatio=.03,[Drawing.Color]$Background=[Drawing.Color]::Transparent) {
    $scale=if([Math]::Max($Width,$Height)-le512){3}else{1};$large=[Drawing.Bitmap]::new($Width*$scale,$Height*$scale,[Drawing.Imaging.PixelFormat]::Format32bppArgb);$g=[Drawing.Graphics]::FromImage($large)
    try{$g.Clear($Background);$g.SmoothingMode='AntiAlias';$g.InterpolationMode='HighQualityBicubic';$g.PixelOffsetMode='HighQuality';$g.CompositingQuality='HighQuality';Draw-ImageContained $g $Logo ([Drawing.RectangleF]::new(0,0,$large.Width,$large.Height)) ([float]([Math]::Min($large.Width,$large.Height)*$PaddingRatio))}finally{$g.Dispose()}
    if($scale-eq1){return $large};$result=[Drawing.Bitmap]::new($Width,$Height,[Drawing.Imaging.PixelFormat]::Format32bppArgb);$rg=[Drawing.Graphics]::FromImage($result);try{$rg.InterpolationMode='HighQualityBicubic';$rg.PixelOffsetMode='HighQuality';$rg.CompositingQuality='HighQuality';$rg.DrawImage($large,0,0,$Width,$Height)}finally{$rg.Dispose();$large.Dispose()};return $result
}

function New-SymbolWordmark([Drawing.Image]$Symbol,[string]$BrandName,[Drawing.Color]$TextColor) {
    if(($Symbol.Width/$Symbol.Height)-gt1.35 -or [string]::IsNullOrWhiteSpace($BrandName)){return $null}
    $bitmap=[Drawing.Bitmap]::new(1400,320,[Drawing.Imaging.PixelFormat]::Format32bppArgb);$graphics=[Drawing.Graphics]::FromImage($bitmap)
    try{$graphics.Clear([Drawing.Color]::Transparent);$graphics.SmoothingMode='AntiAlias';$graphics.InterpolationMode='HighQualityBicubic';Draw-ImageContained $graphics $Symbol ([Drawing.RectangleF]::new(24,24,272,272)) 8;$fontSize=112.0;$font=$null;do{if($font){$font.Dispose()};$font=[Drawing.Font]::new('Segoe UI Semibold',$fontSize,[Drawing.FontStyle]::Regular,[Drawing.GraphicsUnit]::Pixel);$size=$graphics.MeasureString($BrandName,$font);$fontSize-=4}while($size.Width-gt1040-and$fontSize-gt44);$brush=[Drawing.SolidBrush]::new($TextColor);try{$graphics.DrawString($BrandName,$font,$brush,326,[float]((320-$size.Height)/2))}finally{$brush.Dispose();$font.Dispose()}}finally{$graphics.Dispose()};return $bitmap
}

function Draw-ImageCover([Drawing.Graphics]$Graphics,[Drawing.Image]$Image,[Drawing.RectangleF]$Bounds) {
    $scale=[Math]::Max($Bounds.Width/$Image.Width,$Bounds.Height/$Image.Height);$w=[float]($Image.Width*$scale);$h=[float]($Image.Height*$scale);$x=[float]($Bounds.X+($Bounds.Width-$w)/2);$y=[float]($Bounds.Y+($Bounds.Height-$h)/2);$Graphics.DrawImage($Image,[Drawing.RectangleF]::new($x,$y,$w,$h))
}

function New-DesignBackground([int]$Width,[int]$Height,[Drawing.Color]$Primary,[Drawing.Color]$Secondary,[Drawing.Image]$Logo,[string]$Style,[Drawing.Image]$Hero=$null) {
    $bitmap=[Drawing.Bitmap]::new($Width,$Height,[Drawing.Imaging.PixelFormat]::Format24bppRgb);$g=[Drawing.Graphics]::FromImage($bitmap);$g.SmoothingMode='AntiAlias';$g.InterpolationMode='HighQualityBicubic'
    try{
        if($Style-eq'Clean Corporate'){$g.Clear([Drawing.ColorTranslator]::FromHtml('#F4F5F2'));$rail=[Drawing.SolidBrush]::new($Primary);$g.FillRectangle($rail,[int]($Width*.72),0,[int]($Width*.28),$Height);$rail.Dispose();$panel=[Drawing.RectangleF]::new($Width*.75,$Height*.67,$Width*.21,$Height*.20);$card=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(235,255,255,255));$g.FillRectangle($card,$panel);$card.Dispose();Draw-ImageContained $g $Logo $panel 16}
        elseif($Style-eq'Photo & Brand'){
            if($Hero){Draw-ImageCover $g $Hero ([Drawing.RectangleF]::new(0,0,$Width,$Height))}else{$g.Clear($Secondary);$shape=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(210,$Primary));$g.FillEllipse($shape,[int]($Width*.42),[int](-$Height*.25),[int]($Width*.78),[int]($Width*.78));$shape.Dispose()}
            $overlay=[Drawing.Drawing2D.LinearGradientBrush]::new([Drawing.Rectangle]::new(0,0,$Width,$Height),[Drawing.Color]::FromArgb(220,$Secondary),[Drawing.Color]::FromArgb(35,$Primary),0.0);$g.FillRectangle($overlay,0,0,$Width,$Height);$overlay.Dispose();$panel=[Drawing.RectangleF]::new($Width*.68,$Height*.70,$Width*.26,$Height*.18);$card=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(230,255,255,255));$g.FillRectangle($card,$panel);$card.Dispose();Draw-ImageContained $g $Logo $panel 16
        }
        else{$gradient=[Drawing.Drawing2D.LinearGradientBrush]::new([Drawing.Rectangle]::new(0,0,$Width,$Height),$Secondary,$Primary,18.0);$g.FillRectangle($gradient,0,0,$Width,$Height);$gradient.Dispose();$soft=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(30,255,255,255));$g.FillEllipse($soft,[int]($Width*.55),[int](-$Height*.35),[int]($Width*.75),[int]($Width*.75));$g.FillEllipse($soft,[int](-$Width*.22),[int]($Height*.55),[int]($Width*.62),[int]($Width*.62));$soft.Dispose();$panel=[Drawing.RectangleF]::new($Width*.68,$Height*.70,$Width*.26,$Height*.18);$card=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(230,255,255,255));$g.FillRectangle($card,$panel);$card.Dispose();Draw-ImageContained $g $Logo $panel 16}
    }finally{$g.Dispose()};return $bitmap
}

function New-ExperiencePreview([Drawing.Bitmap]$Background,[Drawing.Image]$Logo,[string]$Type,[string]$Path,[Drawing.Color]$Primary) {
    $w=1200;$h=675;$bmp=[Drawing.Bitmap]::new($w,$h,[Drawing.Imaging.PixelFormat]::Format24bppRgb);$g=[Drawing.Graphics]::FromImage($bmp);$g.SmoothingMode='AntiAlias';$g.InterpolationMode='HighQualityBicubic'
    try{
        if($Type-eq'Entra Desktop'){Draw-ImageCover $g $Background ([Drawing.RectangleF]::new(0,0,$w,$h));$shadow=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(40,0,0,0));$g.FillRectangle($shadow,738,118,372,430);$shadow.Dispose();$g.FillRectangle([Drawing.Brushes]::White,724,104,372,430);Draw-ImageContained $g $Logo ([Drawing.RectangleF]::new(770,145,280,65)) 4;$font=[Drawing.Font]::new('Segoe UI',20);$small=[Drawing.Font]::new('Segoe UI',12);$g.DrawString('Sign in',$font,[Drawing.Brushes]::Black,770,235);$g.DrawString('Email, phone, or Skype',$small,[Drawing.Brushes]::DimGray,770,287);$g.DrawLine([Drawing.Pens]::Gray,770,320,1045,320);$font.Dispose();$small.Dispose()}
        elseif($Type-eq'Entra Mobile'){Draw-ImageCover $g $Background ([Drawing.RectangleF]::new(0,0,$w,$h));$shade=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(110,0,0,0));$g.FillRectangle($shade,0,0,$w,$h);$shade.Dispose();$g.FillRectangle([Drawing.Brushes]::White,420,65,360,545);Draw-ImageContained $g $Logo ([Drawing.RectangleF]::new(465,120,270,70)) 4}
        elseif($Type-eq'Microsoft 365 Header'){$g.Clear([Drawing.ColorTranslator]::FromHtml('#F5F5F5'));$bar=[Drawing.SolidBrush]::new($Primary);$g.FillRectangle($bar,0,0,$w,86);$bar.Dispose();Draw-ImageContained $g $Logo ([Drawing.RectangleF]::new(24,16,300,52)) 2;$font=[Drawing.Font]::new('Segoe UI',28);$g.DrawString('Microsoft 365',$font,[Drawing.Brushes]::Black,40,150);$font.Dispose()}
        else{Draw-ImageCover $g $Background ([Drawing.RectangleF]::new(0,0,$w,$h));$card=[Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(235,255,255,255));$g.FillRectangle($card,65,72,430,530);$card.Dispose();Draw-ImageContained $g $Logo ([Drawing.RectangleF]::new(110,120,340,100)) 6}
        $bmp.Save($Path,[Drawing.Imaging.ImageFormat]::Jpeg)
    }finally{$g.Dispose();$bmp.Dispose()}
    return $Path
}

function Get-ImageQualityRows([string[]]$Files,[string]$LogoSource,[string[]]$Colors) {
    $rows=[Collections.Generic.List[object]]::new()
    foreach($file in $Files){$item=Get-Item -LiteralPath $file;$stream=[IO.File]::OpenRead($file);$img=$null;try{$img=[Drawing.Image]::FromStream($stream);$status='Pass';$note='Correctly generated';if($img.Width-lt32-or$img.Height-lt32){$status='Review';$note='Very small image'};$rows.Add([pscustomobject]@{File=$item.Name;Width=$img.Width;Height=$img.Height;Bytes=$item.Length;Status=$status;Note=$note})}finally{if($img){$img.Dispose()};$stream.Dispose()}}
    $source=Get-LoadedBitmap $LogoSource;try{$sourceInfo="$($source.Width) x $($source.Height)"}finally{$source.Dispose()}
    $primary=Convert-HexColor $Colors[0];$white=[Drawing.Color]::White;$black=[Drawing.Color]::Black
    return [pscustomobject]@{Rows=@($rows);SourceResolution=$sourceInfo;ContrastWhite=[Math]::Round((Get-ContrastRatio $primary $white),2);ContrastBlack=[Math]::Round((Get-ContrastRatio $primary $black),2)}
}

function Write-QualityReport([string]$Folder,$Quality,[string]$BrandName,[string]$Website,[string[]]$PreviewFiles) {
    $rows=($Quality.Rows|ForEach-Object{"<tr><td>$([Net.WebUtility]::HtmlEncode($_.File))</td><td>$($_.Width) × $($_.Height)</td><td>$([Math]::Round($_.Bytes/1KB,1)) KB</td><td class='$($_.Status.ToLower())'>$($_.Status)</td><td>$($_.Note)</td></tr>"})-join"`n"
    $previews=($PreviewFiles|ForEach-Object{"<figure><img src='$([Uri]::EscapeDataString([IO.Path]::GetFileName($_)))'><figcaption>$([Net.WebUtility]::HtmlEncode([IO.Path]::GetFileNameWithoutExtension($_)))</figcaption></figure>"})-join"`n"
    $html=@"
<!doctype html><html><head><meta charset="utf-8"><title>Brand QA - $([Net.WebUtility]::HtmlEncode($BrandName))</title><style>body{font-family:Segoe UI,Arial;background:#f4f5f2;color:#142926;margin:40px}header,section{background:white;border:1px solid #d8dfdc;border-radius:14px;padding:24px;margin-bottom:20px}h1{margin-top:0}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.grid img{width:100%;border-radius:9px}.pass{color:#177245;font-weight:700}.review{color:#b06000;font-weight:700}table{width:100%;border-collapse:collapse}th,td{text-align:left;padding:10px;border-bottom:1px solid #e4e9e7}small{color:#60706d}</style></head><body><header><h1>$([Net.WebUtility]::HtmlEncode($BrandName)) brand quality report</h1><p>$([Net.WebUtility]::HtmlEncode($Website))</p><p>Source logo: $($Quality.SourceResolution) · Contrast on white: $($Quality.ContrastWhite):1 · Contrast on black: $($Quality.ContrastBlack):1</p></header><section><h2>Experience previews</h2><div class="grid">$previews</div></section><section><h2>Generated files</h2><table><thead><tr><th>File</th><th>Dimensions</th><th>Size</th><th>Status</th><th>Note</th></tr></thead><tbody>$rows</tbody></table><p><small>Preview and obtain customer approval before publishing. A 4.5:1 contrast ratio is recommended for text and icons.</small></p></section></body></html>
"@
    $path=Join-Path $Folder 'Quality report.html';$html|Set-Content -LiteralPath $path -Encoding UTF8;return $path
}

function New-BrandingPackV2([string]$CustomerFolder,[string]$BrandName,[string]$Website,[string]$LogoPath,[string]$LogoOriginalPath,[string]$HeroPath,[string[]]$Colors,[string]$SelectedStyle,$Support) {
    if(-not(Test-Path -LiteralPath $LogoPath)){throw 'A valid logo is required.'}
    $brandingRoot=Join-Path $CustomerFolder 'Microsoft 365 Branding';$stamp=Get-Date -Format 'yyyy-MM-dd_HHmmss';$draftRoot=Join-Path (Join-Path $brandingRoot 'Drafts') $stamp;$pack=Join-Path (Join-Path $draftRoot $SelectedStyle) 'Ready to upload';$source=Join-Path $brandingRoot 'Source';$previewFolder=Join-Path $draftRoot 'Previews';New-Item -ItemType Directory -Force -Path $pack,$source,$previewFolder|Out-Null
    $sourceLogo=Get-LoadedBitmap $LogoPath;$hero=$null;if($HeroPath-and(Test-Path -LiteralPath $HeroPath)){try{$hero=Get-LoadedBitmap $HeroPath}catch{}}
    $primary=Convert-HexColor $Colors[0];$secondary=if($Colors.Count-gt1){Convert-HexColor $Colors[1] '#142926'}else{Get-DarkerColor $primary};if($primary.GetBrightness()-lt.14){$primary=Convert-HexColor '#197782'}
    $wordmark=New-SymbolWordmark $sourceLogo $BrandName $secondary;$logo=if($wordmark){$wordmark}else{$sourceLogo}
    $styles=@('Clean Corporate','Brand Gradient','Photo & Brand')
    $proposalFiles=[Collections.Generic.List[string]]::new();foreach($style in $styles){$proposal=New-DesignBackground 1200 675 $primary $secondary $logo $style $hero;try{$path=Join-Path $previewFolder (('Proposal - '+$style+'.jpg')-replace'[\\/:*?"<>|]','-');$proposal.Save($path,[Drawing.Imaging.ImageFormat]::Jpeg);$proposalFiles.Add($path)}finally{$proposal.Dispose()}}
    $generated=[Collections.Generic.List[string]]::new()
    try{
        $background=New-DesignBackground 1920 1080 $primary $secondary $logo $SelectedStyle $hero;try{$generated.Add((Save-JpegWithinLimit $background (Join-Path $pack '01-Entra-SignIn-Background-1920x1080.jpg') 300KB 94));$generated.Add((Save-JpegWithinLimit $background (Join-Path $pack '06-Desktop-Wallpaper-1920x1080.jpg') 0 95));$intune=[Drawing.Bitmap]::new(1600,900);$ig=[Drawing.Graphics]::FromImage($intune);try{$ig.InterpolationMode='HighQualityBicubic';$ig.DrawImage($background,0,0,1600,900)}finally{$ig.Dispose()};try{$generated.Add((Save-JpegWithinLimit $intune (Join-Path $pack '07-Intune-Brand-Image-1600x900.jpg') 1300KB 94))}finally{$intune.Dispose()}
            $previewTypes=@('Entra Desktop','Entra Mobile','Microsoft 365 Header','Intune Company Portal');$experience=[Collections.Generic.List[string]]::new();foreach($type in $previewTypes){$path=Join-Path $pack ('Preview - '+$type+'.jpg');$experience.Add((New-ExperiencePreview $background $logo $type $path $primary))}
        }finally{$background.Dispose()}
        foreach($spec in @(@('02-Entra-Banner-Logo-245x36',245,36,50KB),@('03-Entra-Square-Logo-Light-240x240',240,240,10KB),@('04-Entra-Square-Logo-Dark-240x240',240,240,10KB),@('05-Entra-Favicon-32x32',32,32,5KB),@('08-Intune-Logo-Light-512x128',512,128,750KB),@('09-Intune-Logo-Dark-512x128',512,128,750KB),@('10-M365-Header-Logo-Light-200x48',200,48,10KB),@('11-M365-Header-Logo-Dark-200x48',200,48,10KB),@('12-Copilot-Footer-Logo-200x48',200,48,10KB))){$assetLogo=if(([string]$spec[0])-match'^(03|04|05)-'){$sourceLogo}else{$logo};$canvas=New-TransparentLogoCanvas ([int]$spec[1]) ([int]$spec[2]) $assetLogo .02;try{$generated.Add((Save-LogoWithinLimit $canvas (Join-Path $pack ([string]$spec[0])) ([int64]$spec[3])))}finally{$canvas.Dispose()}}
    }finally{if($wordmark){$wordmark.Dispose()};$sourceLogo.Dispose();if($hero){$hero.Dispose()}}
    $original=if($LogoOriginalPath-and(Test-Path -LiteralPath $LogoOriginalPath)){$LogoOriginalPath}else{$LogoPath};$ext=[IO.Path]::GetExtension($original);if(-not$ext){$ext='.png'};Copy-Item -LiteralPath $original -Destination (Join-Path $source ('original-logo'+$ext)) -Force;Copy-Item -LiteralPath $LogoPath -Destination (Join-Path $source 'normalized-logo.png') -Force
    $brandKit=[ordered]@{customer=$BrandName;website=$Website;palette=@($Colors);support=$Support;selectedStyle=$SelectedStyle;generatedWordmarkFromSymbol=[bool]$wordmark;generatedUtc=[DateTime]::UtcNow.ToString('o');generator='PeakNet Branding Studio 2.0'};$brandKit|ConvertTo-Json -Depth 6|Set-Content -LiteralPath (Join-Path $brandingRoot 'brand-kit.json') -Encoding UTF8
    [ordered]@{locale='da-DK';signInPageText="Har du problemer med at logge ind? Kontakt $($Support.Email) $($Support.Phone)";privacyUrl=$Support.PrivacyUrl;termsUrl=$Support.TermsUrl}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $pack 'localization-da-DK.json') -Encoding UTF8
    [ordered]@{locale='en-US';signInPageText="Need help signing in? Contact $($Support.Email) $($Support.Phone)";privacyUrl=$Support.PrivacyUrl;termsUrl=$Support.TermsUrl}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $pack 'localization-en-US.json') -Encoding UTF8
    $quality=Get-ImageQualityRows @($generated) $LogoPath $Colors;$report=Write-QualityReport $pack $quality $BrandName $Website @($experience)
    @("PeakNet branding pack for $BrandName","Design: $SelectedStyle","Website: $Website","Primary: $($Colors[0])","Secondary: $($Colors[1])",'',"This is a draft. Use 'Approve selected design' before publishing.",'Review Quality report.html and all previews.','Transparent PNG files are preferred. Square logos are compressed to the stricter 10 KB Graph limit.')|Set-Content -LiteralPath (Join-Path $pack 'README - review and upload.txt') -Encoding UTF8
    return [pscustomobject]@{DraftRoot=$draftRoot;Folder=$pack;Files=@($generated);PreviewFiles=@($experience);ProposalFiles=@($proposalFiles);Report=$report;Style=$SelectedStyle;Quality=$quality}
}

function Approve-BrandingPack([string]$CustomerFolder,$Result) {
    $root=Join-Path $CustomerFolder 'Microsoft 365 Branding';$stamp=Get-Date -Format 'yyyy-MM-dd_HHmmss';$approved=Join-Path (Join-Path $root 'Approved') $stamp;$ready=Join-Path $root 'Ready to upload';New-Item -ItemType Directory -Force -Path $approved|Out-Null
    Get-ChildItem -LiteralPath $Result.Folder -Force | Copy-Item -Destination $approved -Recurse -Force
    if(Test-Path -LiteralPath $ready){$history=Join-Path (Join-Path $root 'History') $stamp;New-Item -ItemType Directory -Force -Path $history|Out-Null;Get-ChildItem -LiteralPath $ready -Force | Copy-Item -Destination $history -Recurse -Force}
    New-Item -ItemType Directory -Force -Path $ready|Out-Null;Get-ChildItem -LiteralPath $Result.Folder -Force | Copy-Item -Destination $ready -Recurse -Force
    [ordered]@{approvedUtc=[DateTime]::UtcNow.ToString('o');style=$Result.Style;sourceDraft=$Result.Folder}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $ready 'approval.json') -Encoding UTF8
    return $ready
}

function New-SecureRandomBytesV2([int]$Count){$bytes=New-Object byte[] $Count;$rng=[Security.Cryptography.RandomNumberGenerator]::Create();try{$rng.GetBytes($bytes)}finally{$rng.Dispose()};return $bytes}
function ConvertTo-Base64UrlV2([byte[]]$Bytes){return [Convert]::ToBase64String($Bytes).TrimEnd('=').Replace('+','-').Replace('/','_')}
function ConvertFrom-QueryStringV2([string]$Query){$values=@{};foreach($pair in $Query.TrimStart('?').Split('&',[StringSplitOptions]::RemoveEmptyEntries)){$parts=$pair.Split('=',2);$key=[Uri]::UnescapeDataString($parts[0].Replace('+',' '));$value=if($parts.Count-gt1){[Uri]::UnescapeDataString($parts[1].Replace('+',' '))}else{''};$values[$key]=$value};return $values}

function Connect-BrandingGraph([string]$TenantId,[string]$ClientId) {
    if($TenantId-notmatch'^(?:[0-9a-fA-F-]{36}|[a-zA-Z0-9][a-zA-Z0-9.-]+\.[a-zA-Z]{2,})$'){throw 'The selected customer does not have a valid Tenant ID or verified domain.'};if($ClientId-notmatch'^[0-9a-fA-F-]{36}$'){throw 'The PeakNet public-client Application ID is missing.'}
    $random=New-SecureRandomBytesV2 48;$verifier=ConvertTo-Base64UrlV2 $random;$sha=[Security.Cryptography.SHA256]::Create();try{$challenge=ConvertTo-Base64UrlV2($sha.ComputeHash([Text.Encoding]::ASCII.GetBytes($verifier)))}finally{$sha.Dispose()};$state=ConvertTo-Base64UrlV2(New-SecureRandomBytesV2 24)
    $listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$listener.Start();$port=([Net.IPEndPoint]$listener.LocalEndpoint).Port;$redirect="http://localhost:$port/";$scope='openid profile User.Read OrganizationalBranding.ReadWrite.All';$authorize='https://login.microsoftonline.com/{0}/oauth2/v2.0/authorize?client_id={1}&response_type=code&redirect_uri={2}&response_mode=query&scope={3}&state={4}&code_challenge={5}&code_challenge_method=S256&prompt=select_account' -f[Uri]::EscapeDataString($TenantId),[Uri]::EscapeDataString($ClientId),[Uri]::EscapeDataString($redirect),[Uri]::EscapeDataString($scope),[Uri]::EscapeDataString($state),[Uri]::EscapeDataString($challenge)
    $client=$null;$stream=$null;$reader=$null;try{Start-Process $authorize|Out-Null;$deadline=[DateTime]::UtcNow.AddMinutes(4);while(-not$listener.Pending()-and[DateTime]::UtcNow-lt$deadline){[Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 100};if(-not$listener.Pending()){throw 'Microsoft sign-in timed out.'};$client=$listener.AcceptTcpClient();$stream=$client.GetStream();$reader=[IO.StreamReader]::new($stream,[Text.Encoding]::ASCII,$false,1024,$true);$line=$reader.ReadLine();while(-not[string]::IsNullOrEmpty($reader.ReadLine())){};if($line-notmatch'^GET\s+([^\s]+)\s+HTTP/'){throw 'Invalid authentication callback.'};$callback=[Uri]("http://localhost:$port"+$Matches[1]);$query=ConvertFrom-QueryStringV2 $callback.Query;$ok=$query.ContainsKey('code')-and$query.ContainsKey('state')-and$query['state']-eq$state;$body=if($ok){'<h2>PeakNet Branding Studio connected</h2><p>Return to the app.</p>'}else{'<h2>Connection failed</h2>'};$bytes=[Text.Encoding]::UTF8.GetBytes($body);$header=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 200 OK`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`n`r`n");$stream.Write($header,0,$header.Length);$stream.Write($bytes,0,$bytes.Length);$stream.Flush();if($query.ContainsKey('error')){throw "Microsoft sign-in failed: $($query['error_description'])"};if(-not$ok){throw 'Invalid sign-in response.'};$code=[string]$query['code']}finally{if($reader){$reader.Dispose()};if($stream){$stream.Dispose()};if($client){$client.Dispose()};$listener.Stop()}
    $token=Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token" -ContentType 'application/x-www-form-urlencoded' -Body @{client_id=$ClientId;grant_type='authorization_code';code=$code;redirect_uri=$redirect;scope=$scope;code_verifier=$verifier};$authHeaders=@{Authorization="Bearer $($token.access_token)"};$me=Invoke-RestMethod -Uri 'https://graph.microsoft.com/v1.0/me?$select=displayName,userPrincipalName' -Headers $authHeaders;$organization=Invoke-RestMethod -Uri 'https://graph.microsoft.com/v1.0/organization?$select=id,displayName' -Headers $authHeaders;$organizationId=[string](@($organization.value)[0].id);if(-not$organizationId){throw 'Microsoft Graph did not return the customer organization.'};return [pscustomobject]@{AccessToken=[string]$token.access_token;Account=[string]$me.userPrincipalName;TenantId=$TenantId;OrganizationId=$organizationId;OrganizationName=[string](@($organization.value)[0].displayName)}
}

function Backup-EntraBranding($Connection,[string]$CustomerFolder) {
    $stamp=Get-Date -Format 'yyyy-MM-dd_HHmmss';$folder=Join-Path (Join-Path (Join-Path $CustomerFolder 'Microsoft 365 Branding') 'Microsoft backups') $stamp;New-Item -ItemType Directory -Force -Path $folder|Out-Null;$headers=@{Authorization="Bearer $($Connection.AccessToken)"}
    try{Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/organization/$($Connection.OrganizationId)/branding" -Headers $headers|ConvertTo-Json -Depth 12|Set-Content -LiteralPath (Join-Path $folder 'branding.json') -Encoding UTF8}catch{throw "Could not back up current branding: $($_.Exception.Message)"}
    foreach($asset in @('backgroundImage','bannerLogo','squareLogo','squareLogoDark','favicon','headerLogo')){try{Invoke-WebRequest -Uri "https://graph.microsoft.com/v1.0/organization/$($Connection.OrganizationId)/branding/localizations/0/$asset" -Headers $headers -OutFile (Join-Path $folder($asset+'.bin')) -UseBasicParsing}catch{}}
    return $folder
}

function Publish-EntraBranding($Connection,[string]$ApprovedFolder,[string]$CustomerFolder,[string]$BackgroundColor,[string]$SignInText='') {
    if(-not(Test-Path -LiteralPath (Join-Path $ApprovedFolder 'approval.json'))){throw 'Only an approved branding pack can be published.'};$backup=Backup-EntraBranding $Connection $CustomerFolder;$headers=@{Authorization="Bearer $($Connection.AccessToken)";'Accept-Language'='0'}
    $mapping=[ordered]@{backgroundImage='01-Entra-SignIn-Background-1920x1080.jpg';bannerLogo='02-Entra-Banner-Logo-245x36';squareLogo='03-Entra-Square-Logo-Light-240x240';squareLogoDark='04-Entra-Square-Logo-Dark-240x240';favicon='05-Entra-Favicon-32x32'}
    foreach($entry in $mapping.GetEnumerator()){$file=Get-ChildItem -LiteralPath $ApprovedFolder -File|Where-Object { $_.BaseName -eq $entry.Value }|Select-Object -First 1;if(-not$file){continue};$contentType=if($file.Extension-eq'.png'){'image/png'}else{'image/jpeg'};Invoke-RestMethod -Method Put -Uri "https://graph.microsoft.com/v1.0/organization/$($Connection.OrganizationId)/branding/localizations/0/$($entry.Key)" -Headers $headers -ContentType $contentType -InFile $file.FullName|Out-Null}
    $body=[ordered]@{backgroundColor=$BackgroundColor};if($SignInText){$body.signInPageText=$SignInText};Invoke-RestMethod -Method Patch -Uri "https://graph.microsoft.com/v1.0/organization/$($Connection.OrganizationId)/branding" -Headers $headers -ContentType 'application/json' -Body ($body|ConvertTo-Json)|Out-Null
    return $backup
}
