[CmdletBinding()]
param(
    [string]$CustomerName = '',
    [string]$TenantId = '',
    [string]$ClientsRoot = (Join-Path $env:USERPROFILE 'PEAKNET\PEAKNET Security - Dokumenter\Clients')
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

function ConvertTo-SafeFolderName([string]$Value) {
    $invalid = [IO.Path]::GetInvalidFileNameChars()
    $result = $Value
    foreach ($character in $invalid) { $result = $result.Replace([string]$character, '_') }
    return $result.Trim().TrimEnd('.')
}

function ConvertTo-NormalizedName([string]$Value) {
    return (($Value -replace '[^a-zA-Z0-9]', '').ToLowerInvariant())
}

function Find-CustomerFolder([string]$Name) {
    if (-not (Test-Path -LiteralPath $ClientsRoot)) { return (Join-Path $ClientsRoot (ConvertTo-SafeFolderName $Name)) }
    $directories = @(Get-ChildItem -LiteralPath $ClientsRoot -Directory -ErrorAction SilentlyContinue)
    if (-not $directories.Count) { return (Join-Path $ClientsRoot (ConvertTo-SafeFolderName $Name)) }
    $normalized = ConvertTo-NormalizedName $Name
    $exact = $directories | Where-Object { (ConvertTo-NormalizedName $_.Name) -eq $normalized } | Select-Object -First 1
    if ($exact) { return $exact.FullName }
    $partial = $directories | Where-Object {
        $candidate = ConvertTo-NormalizedName $_.Name
        $candidate.Contains($normalized) -or $normalized.Contains($candidate)
    } | Sort-Object { [Math]::Abs($_.Name.Length - $Name.Length) } | Select-Object -First 1
    if ($partial) { return $partial.FullName }
    return (Join-Path $ClientsRoot (ConvertTo-SafeFolderName $Name))
}

function Test-PublicWebUri([Uri]$Uri) {
    if (-not $Uri.IsAbsoluteUri -or $Uri.Scheme -notin @('http','https')) { return $false }
    if ($Uri.Host -match '^(localhost|.+\.local)$') { return $false }
    $parsedIp = $null
    if ([Net.IPAddress]::TryParse($Uri.Host, [ref]$parsedIp)) { $addresses = @($parsedIp) }
    else {
        try { $addresses = @([Net.Dns]::GetHostAddresses($Uri.DnsSafeHost)) } catch { return $false }
    }
    foreach ($address in $addresses) {
        if ([Net.IPAddress]::IsLoopback($address)) { return $false }
        $bytes = $address.GetAddressBytes()
        if ($address.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetwork) {
            if ($bytes[0] -eq 10 -or $bytes[0] -eq 127 -or ($bytes[0] -eq 169 -and $bytes[1] -eq 254) -or ($bytes[0] -eq 172 -and $bytes[1] -ge 16 -and $bytes[1] -le 31) -or ($bytes[0] -eq 192 -and $bytes[1] -eq 168)) { return $false }
        } elseif ($address.AddressFamily -eq [Net.Sockets.AddressFamily]::InterNetworkV6) {
            if ($address.IsIPv6LinkLocal -or $address.IsIPv6SiteLocal -or $bytes[0] -eq 0xFC -or $bytes[0] -eq 0xFD) { return $false }
        }
    }
    return $true
}

function Resolve-PublicUri([string]$Value) {
    $text = $Value.Trim()
    if ($text -notmatch '^https?://') { $text = 'https://' + $text }
    $uri = [Uri]$text
    if (-not (Test-PublicWebUri $uri)) { throw 'Enter a public HTTP or HTTPS customer website. Local and private network addresses are blocked.' }
    return $uri
}

function Get-AbsoluteCandidateUri([Uri]$BaseUri, [string]$Candidate) {
    if ([string]::IsNullOrWhiteSpace($Candidate) -or $Candidate.StartsWith('data:', [StringComparison]::OrdinalIgnoreCase)) { return $null }
    try {
        $decoded = [Net.WebUtility]::HtmlDecode($Candidate.Trim())
        return [Uri]::new($BaseUri, $decoded)
    } catch { return $null }
}

function Get-HtmlAttributeValue([string]$Tag, [string]$Attribute) {
    $match = [regex]::Match($Tag, '(?is)\b' + [regex]::Escape($Attribute) + '\s*=\s*["'']([^"'']+)["'']')
    if ($match.Success) { return [Net.WebUtility]::HtmlDecode($match.Groups[1].Value) }
    return ''
}

function Get-WebsiteAnalysis([string]$Website, [string]$CacheFolder) {
    $uri = Resolve-PublicUri $Website
    $response = Invoke-WebRequest -Uri $uri.AbsoluteUri -UseBasicParsing -TimeoutSec 20 -MaximumRedirection 5 -Headers @{ 'User-Agent'='Mozilla/5.0 PeakNet-Branding-Studio/1.0' }
    $finalUri = if ($response.BaseResponse.ResponseUri) { [Uri]$response.BaseResponse.ResponseUri } else { $uri }
    if (-not (Test-PublicWebUri $finalUri)) { throw 'The website redirected to a local or private address, so the request was blocked.' }
    $html = [string]$response.Content

    $candidates = [Collections.Generic.List[Uri]]::new()
    foreach ($tagMatch in [regex]::Matches($html, '(?is)<img\b[^>]*>')) {
        $tag = $tagMatch.Value
        $descriptor = (Get-HtmlAttributeValue $tag 'alt') + ' ' + (Get-HtmlAttributeValue $tag 'class') + ' ' + (Get-HtmlAttributeValue $tag 'id')
        if ($descriptor -match '(?i)logo|brand') {
            $candidate = Get-AbsoluteCandidateUri $finalUri (Get-HtmlAttributeValue $tag 'src')
            if ($candidate) { $candidates.Add($candidate) }
        }
    }
    foreach ($tagMatch in [regex]::Matches($html, '(?is)<meta\b[^>]*>')) {
        $tag = $tagMatch.Value
        $property = (Get-HtmlAttributeValue $tag 'property') + ' ' + (Get-HtmlAttributeValue $tag 'name')
        if ($property -match '(?i)og:image|twitter:image|logo') {
            $candidate = Get-AbsoluteCandidateUri $finalUri (Get-HtmlAttributeValue $tag 'content')
            if ($candidate) { $candidates.Add($candidate) }
        }
    }
    foreach ($tagMatch in [regex]::Matches($html, '(?is)<link\b[^>]*>')) {
        $tag = $tagMatch.Value
        if ((Get-HtmlAttributeValue $tag 'rel') -match '(?i)icon') {
            $candidate = Get-AbsoluteCandidateUri $finalUri (Get-HtmlAttributeValue $tag 'href')
            if ($candidate) { $candidates.Add($candidate) }
        }
    }
    $candidates.Add([Uri]::new($finalUri, '/favicon.ico'))

    New-Item -ItemType Directory -Force -Path $CacheFolder | Out-Null
    $logoPath = $null
    $candidateIndex = 0
    foreach ($candidate in @($candidates | Select-Object -Unique)) {
        $candidateIndex++
        if (-not (Test-PublicWebUri $candidate)) { continue }
        $temporary = Join-Path $CacheFolder ("candidate-{0}.img" -f $candidateIndex)
        try {
            $imageResponse = Invoke-WebRequest -Uri $candidate.AbsoluteUri -UseBasicParsing -TimeoutSec 15 -MaximumRedirection 4 -OutFile $temporary -PassThru -Headers @{ 'User-Agent'='Mozilla/5.0 PeakNet-Branding-Studio/1.0'; 'Referer'=$finalUri.AbsoluteUri }
            $downloadedUri = if ($imageResponse.BaseResponse.ResponseUri) { [Uri]$imageResponse.BaseResponse.ResponseUri } else { $candidate }
            if (-not (Test-PublicWebUri $downloadedUri)) { continue }
            if (-not (Test-Path -LiteralPath $temporary)) { continue }
            $downloadedLength = (Get-Item -LiteralPath $temporary).Length
            if ($downloadedLength -lt 32 -or $downloadedLength -gt 8MB) { continue }
            $contentType = [string]$imageResponse.Headers['Content-Type']
            if ($contentType -match 'svg') { continue }
            $stream = [IO.File]::OpenRead($temporary)
            $image = $null
            try {
                $image = [Drawing.Image]::FromStream($stream, $true, $true)
                if ($image.Width -lt 24 -or $image.Height -lt 24) { continue }
                $logoPath = $temporary
                break
            } finally {
                if ($image) { $image.Dispose() }
                $stream.Dispose()
            }
        } catch { continue }
        finally {
            if ($temporary -ne $logoPath -and (Test-Path -LiteralPath $temporary)) {
                Remove-Item -LiteralPath $temporary -Force -ErrorAction SilentlyContinue
            }
        }
    }

    $colors = [Collections.Generic.List[string]]::new()
    foreach ($tagMatch in [regex]::Matches($html, '(?is)<meta\b[^>]*>')) {
        $tag = $tagMatch.Value
        if ((Get-HtmlAttributeValue $tag 'name') -match '(?i)^theme-color$') {
            $theme = Get-HtmlAttributeValue $tag 'content'
            if ($theme -match '^#[0-9a-fA-F]{6}$') { $colors.Add($theme.ToUpperInvariant()) }
        }
    }
    $hexMatches = [regex]::Matches($html, '(?i)#[0-9a-f]{6}\b') | ForEach-Object { $_.Value.ToUpperInvariant() } | Group-Object | Sort-Object Count -Descending
    foreach ($entry in $hexMatches) {
        try {
            $color = [Drawing.ColorTranslator]::FromHtml([string]$entry.Name)
            $range = [Math]::Max($color.R,[Math]::Max($color.G,$color.B)) - [Math]::Min($color.R,[Math]::Min($color.G,$color.B))
            $brightness = ($color.R + $color.G + $color.B) / 3
            if ($range -ge 24 -and $brightness -gt 35 -and $brightness -lt 225 -and -not $colors.Contains([string]$entry.Name)) { $colors.Add([string]$entry.Name) }
        } catch {}
        if ($colors.Count -ge 4) { break }
    }
    if (-not $colors.Count) { $colors.Add('#197782') }
    if ($colors.Count -lt 2) { $colors.Add('#142926') }

    return [pscustomobject]@{ Website=$finalUri.AbsoluteUri; LogoPath=$logoPath; Colors=@($colors) }
}

function Get-LoadedBitmap([string]$Path) {
    $stream = [IO.File]::OpenRead($Path)
    try {
        $source = [Drawing.Image]::FromStream($stream, $true, $true)
        try { return [Drawing.Bitmap]::new($source) } finally { $source.Dispose() }
    } finally { $stream.Dispose() }
}

function Convert-HexColor([string]$Value, [string]$Fallback='#197782') {
    try { return [Drawing.ColorTranslator]::FromHtml($Value) } catch { return [Drawing.ColorTranslator]::FromHtml($Fallback) }
}

function Get-ContrastColor([Drawing.Color]$Color) {
    $luminance = (0.299*$Color.R) + (0.587*$Color.G) + (0.114*$Color.B)
    if ($luminance -gt 145) { return [Drawing.ColorTranslator]::FromHtml('#142926') }
    return [Drawing.Color]::White
}

function Get-DarkerColor([Drawing.Color]$Color, [double]$Factor=0.48) {
    return [Drawing.Color]::FromArgb(255,[int]($Color.R*$Factor),[int]($Color.G*$Factor),[int]($Color.B*$Factor))
}

function Draw-ImageContained([Drawing.Graphics]$Graphics, [Drawing.Image]$Image, [Drawing.RectangleF]$Bounds, [float]$Padding=0) {
    $availableWidth = [Math]::Max(1, $Bounds.Width - (2*$Padding))
    $availableHeight = [Math]::Max(1, $Bounds.Height - (2*$Padding))
    $scale = [Math]::Min($availableWidth/$Image.Width, $availableHeight/$Image.Height)
    $width = [float]($Image.Width*$scale); $height = [float]($Image.Height*$scale)
    $x = [float]($Bounds.X + (($Bounds.Width-$width)/2)); $y = [float]($Bounds.Y + (($Bounds.Height-$height)/2))
    $Graphics.DrawImage($Image, [Drawing.RectangleF]::new($x,$y,$width,$height))
}

function New-BrandCanvas([int]$Width, [int]$Height, [Drawing.Color]$Primary, [Drawing.Color]$Secondary, [Drawing.Image]$Logo, [ValidateSet('Login','Desktop','Intune')]$Layout) {
    $bitmap = [Drawing.Bitmap]::new($Width,$Height,[Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    $graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    $graphics.PixelOffsetMode = [Drawing.Drawing2D.PixelOffsetMode]::HighQuality
    $gradient = [Drawing.Drawing2D.LinearGradientBrush]::new([Drawing.Rectangle]::new(0,0,$Width,$Height), $Secondary, $Primary, 18.0)
    $graphics.FillRectangle($gradient,0,0,$Width,$Height)
    $gradient.Dispose()
    $soft = [Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(32,255,255,255))
    $graphics.FillEllipse($soft,[int]($Width*.55),[int](-$Height*.35),[int]($Width*.75),[int]($Width*.75))
    $graphics.FillEllipse($soft,[int](-$Width*.22),[int]($Height*.55),[int]($Width*.62),[int]($Width*.62))
    $soft.Dispose()
    $panelBrush = [Drawing.SolidBrush]::new([Drawing.Color]::FromArgb(220,255,255,255))
    if ($Layout -eq 'Login') { $panel = [Drawing.RectangleF]::new($Width*.07,$Height*.27,$Width*.34,$Height*.46) }
    elseif ($Layout -eq 'Desktop') { $panel = [Drawing.RectangleF]::new($Width*.62,$Height*.68,$Width*.30,$Height*.20) }
    else { $panel = [Drawing.RectangleF]::new($Width*.10,$Height*.22,$Width*.38,$Height*.56) }
    $graphics.FillRectangle($panelBrush,$panel)
    $panelBrush.Dispose()
    Draw-ImageContained $graphics $Logo $panel ([float]([Math]::Min($Width,$Height)*.035))
    $graphics.Dispose()
    return $bitmap
}

function New-LogoCanvas([int]$Width, [int]$Height, [Drawing.Color]$Background, [Drawing.Image]$Logo, [float]$PaddingRatio=.10) {
    $bitmap = [Drawing.Bitmap]::new($Width,$Height,[Drawing.Imaging.PixelFormat]::Format24bppRgb)
    $graphics = [Drawing.Graphics]::FromImage($bitmap)
    $graphics.Clear($Background)
    $graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $graphics.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
    Draw-ImageContained $graphics $Logo ([Drawing.RectangleF]::new(0,0,$Width,$Height)) ([float]([Math]::Min($Width,$Height)*$PaddingRatio))
    $graphics.Dispose()
    return $bitmap
}

function Get-JpegEncoder {
    return [Drawing.Imaging.ImageCodecInfo]::GetImageEncoders() | Where-Object MimeType -eq 'image/jpeg' | Select-Object -First 1
}

function Save-JpegWithinLimit([Drawing.Bitmap]$Bitmap, [string]$Path, [int64]$MaximumBytes=0, [int]$StartingQuality=90) {
    $encoder = Get-JpegEncoder
    $quality = $StartingQuality
    do {
        $parameters = [Drawing.Imaging.EncoderParameters]::new(1)
        $parameters.Param[0] = [Drawing.Imaging.EncoderParameter]::new([Drawing.Imaging.Encoder]::Quality,[long]$quality)
        $Bitmap.Save($Path,$encoder,$parameters)
        $parameters.Dispose()
        if ($MaximumBytes -le 0 -or (Get-Item -LiteralPath $Path).Length -le $MaximumBytes) { return $Path }
        $quality -= 8
    } while ($quality -ge 30)
    throw "Could not compress $([IO.Path]::GetFileName($Path)) below $MaximumBytes bytes."
}

function Save-LogoWithinLimit([Drawing.Bitmap]$Bitmap, [string]$BasePath, [int64]$MaximumBytes) {
    $pngPath = $BasePath + '.png'
    $Bitmap.Save($pngPath,[Drawing.Imaging.ImageFormat]::Png)
    if ((Get-Item -LiteralPath $pngPath).Length -le $MaximumBytes) { return $pngPath }
    Remove-Item -LiteralPath $pngPath -Force
    return Save-JpegWithinLimit $Bitmap ($BasePath + '.jpg') $MaximumBytes 92
}

function New-BrandingPack([string]$CustomerFolder, [string]$BrandName, [string]$Website, [string]$LogoPath, [string[]]$Colors) {
    if (-not (Test-Path -LiteralPath $LogoPath)) { throw 'A valid logo image is required.' }
    if (-not (Test-Path -LiteralPath $CustomerFolder)) { New-Item -ItemType Directory -Path $CustomerFolder -Force | Out-Null }
    $brandingRoot = Join-Path $CustomerFolder 'Microsoft 365 Branding'
    $outputFolder = Join-Path $brandingRoot 'Ready to upload'
    $sourceFolder = Join-Path $brandingRoot 'Source'
    New-Item -ItemType Directory -Force -Path $outputFolder,$sourceFolder | Out-Null

    $logo = Get-LoadedBitmap $LogoPath
    $primary = Convert-HexColor $Colors[0]
    $secondary = if ($Colors.Count -gt 1) { Convert-HexColor $Colors[1] '#142926' } else { Get-DarkerColor $primary }
    if ($primary.GetBrightness() -lt .18) { $primary = Convert-HexColor '#197782' }
    if ($secondary.GetBrightness() -gt .55) { $secondary = Get-DarkerColor $primary }
    $light = [Drawing.Color]::White
    $dark = Get-DarkerColor $secondary .48
    $generated = [Collections.Generic.List[string]]::new()
    try {
        $login = New-BrandCanvas 1920 1080 $primary $secondary $logo Login
        try { $generated.Add((Save-JpegWithinLimit $login (Join-Path $outputFolder '01-Entra-SignIn-Background-1920x1080.jpg') 300KB 90)) } finally { $login.Dispose() }

        $banner = New-LogoCanvas 245 36 $light $logo .05
        try { $generated.Add((Save-LogoWithinLimit $banner (Join-Path $outputFolder '02-Entra-Banner-Logo-245x36') 50KB)) } finally { $banner.Dispose() }

        $squareLight = New-LogoCanvas 240 240 $light $logo .13
        try { $generated.Add((Save-LogoWithinLimit $squareLight (Join-Path $outputFolder '03-Entra-Square-Logo-Light-240x240') 50KB)) } finally { $squareLight.Dispose() }

        $squareDark = New-LogoCanvas 240 240 $dark $logo .13
        try { $generated.Add((Save-LogoWithinLimit $squareDark (Join-Path $outputFolder '04-Entra-Square-Logo-Dark-240x240') 50KB)) } finally { $squareDark.Dispose() }

        $favicon = New-LogoCanvas 32 32 $light $logo .08
        try { $generated.Add((Save-LogoWithinLimit $favicon (Join-Path $outputFolder '05-Entra-Favicon-32x32') 5KB)) } finally { $favicon.Dispose() }

        $desktop = New-BrandCanvas 1920 1080 $primary $secondary $logo Desktop
        try { $generated.Add((Save-JpegWithinLimit $desktop (Join-Path $outputFolder '06-Desktop-Wallpaper-1920x1080.jpg') 0 92)) } finally { $desktop.Dispose() }

        $intune = New-BrandCanvas 1600 900 $primary $secondary $logo Intune
        try { $generated.Add((Save-JpegWithinLimit $intune (Join-Path $outputFolder '07-Intune-Brand-Image-1600x900.jpg') 1300KB 92)) } finally { $intune.Dispose() }

        $intuneLight = New-LogoCanvas 512 128 $light $logo .10
        try { $generated.Add((Save-LogoWithinLimit $intuneLight (Join-Path $outputFolder '08-Intune-Logo-Light-512x128') 750KB)) } finally { $intuneLight.Dispose() }

        $intuneDark = New-LogoCanvas 512 128 $dark $logo .10
        try { $generated.Add((Save-LogoWithinLimit $intuneDark (Join-Path $outputFolder '09-Intune-Logo-Dark-512x128') 750KB)) } finally { $intuneDark.Dispose() }

        $header = New-LogoCanvas 200 48 $light $logo .06
        try { $generated.Add((Save-LogoWithinLimit $header (Join-Path $outputFolder '10-M365-Header-Logo-200x48') 10KB)) } finally { $header.Dispose() }
    } finally { $logo.Dispose() }

    $sourceExtension = [IO.Path]::GetExtension($LogoPath)
    if ([string]::IsNullOrWhiteSpace($sourceExtension) -or $sourceExtension -eq '.img') { $sourceExtension = '.png' }
    $sourceCopy = Join-Path $sourceFolder ('website-logo' + $sourceExtension)
    try { Copy-Item -LiteralPath $LogoPath -Destination $sourceCopy -Force } catch {}

    $config = [ordered]@{ customer=$BrandName; website=$Website; colors=@($Colors); generatedUtc=[DateTime]::UtcNow.ToString('o'); generator='PeakNet Branding Studio 1.0' }
    $config | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $brandingRoot 'branding-source.json') -Encoding UTF8
    @(
        "PeakNet Microsoft 365 branding pack for $BrandName",
        "Website: $Website",
        "Primary colour: $($Colors[0])",
        "Secondary colour: $(if($Colors.Count -gt 1){$Colors[1]}else{'#142926'})",
        '',
        'Microsoft Entra > Entra ID > Custom Branding:',
        '  01 = Background image (1920x1080, max 300 KB)',
        '  02 = Banner logo (245x36, max 50 KB)',
        '  03 = Square logo for light theme (240x240, max 50 KB)',
        '  04 = Square logo for dark theme (240x240, max 50 KB)',
        '  05 = Favicon (32x32, max 5 KB)',
        '',
        'Windows desktop:',
        '  06 = Desktop wallpaper (1920x1080)',
        '',
        'Microsoft Intune > Tenant administration > Customization:',
        '  07 = Brand image (recommended width above 1125 px, max 1.3 MB)',
        '  08 = Logo for white/light background (recommended height above 72 px, max 750 KB)',
        '  09 = Logo for theme-colour/dark background (recommended height above 72 px, max 750 KB)',
        '',
        'Microsoft 365 admin > Settings > Org settings > Organization profile > Custom themes:',
        '  10 = Header logo (200x48, compressed below 10 KB)',
        '',
        'Review all images with the customer before publishing. Confirm that website images and logos are approved brand assets.'
    ) | Set-Content -LiteralPath (Join-Path $outputFolder 'README - upload guide.txt') -Encoding UTF8
    return [pscustomobject]@{ Folder=$outputFolder; Files=@($generated) }
}

$enginePath = Join-Path $PSScriptRoot 'Branding-Engine.ps1'
if (-not (Test-Path -LiteralPath $enginePath)) { throw 'Branding-Engine.ps1 is missing from the application folder.' }
. $enginePath

$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="PeakNet | Branding Studio 2.0" Width="1240" Height="850" MinWidth="1050" MinHeight="720" WindowStartupLocation="CenterScreen" Background="#F4F5F2" FontFamily="Segoe UI">
 <Window.Resources>
  <Style TargetType="TextBox"><Setter Property="Background" Value="#FFFFFF"/><Setter Property="Foreground" Value="#142926"/><Setter Property="BorderBrush" Value="#D8DFDC"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="10,7"/><Setter Property="FontSize" Value="12.5"/></Style>
  <Style TargetType="ComboBox"><Setter Property="Background" Value="#FFFFFF"/><Setter Property="Foreground" Value="#142926"/><Setter Property="BorderBrush" Value="#D8DFDC"/><Setter Property="Padding" Value="9,6"/></Style>
  <Style TargetType="Button"><Setter Property="Background" Value="#FFFFFF"/><Setter Property="Foreground" Value="#142926"/><Setter Property="BorderBrush" Value="#D8DFDC"/><Setter Property="BorderThickness" Value="1"/><Setter Property="Padding" Value="13,8"/><Setter Property="FontSize" Value="12"/><Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/><Setter Property="Template"><Setter.Value><ControlTemplate TargetType="Button"><Border x:Name="B" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="8" Padding="{TemplateBinding Padding}"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><ControlTemplate.Triggers><Trigger Property="IsMouseOver" Value="True"><Setter TargetName="B" Property="Opacity" Value="0.82"/></Trigger><Trigger Property="IsPressed" Value="True"><Setter TargetName="B" Property="Opacity" Value="0.64"/></Trigger><Trigger Property="IsEnabled" Value="False"><Setter TargetName="B" Property="Opacity" Value="0.38"/></Trigger></ControlTemplate.Triggers></ControlTemplate></Setter.Value></Setter></Style>
  <Style x:Key="Primary" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Background" Value="#197782"/><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="BorderBrush" Value="#197782"/></Style>
  <Style x:Key="Danger" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Foreground" Value="#B42318"/></Style>
 </Window.Resources>
 <Grid><Grid.RowDefinitions><RowDefinition Height="86"/><RowDefinition Height="*"/><RowDefinition Height="76"/></Grid.RowDefinitions>
  <Border Grid.Row="0" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="0,0,0,1" Padding="26,15"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Microsoft 365 Branding Studio" FontSize="24" FontWeight="SemiBold" Foreground="#142926"/><TextBlock Text="Website to brand kit to responsive previews to approval to optional Entra publishing" FontSize="12" Foreground="#60706D" Margin="0,4,0,0"/></StackPanel><Border Grid.Column="1" Background="#EEF5F3" CornerRadius="16" Padding="13,7" VerticalAlignment="Center"><TextBlock Text="QUALITY ENGINE 2.0" Foreground="#197782" FontSize="10" FontWeight="Bold"/></Border></Grid></Border>
  <Grid Grid.Row="1" Margin="22,18"><Grid.ColumnDefinitions><ColumnDefinition Width="470"/><ColumnDefinition Width="18"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
   <Border Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="12"><ScrollViewer VerticalScrollBarVisibility="Auto"><StackPanel Margin="20">
    <TextBlock Text="Customer" FontSize="17" FontWeight="SemiBold" Foreground="#142926"/><TextBlock Text="Customer folder" Foreground="#60706D" Margin="0,10,0,4"/><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBox x:Name="CustomerFolderBox"/><Button x:Name="BrowseFolderButton" Grid.Column="1" Content="Choose" Margin="7,0,0,0"/></Grid>
    <Grid Margin="0,9,0,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="10"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Brand name" Foreground="#60706D" Margin="0,0,0,4"/><TextBox x:Name="BrandNameBox"/></StackPanel><StackPanel Grid.Column="2"><TextBlock Text="Tenant ID" Foreground="#60706D" Margin="0,0,0,4"/><TextBox x:Name="TenantIdBox" IsReadOnly="True"/></StackPanel></Grid>
    <Border BorderBrush="#E4E9E7" BorderThickness="0,1,0,0" Margin="0,18,0,16"/>
    <TextBlock Text="Website and source assets" FontSize="17" FontWeight="SemiBold" Foreground="#142926"/><TextBlock Text="Public website" Foreground="#60706D" Margin="0,10,0,4"/><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBox x:Name="WebsiteBox"/><Button x:Name="AnalyzeButton" Grid.Column="1" Content="Analyse" Style="{StaticResource Primary}" Margin="7,0,0,0"/></Grid>
    <TextBlock Text="Finds SVG, srcset, structured logo data, hero images, colours and support links. Private addresses are blocked." TextWrapping="Wrap" FontSize="10.5" Foreground="#60706D" Margin="0,6,0,0"/>
    <TextBlock Text="Approved logo source" Foreground="#60706D" Margin="0,10,0,4"/><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><TextBox x:Name="LogoBox" IsReadOnly="True"/><Button x:Name="ChooseLogoButton" Grid.Column="1" Content="Replace" Margin="7,0,0,0"/></Grid>
    <TextBlock Text="Design direction" Foreground="#60706D" Margin="0,10,0,4"/><ComboBox x:Name="StyleBox" SelectedIndex="1"><ComboBoxItem Content="Clean Corporate"/><ComboBoxItem Content="Brand Gradient"/><ComboBoxItem Content="Photo &amp; Brand"/></ComboBox>
    <Border BorderBrush="#E4E9E7" BorderThickness="0,1,0,0" Margin="0,18,0,16"/>
    <TextBlock Text="Support and legal details" FontSize="17" FontWeight="SemiBold" Foreground="#142926"/><Grid Margin="0,10,0,0"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="10"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Support email" Foreground="#60706D" Margin="0,0,0,4"/><TextBox x:Name="SupportEmailBox"/></StackPanel><StackPanel Grid.Column="2"><TextBlock Text="Support phone" Foreground="#60706D" Margin="0,0,0,4"/><TextBox x:Name="SupportPhoneBox"/></StackPanel></Grid>
    <TextBlock Text="Privacy URL" Foreground="#60706D" Margin="0,9,0,4"/><TextBox x:Name="PrivacyBox"/><TextBlock Text="Terms URL" Foreground="#60706D" Margin="0,9,0,4"/><TextBox x:Name="TermsBox"/>
   </StackPanel></ScrollViewer></Border>
   <Border Grid.Column="2" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="12" Padding="18"><Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions>
    <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="220"/></Grid.ColumnDefinitions><StackPanel><TextBlock Text="Live preview" FontSize="18" FontWeight="SemiBold" Foreground="#142926"/><TextBlock Text="Review cropping, safe areas, light/dark use and Microsoft experiences." FontSize="11" Foreground="#60706D" Margin="0,3,0,0"/></StackPanel><ComboBox x:Name="PreviewModeBox" Grid.Column="1" SelectedIndex="0"><ComboBoxItem Content="Source logo"/><ComboBoxItem Content="Design proposal"/><ComboBoxItem Content="Entra desktop"/><ComboBoxItem Content="Entra mobile"/><ComboBoxItem Content="Microsoft 365 header"/><ComboBoxItem Content="Intune Company Portal"/></ComboBox></Grid>
    <Border Grid.Row="1" Background="#EEF1EF" CornerRadius="10" Margin="0,15,0,12"><Grid><Image x:Name="LogoPreview" Stretch="Uniform" Margin="18"/><Border x:Name="SafeAreaOverlay" BorderBrush="#80FFFFFF" BorderThickness="1" Margin="45" CornerRadius="8" IsHitTestVisible="False"/><TextBlock x:Name="PreviewHint" Text="Safe preview area" Foreground="#CCFFFFFF" FontSize="10" HorizontalAlignment="Right" VerticalAlignment="Bottom" Margin="0,0,18,14"/></Grid></Border>
    <Grid Grid.Row="2"><Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><Border x:Name="PrimarySwatch" Width="55" Height="38" Background="#197782" CornerRadius="7" Margin="0,0,8,0"/><Border x:Name="SecondarySwatch" Grid.Column="1" Width="55" Height="38" Background="#142926" CornerRadius="7"/><StackPanel Grid.Column="2" Margin="10,0,0,0"><TextBlock x:Name="PrimaryColorText" Text="#197782"/><TextBlock x:Name="SecondaryColorText" Text="#142926" Foreground="#60706D"/></StackPanel><Button x:Name="OpenReportButton" Grid.Column="3" Content="Open quality report" IsEnabled="False"/></Grid>
    <Border Grid.Row="3" Background="#F7F9F8" CornerRadius="8" Padding="13" Margin="0,13,0,0"><StackPanel><TextBlock x:Name="StatusText" Text="Enter a website and run analysis." TextWrapping="Wrap" Foreground="#445451"/><TextBlock x:Name="GraphStatusText" Text="Microsoft publishing: not connected" FontSize="10.5" Foreground="#60706D" Margin="0,5,0,0"/></StackPanel></Border>
   </Grid></Border>
  </Grid>
  <Border Grid.Row="2" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="0,1,0,0" Padding="22,13"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions><WrapPanel VerticalAlignment="Center"><Button x:Name="OpenFolderButton" Content="Open folder"/><Button x:Name="ConnectGraphButton" Content="Connect Microsoft" Margin="8,0,0,0"/><Button x:Name="PublishButton" Content="Backup + publish to Entra" Margin="8,0,0,0" IsEnabled="False"/></WrapPanel><WrapPanel Grid.Column="1"><Button x:Name="CloseButton" Content="Close"/><Button x:Name="ApproveButton" Content="Approve selected design" Margin="8,0,0,0" IsEnabled="False"/><Button x:Name="GenerateButton" Content="Generate draft &amp; previews" Style="{StaticResource Primary}" Margin="8,0,0,0"/></WrapPanel></Grid></Border>
 </Grid>
</Window>
'@

$reader = [Xml.XmlNodeReader]::new([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)
$controls=@{};foreach($name in @('CustomerFolderBox','BrandNameBox','TenantIdBox','WebsiteBox','LogoBox','LogoPreview','PrimarySwatch','SecondarySwatch','PrimaryColorText','SecondaryColorText','StatusText','GraphStatusText','AnalyzeButton','GenerateButton','StyleBox','PreviewModeBox','SupportEmailBox','SupportPhoneBox','PrivacyBox','TermsBox','OpenReportButton','ApproveButton','ConnectGraphButton','PublishButton','SafeAreaOverlay','PreviewHint')){$controls[$name]=$window.FindName($name)}
$safeCustomerName=if([string]::IsNullOrWhiteSpace($CustomerName)){'New customer'}else{$CustomerName.Trim()};$controls.CustomerFolderBox.Text=Find-CustomerFolder $safeCustomerName;$controls.BrandNameBox.Text=$safeCustomerName;$controls.TenantIdBox.Text=$TenantId
$emptySupport=[pscustomobject]@{Email='';Phone='';PrivacyUrl='';TermsUrl=''};$script:Analysis=[pscustomobject]@{Website='';LogoPath='';LogoOriginalPath='';LogoUri='';HeroPath='';Colors=@('#197782','#142926');Support=$emptySupport;CandidateCount=0;VectorLogo=$false};$script:LatestResult=$null;$script:ApprovedFolder='';$script:GraphConnection=$null
$cacheFolder=Join-Path (Join-Path $env:LOCALAPPDATA 'MSPTenantLauncher') 'BrandingCacheV2'

function Set-PreviewImage([string]$Path){if(-not$Path-or-not(Test-Path -LiteralPath $Path)){$controls.LogoPreview.Source=$null;return};try{$stream=[IO.File]::OpenRead($Path);try{$image=[Windows.Media.Imaging.BitmapImage]::new();$image.BeginInit();$image.CacheOption=[Windows.Media.Imaging.BitmapCacheOption]::OnLoad;$image.StreamSource=$stream;$image.EndInit();$image.Freeze();$controls.LogoPreview.Source=$image}finally{$stream.Dispose()}}catch{$controls.LogoPreview.Source=$null}}
function Get-ComboText($Combo) {
    if ($Combo.SelectedItem -and $null -ne $Combo.SelectedItem.Content) {
        return [string]$Combo.SelectedItem.Content
    }
    return ''
}
function Update-BrandPreview {
    $colors=@($script:Analysis.Colors);if(-not$colors.Count){$colors=@('#197782','#142926')};if($colors.Count-lt2){$colors+='#142926'};$controls.PrimaryColorText.Text=$colors[0];$controls.SecondaryColorText.Text=$colors[1];try{$controls.PrimarySwatch.Background=[Windows.Media.BrushConverter]::new().ConvertFromString($colors[0])}catch{};try{$controls.SecondarySwatch.Background=[Windows.Media.BrushConverter]::new().ConvertFromString($colors[1])}catch{}
    $mode=Get-ComboText $controls.PreviewModeBox;$path=$script:Analysis.LogoPath;$controls.SafeAreaOverlay.Visibility='Collapsed';$controls.PreviewHint.Visibility='Collapsed'
    if($script:LatestResult){if($mode-eq'Design proposal'){$style=Get-ComboText $controls.StyleBox;$path=$script:LatestResult.ProposalFiles|Where-Object{$_-like"*$style*"}|Select-Object -First 1;$controls.SafeAreaOverlay.Visibility='Visible';$controls.PreviewHint.Visibility='Visible'}elseif($mode-ne'Source logo'){$map=@{'Entra desktop'='Preview - Entra Desktop.jpg';'Entra mobile'='Preview - Entra Mobile.jpg';'Microsoft 365 header'='Preview - Microsoft 365 Header.jpg';'Intune Company Portal'='Preview - Intune Company Portal.jpg'};$path=Join-Path $script:LatestResult.Folder $map[$mode]}}
    Set-PreviewImage $path;if($script:Analysis.LogoPath){$controls.LogoBox.Text=$script:Analysis.LogoOriginalPath}
}

$window.FindName('BrowseFolderButton').Add_Click({$picker=New-Object Windows.Forms.FolderBrowserDialog;$picker.Description='Choose customer folder';$picker.SelectedPath=$controls.CustomerFolderBox.Text;if($picker.ShowDialog()-eq'OK'){$controls.CustomerFolderBox.Text=$picker.SelectedPath};$picker.Dispose()})
$window.FindName('ChooseLogoButton').Add_Click({$picker=New-Object Windows.Forms.OpenFileDialog;$picker.Filter='Logo files|*.svg;*.png;*.jpg;*.jpeg;*.bmp;*.gif;*.ico|All files|*.*';if($picker.ShowDialog()-eq'OK'){$original=$picker.FileName;$raster=$original;if([IO.Path]::GetExtension($original)-eq'.svg'){$raster=Join-Path $cacheFolder ('manual-'+[guid]::NewGuid().ToString('N')+'.png');New-Item -ItemType Directory -Force -Path $cacheFolder|Out-Null;$raster=Convert-SvgToPng $original $raster;if(-not$raster){[Windows.MessageBox]::Show('The SVG could not be rendered. Choose a PNG instead.','Logo','OK','Warning')|Out-Null;return}};$palette=Get-LogoPalette $raster;$script:Analysis=[pscustomobject]@{Website=$controls.WebsiteBox.Text.Trim();LogoPath=$raster;LogoOriginalPath=$original;LogoUri='';HeroPath=$script:Analysis.HeroPath;Colors=@($palette);Support=$script:Analysis.Support;CandidateCount=$script:Analysis.CandidateCount;VectorLogo=([IO.Path]::GetExtension($original)-eq'.svg')};Update-BrandPreview;$controls.StatusText.Text='Approved source logo selected. Generate previews when ready.'};$picker.Dispose()})

$controls.AnalyzeButton.Add_Click({$controls.AnalyzeButton.IsEnabled=$false;$controls.GenerateButton.IsEnabled=$false;$controls.StatusText.Text='Analysing logo sources, SVG, hero image, palette and support links...';[Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background);try{$script:Analysis=Get-WebsiteAnalysis $controls.WebsiteBox.Text $cacheFolder;$controls.WebsiteBox.Text=$script:Analysis.Website;$controls.SupportEmailBox.Text=$script:Analysis.Support.Email;$controls.SupportPhoneBox.Text=$script:Analysis.Support.Phone;$controls.PrivacyBox.Text=$script:Analysis.Support.PrivacyUrl;$controls.TermsBox.Text=$script:Analysis.Support.TermsUrl;Update-BrandPreview;if($script:Analysis.LogoPath){$kind=if($script:Analysis.VectorLogo){'SVG/vector logo'}else{'raster logo'};$controls.StatusText.Text="$kind found among $($script:Analysis.CandidateCount) candidates. Review it before generation."}else{$controls.StatusText.Text='No usable logo was found. Choose an approved SVG, PNG or JPG manually.'}}catch{$controls.StatusText.Text='Analysis failed: '+$_.Exception.Message;[Windows.MessageBox]::Show($controls.StatusText.Text,'Branding Studio','OK','Warning')|Out-Null}finally{$controls.AnalyzeButton.IsEnabled=$true;$controls.GenerateButton.IsEnabled=$true}})

$controls.GenerateButton.Add_Click({if([string]::IsNullOrWhiteSpace($controls.BrandNameBox.Text)-or[string]::IsNullOrWhiteSpace($controls.CustomerFolderBox.Text)){[Windows.MessageBox]::Show('Enter a customer and folder.','Branding Studio','OK','Warning')|Out-Null;return};if(-not$script:Analysis.LogoPath-or-not(Test-Path -LiteralPath $script:Analysis.LogoPath)){[Windows.MessageBox]::Show('Analyse the website or choose an approved logo first.','Logo required','OK','Warning')|Out-Null;return};$style=Get-ComboText $controls.StyleBox;$support=[pscustomobject]@{Email=$controls.SupportEmailBox.Text.Trim();Phone=$controls.SupportPhoneBox.Text.Trim();PrivacyUrl=$controls.PrivacyBox.Text.Trim();TermsUrl=$controls.TermsBox.Text.Trim()};$controls.GenerateButton.IsEnabled=$false;$controls.AnalyzeButton.IsEnabled=$false;$controls.StatusText.Text='Rendering high-quality assets, proposals, experience previews and QA report...';[Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background);try{$script:LatestResult=New-BrandingPackV2 $controls.CustomerFolderBox.Text.Trim() $controls.BrandNameBox.Text.Trim() $controls.WebsiteBox.Text.Trim() $script:Analysis.LogoPath $script:Analysis.LogoOriginalPath $script:Analysis.HeroPath @($script:Analysis.Colors) $style $support;$controls.PreviewModeBox.SelectedIndex=1;$controls.ApproveButton.IsEnabled=$true;$controls.OpenReportButton.IsEnabled=$true;$controls.StatusText.Text="$($script:LatestResult.Files.Count) upload assets, $($script:LatestResult.ProposalFiles.Count) design directions and $($script:LatestResult.PreviewFiles.Count) responsive previews are ready. Review the QA report, then approve.";Update-BrandPreview}catch{$controls.StatusText.Text='Generation failed: '+$_.Exception.Message;[Windows.MessageBox]::Show($controls.StatusText.Text,'Branding Studio','OK','Error')|Out-Null}finally{$controls.GenerateButton.IsEnabled=$true;$controls.AnalyzeButton.IsEnabled=$true}})

$controls.PreviewModeBox.Add_SelectionChanged({Update-BrandPreview});$controls.StyleBox.Add_SelectionChanged({if($script:LatestResult-and(Get-ComboText $controls.PreviewModeBox)-eq'Design proposal'){Update-BrandPreview}})
$controls.OpenReportButton.Add_Click({if($script:LatestResult-and(Test-Path -LiteralPath $script:LatestResult.Report)){Start-Process $script:LatestResult.Report|Out-Null}})
$controls.ApproveButton.Add_Click({if(-not$script:LatestResult){return};$choice=[Windows.MessageBox]::Show("Approve '$($script:LatestResult.Style)' for $($controls.BrandNameBox.Text)?`n`nThe current Ready to upload pack is preserved in History.",'Approve branding','YesNo','Question');if($choice-ne'Yes'){return};try{$script:ApprovedFolder=Approve-BrandingPack $controls.CustomerFolderBox.Text.Trim() $script:LatestResult;$controls.PublishButton.IsEnabled=($null-ne$script:GraphConnection);$controls.StatusText.Text="Approved pack saved to: $script:ApprovedFolder"}catch{[Windows.MessageBox]::Show($_.Exception.Message,'Approval failed','OK','Error')|Out-Null}})

$controls.ConnectGraphButton.Add_Click({try{$configPath=Join-Path (Join-Path $ClientsRoot '_PeakNet Tenant Access') 'msp-connection.json';if(-not(Test-Path -LiteralPath $configPath)){throw"MSP connection configuration not found: $configPath"};$config=Get-Content -Raw -LiteralPath $configPath|ConvertFrom-Json;$script:GraphConnection=Connect-BrandingGraph $controls.TenantIdBox.Text.Trim() ([string]$config.clientId);$controls.GraphStatusText.Text="Connected as $($script:GraphConnection.Account) | tokens stay in memory";$controls.PublishButton.IsEnabled=(-not[string]::IsNullOrWhiteSpace($script:ApprovedFolder));$controls.ConnectGraphButton.Content='Reconnect Microsoft'}catch{$controls.GraphStatusText.Text='Microsoft connection failed';[Windows.MessageBox]::Show("$($_.Exception.Message)`n`nThe app registration requires delegated OrganizationalBranding.ReadWrite.All and administrator consent. Use an Organizational Branding Administrator account.",'Microsoft connection','OK','Warning')|Out-Null}})
$controls.PublishButton.Add_Click({if(-not$script:GraphConnection-or-not$script:ApprovedFolder){return};$confirmation=[Windows.MessageBox]::Show("Publish the approved Entra branding now?`n`nCustomer: $($controls.BrandNameBox.Text)`nTenant: $($controls.TenantIdBox.Text)`nAccount: $($script:GraphConnection.Account)`n`nThe existing Entra branding is backed up first. Microsoft 365 and Intune assets remain ready for manual portal upload.",'Confirm Entra publication','YesNo','Warning');if($confirmation-ne'Yes'){return};try{$controls.PublishButton.IsEnabled=$false;$controls.StatusText.Text='Backing up existing Entra branding and publishing the approved assets...';[Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background);$text="Har du problemer med at logge ind? Kontakt $($controls.SupportEmailBox.Text) $($controls.SupportPhoneBox.Text)";$backup=Publish-EntraBranding $script:GraphConnection $script:ApprovedFolder $controls.CustomerFolderBox.Text.Trim() ([string]$script:Analysis.Colors[0]) $text;$controls.StatusText.Text="Entra branding published. Previous branding backup: $backup";[Windows.MessageBox]::Show("Entra branding was published successfully.`n`nBackup: $backup",'Publication complete','OK','Information')|Out-Null}catch{$controls.StatusText.Text='Publication failed. Existing backup was retained.';[Windows.MessageBox]::Show($_.Exception.Message,'Publication failed','OK','Error')|Out-Null}finally{$controls.PublishButton.IsEnabled=$true}})

$window.FindName('OpenFolderButton').Add_Click({$folder=Join-Path $controls.CustomerFolderBox.Text 'Microsoft 365 Branding';if(Test-Path -LiteralPath $folder){Start-Process explorer.exe -ArgumentList ('"'+$folder+'"')|Out-Null}else{[Windows.MessageBox]::Show('No branding folder exists yet.','Branding Studio','OK','Information')|Out-Null}})
$window.FindName('CloseButton').Add_Click({$window.Close()});$window.Add_Closed({if($script:GraphConnection){$script:GraphConnection.AccessToken='';$script:GraphConnection=$null}})

$existingConfig=Join-Path (Join-Path $controls.CustomerFolderBox.Text 'Microsoft 365 Branding') 'brand-kit.json';if(Test-Path -LiteralPath $existingConfig){try{$saved=Get-Content -Raw -LiteralPath $existingConfig|ConvertFrom-Json;if($saved.website){$controls.WebsiteBox.Text=[string]$saved.website};if($saved.palette){$script:Analysis.Colors=@($saved.palette)};if($saved.support){$controls.SupportEmailBox.Text=[string]$saved.support.Email;$controls.SupportPhoneBox.Text=[string]$saved.support.Phone;$controls.PrivacyBox.Text=[string]$saved.support.PrivacyUrl;$controls.TermsBox.Text=[string]$saved.support.TermsUrl};Update-BrandPreview}catch{}}
[void]$window.ShowDialog()
