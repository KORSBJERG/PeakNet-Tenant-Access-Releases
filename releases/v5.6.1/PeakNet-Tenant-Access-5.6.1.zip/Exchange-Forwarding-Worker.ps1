[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$RequestPath,
    [Parameter(Mandatory)][string]$StatusPath,
    [Parameter(Mandatory)][string]$ResultPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-WorkerStatus([string]$Message) {
    $Message | Add-Content -LiteralPath $StatusPath -Encoding UTF8
}

function Test-EmailAddress([string]$Value) {
    try {
        $address = [Net.Mail.MailAddress]::new($Value)
        return $address.Address -eq $Value
    } catch { return $false }
}

function ConvertTo-RecipientText($Value) {
    $values = @($Value | ForEach-Object { ([string]$_).Trim() } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })
    return ($values -join '; ')
}

function Get-ForwardingState([string]$Source) {
    $mailbox = Get-Mailbox -Identity $Source -ErrorAction Stop
    $ruleWarning = ''
    $allRules = @()
    try {
        $allRules = @(Get-InboxRule -Mailbox $Source -ResultSize Unlimited -ErrorAction Stop)
    } catch {
        $ruleWarning = 'Mailbox forwarding was read, but Inbox Rules could not be listed: ' + $_.Exception.Message
    }
    $forwardingRules = @($allRules | Where-Object {
        -not [string]::IsNullOrWhiteSpace((ConvertTo-RecipientText $_.ForwardTo)) -or
        -not [string]::IsNullOrWhiteSpace((ConvertTo-RecipientText $_.RedirectTo)) -or
        -not [string]::IsNullOrWhiteSpace((ConvertTo-RecipientText $_.ForwardAsAttachmentTo))
    })
    return [pscustomobject]@{ Mailbox=$mailbox; InboxRules=$forwardingRules; Warning=$ruleWarning }
}

function Get-ForwardingRecords($State) {
    $records = [Collections.Generic.List[object]]::new()
    $mailbox = $State.Mailbox
    $smtp = ([string]$mailbox.ForwardingSmtpAddress) -replace '^(?i)smtp:',''
    $internal = [string]$mailbox.ForwardingAddress
    $delivery = if ([bool]$mailbox.DeliverToMailboxAndForward) { 'Keep mailbox copy' } else { 'Forward only' }
    if (-not [string]::IsNullOrWhiteSpace($smtp)) {
        $records.Add([pscustomobject][ordered]@{Type='Mailbox';Name='External forwarding';Destination=$smtp;Enabled='Yes';Delivery=$delivery})
    }
    if (-not [string]::IsNullOrWhiteSpace($internal)) {
        $records.Add([pscustomobject][ordered]@{Type='Mailbox';Name='Internal forwarding';Destination=$internal;Enabled='Yes';Delivery=$delivery})
    }
    foreach ($rule in @($State.InboxRules)) {
        $enabled = if ([bool]$rule.Enabled) { 'Yes' } else { 'No' }
        $deliveryText = if ($rule.PSObject.Properties.Name -contains 'DeleteMessage' -and [bool]$rule.DeleteMessage) { 'Delete original' } else { 'Keep original' }
        foreach ($action in @(
            @{Label='Inbox rule - forward';Value=(ConvertTo-RecipientText $rule.ForwardTo)},
            @{Label='Inbox rule - redirect';Value=(ConvertTo-RecipientText $rule.RedirectTo)},
            @{Label='Inbox rule - attachment';Value=(ConvertTo-RecipientText $rule.ForwardAsAttachmentTo)}
        )) {
            if (-not [string]::IsNullOrWhiteSpace([string]$action.Value)) {
                $records.Add([pscustomobject][ordered]@{Type=[string]$action.Label;Name=[string]$rule.Name;Destination=[string]$action.Value;Enabled=$enabled;Delivery=$deliveryText})
            }
        }
    }
    return @($records)
}

function Get-ForwardingDescription($State) {
    $mailbox = $State.Mailbox
    $smtp = ([string]$mailbox.ForwardingSmtpAddress) -replace '^(?i)smtp:',''
    $internal = [string]$mailbox.ForwardingAddress
    $records = @(Get-ForwardingRecords $State)
    $lines = [Collections.Generic.List[string]]::new()
    $lines.Add("Mailbox: $([string]$mailbox.PrimarySmtpAddress)")
    $lines.Add("External mailbox forwarding: $(if($smtp){$smtp}else{'Disabled'})")
    $lines.Add("Internal mailbox forwarding: $(if($internal){$internal}else{'Disabled'})")
    $lines.Add("Keep local mailbox copy: $([bool]$mailbox.DeliverToMailboxAndForward)")
    $lines.Add("Forwarding Inbox Rules: $(@($State.InboxRules).Count)")
    if ($records.Count -eq 0) { $lines.Add('No mailbox or Inbox Rule forwarding was found.') }
    if (-not [string]::IsNullOrWhiteSpace([string]$State.Warning)) { $lines.Add('');$lines.Add([string]$State.Warning) }
    return ($lines -join [Environment]::NewLine)
}

$result = [ordered]@{ Success=$false; Message='The Exchange Online operation did not complete.'; Records=@(); Warning='' }
$connected = $false
try {
    $request = Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Import-Module ExchangeOnlineManagement -MinimumVersion 3.0 -ErrorAction Stop
    Write-WorkerStatus 'A Microsoft device sign-in is required. The code shown below is also copied by the PeakNet app.'
    $parameters = @{
        Device = $true
        ShowBanner = $false
        ShowProgress = $false
        SkipLoadingFormatData = $true
        CommandName = @('Get-Mailbox','Set-Mailbox','Get-AcceptedDomain','Get-InboxRule')
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$request.Login)) { $parameters.UserPrincipalName = [string]$request.Login }
    if ([string]$request.Authentication -eq 'GDAP') { $parameters.DelegatedOrganization = [string]$request.Tenant }
    Connect-ExchangeOnline @parameters -ErrorAction Stop 6>&1 | ForEach-Object { Write-WorkerStatus ([string]$_) }
    $connected = $true
    Write-WorkerStatus 'Microsoft sign-in completed. Reading Exchange Online forwarding configuration...'

    $source = ([string]$request.Source).Trim()
    if (-not (Test-EmailAddress $source)) { throw 'Enter a valid source mailbox address.' }
    switch ([string]$request.Action) {
        'Check' {
            $state = Get-ForwardingState $source
            $result.Success = $true
            $result.Message = Get-ForwardingDescription $state
            $result.Records = @(Get-ForwardingRecords $state)
            $result.Warning = [string]$state.Warning
        }
        'Apply' {
            $destination = ([string]$request.Destination).Trim()
            if (-not (Test-EmailAddress $destination)) { throw 'Enter a valid external destination address.' }
            if ($source -eq $destination) { throw 'The source and destination must be different.' }
            $domain = $destination.Split('@')[-1].ToLowerInvariant()
            $accepted = @(Get-AcceptedDomain -ErrorAction Stop | ForEach-Object { ([string]$_.DomainName).ToLowerInvariant() })
            if ($accepted -contains $domain) { throw "The destination domain $domain belongs to this tenant. Enter an external address." }
            $before = Get-Mailbox -Identity $source -ErrorAction Stop
            if (-not [string]::IsNullOrWhiteSpace([string]$before.ForwardingAddress)) {
                throw 'This mailbox already has internal forwarding. PeakNet did not replace or clear it. Review the existing configuration in Exchange before applying external forwarding.'
            }
            Set-Mailbox -Identity $source -ForwardingSmtpAddress $destination -DeliverToMailboxAndForward ([bool]$request.KeepCopy) -ErrorAction Stop
            $verified = Get-Mailbox -Identity $source -ErrorAction Stop
            if (([string]$verified.ForwardingSmtpAddress) -notmatch [regex]::Escape($destination)) { throw 'Exchange did not return the requested destination during verification.' }
            $state = Get-ForwardingState $source
            $result.Success = $true
            $result.Message = "Forwarding applied and verified.`r`n`r`n$(Get-ForwardingDescription $state)"
            $result.Records = @(Get-ForwardingRecords $state)
            $result.Warning = [string]$state.Warning
        }
        'Disable' {
            $before = Get-Mailbox -Identity $source -ErrorAction Stop
            $preserveKeepCopy = if (-not [string]::IsNullOrWhiteSpace([string]$before.ForwardingAddress)) { [bool]$before.DeliverToMailboxAndForward } else { $false }
            Set-Mailbox -Identity $source -ForwardingSmtpAddress $null -DeliverToMailboxAndForward $preserveKeepCopy -ErrorAction Stop
            $verified = Get-Mailbox -Identity $source -ErrorAction Stop
            if (-not [string]::IsNullOrWhiteSpace([string]$verified.ForwardingSmtpAddress)) { throw 'Verification shows external mailbox forwarding is still configured.' }
            $state = Get-ForwardingState $source
            $result.Success = $true
            $result.Message = "External mailbox forwarding disabled and verified. Internal forwarding and Inbox Rules were not changed.`r`n`r`n$(Get-ForwardingDescription $state)"
            $result.Records = @(Get-ForwardingRecords $state)
            $result.Warning = [string]$state.Warning
        }
        default { throw 'Unknown Exchange Online action.' }
    }
} catch {
    $result.Message = $_.Exception.Message
} finally {
    if ($connected) { try { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue } catch {} }
    $result | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $ResultPath -Encoding UTF8
}