# PeakNet Tenant Access - secure GitHub updates

## Architecture

PeakNet Tenant Access uses a public, release-only GitHub repository. It must never contain customer tenant data, time entries, audit logs, MSP tokens, settings, or the private signing key.

The app downloads `stable/latest.json` and its detached CMS signature. The signature is checked against the PeakNet publisher certificate bundled with the app. Only an HTTPS package URL under the pinned `KORSBJERG/PeakNet-Tenant-Access-Releases` repository is accepted. The ZIP size and SHA-256 hash must match the signed feed.

Before installation the updater waits for the launcher to close, rejects unsafe ZIP paths, verifies every file against `release-manifest.json`, parses every PowerShell script, and backs up the current version. If installation fails, the previous files are restored. Installation is blocked while tenant sessions are active.

## Publish a release

1. Finish and test the source files in this folder.
2. Run:

   `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Publish-PeakNetRelease.ps1 -Version 5.3.1 -ReleaseNotes "Describe the changes"`

3. Create GitHub release tag `v5.3.1` and upload the generated ZIP from `release-build\v5.3.1`.
4. Copy the generated `latest.json` and `latest.json.p7s` into the repository's `stable` folder and commit both files together.
5. Test **Check for updates** on a non-production installation.

The publishing script's private key is protected with Windows DPAPI for the current Windows user at:

`%LOCALAPPDATA%\PeakNet\TenantAccess\Signing\publisher-key.dpapi`

Back up that encrypted key securely. It works only for this Windows user profile. Never upload it or include it in a release.

## First installation for a colleague

Send the colleague the ZIP asset from the newest GitHub Release. They extract it to a local application folder and run `Start-MSP-Tenant-Launcher.vbs`. After that, **Check for updates** performs signed online updates. Customer and time-tracking data remain outside the program folder.

## Release channels

`Update-Config.json` selects `stable`. A future preview installation can use a separately signed `preview/latest.json` feed without exposing preview releases to normal users.