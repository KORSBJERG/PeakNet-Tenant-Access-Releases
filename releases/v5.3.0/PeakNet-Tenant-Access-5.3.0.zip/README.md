# MSP Tenant Launcher

A small Windows launcher for safer daily access to Microsoft Entra, Microsoft 365, and Azure customer tenants.

Version 5.2.1 replaces the hidden Exchange Online authentication prompt with Microsoft device sign-in through PowerShell 7. The app opens Edge InPrivate, displays and copies the short-lived sign-in code, keeps the forwarding window responsive, times out safely, and runs each Exchange action in an isolated helper process whose temporary request and result files are removed afterward.

Version 5.2.0 adds customer company logos to the tenant list. Existing approved Branding Studio assets are reused automatically, while **Update selected company logo** safely analyses the selected customer's public website and stores a shared cached copy under `Clients\_PeakNet Tenant Access\Logos`. Customers without an available logo show clear initials instead. A customer website can now be stored in **Add/Edit**; no website credentials, cookies, or Microsoft tokens are used.

Version 5.1.3 fixes all compact throw/return statements in the forwarding workflow so validation messages are raised correctly instead of being interpreted as command names. Version 5.1.2 fixed Exchange Online sign-in in the hidden launcher host by using the connected MSP account for GDAP and the Microsoft-supported DisableWAM workaround for GDAP authentication. Version 5.1.1 fixed the startup event registration for the Branding Studio button after adding External email forwarding. Version 5.1.0 added a controlled External email forwarding workspace for Exchange Online mailboxes. It supports GDAP or direct administrator sign-in, reads the current configuration, validates external destinations, requires customer authorization and explicit confirmation, verifies changes, disables forwarding again, and never weakens the tenant outbound spam policy. Version 5.0.3 prevents duplicate tenant rows during loading, display, synchronization, import, and saving. Version 5.0.2 added clearer spacing between the left workspace menu and the customer list. Version 5.0.1 moved the complete workspace menu to the left. Version 5.0 introduced Branding Studio 2.0: a quality-focused Microsoft 365 brand workflow with richer website discovery, three design directions, responsive previews, approval/history, QA reporting, and optional backup-first Entra publishing.

## Version 5.0 features

- **Higher-quality sources:** finds SVG logos, `srcset` variants, structured logo data, favicons, social/hero images, CSS backgrounds, and the highest-value source candidates.
- **Vector workflow:** SVG source files are retained and rendered through the locally installed Microsoft Edge for raster-only Microsoft destinations.
- **Logo-derived palette:** colours are sampled from the selected logo instead of relying only on arbitrary website CSS values.
- **Three design directions:** generates Clean Corporate, Brand Gradient, and Photo & Brand proposals for visual comparison.
- **Transparent, supersampled logos:** small Microsoft assets use transparent PNG where possible and are rendered at higher internal resolution before downscaling.
- **Experience previews:** simulates Entra desktop, Entra mobile, Microsoft 365 header, and Intune Company Portal placement before approval.
- **Quality report:** creates an HTML report containing previews, dimensions, file sizes, source resolution, and contrast measurements.
- **Reusable customer brand kit:** saves original and normalized logos, colour palette, website, support information, legal links, and generation settings.
- **Draft, approval, and history workflow:** drafts are timestamped; approval creates an immutable approved copy, archives the previous upload pack, and refreshes `Ready to upload`.
- **Expanded asset pack:** includes Entra, Intune, Windows wallpaper, Microsoft 365 light/dark logos, Copilot footer logo, and Danish/English sign-in text templates.
- **Safer Entra publishing:** connects to the selected customer, keeps OAuth tokens in memory only, backs up existing Entra branding, and publishes only an explicitly approved pack after a final confirmation.
- **Least-privilege publishing:** requires delegated `OrganizationalBranding.ReadWrite.All` and an account with the Organizational Branding Administrator role. The public-client app must be multitenant and have `http://localhost` as a desktop redirect URI.

Microsoft 365 theme and Intune assets are prepared for portal upload. Entra assets can be published directly through Microsoft Graph; the app does not attempt unsupported or undocumented tenant mutations.

Version 4.3 added the first Microsoft 365 Branding Studio that turned a customer website and logo into a review-ready image pack stored in the customer's shared folder.

## Version 4.3 features

- **Website-to-branding workflow:** select a customer, open **Microsoft 365 Branding Studio**, enter the customer website, and analyse it for a likely logo and brand colours.
- **Customer-folder output:** files are saved under `Clients\<customer>\Microsoft 365 Branding`, with the upload-ready versions separated from the retained source logo and settings.
- **Ready-sized assets:** creates an Entra sign-in background, banner logo, light/dark square logos, favicon, desktop wallpaper, Intune brand image and logos, and a Microsoft 365 header logo.
- **Built-in size control:** generated assets are compressed to the relevant Microsoft upload limits, and an upload guide is included with every pack.
- **Human review by design:** the detected logo and colours are previewed before generation, and a local approved PNG/JPG logo can be selected if the website does not expose a usable one.
- **Safer website analysis:** only public HTTP/HTTPS sites are accepted; local/private network addresses are rejected, downloads are bounded, and no password or tenant token is used.

Version 4.2 gave the complete application a consistent web-style visual system, including reports, dashboards, forms, security results, session setup, and policy windows.

## Version 4.2 features

- **Consistent secondary windows:** custom reports and settings now share the main workspace's PeakNet typography, teal actions, white surfaces, and soft neutral backgrounds.
- **Modern report tables:** spacious rows, flat headers, subtle dividers, alternating surfaces, and soft selection replace the classic Windows grid appearance.
- **Web-style navigation:** report tabs use larger flat navigation controls and the work log has a dedicated page heading, supporting text, and action bar.
- **Unified forms:** tenant editing, session confirmation, manual adjustments, MSP setup, portal selection, security checks, dashboards, charts, and session policy use the same control styling.

## Version 4.1 features

- **Session Workspace:** live tenant sessions appear in a selectable strip with their elapsed time; selecting one also selects the matching customer.
- **Right-side workspace:** the selected tenant, four direct portal shortcuts, secure launch controls, time reports, management functions, security tools, and MSP connections are grouped by purpose on the right.
- **Focused tenant list:** the customer grid has more room, a prominent search field, and keeps the existing pinned/recent/alphabetical ordering.
- **Direct portal access:** Admin, Entra, Intune, and Security buttons open directly in the selected tenant's existing isolated Edge profile.
- **PeakNet taskbar identity:** the active window uses the custom shield icon instead of being grouped under the standard PowerShell icon.

## Version 4.0 foundations

- **Operations dashboard:** active sessions, current-month time, recently used customers, tenant health, and the shared-data status appear in one view.
- **Idle-aware time:** each session can pause time tracking after the configured period of Windows computer inactivity. Only the duration is recorded; keys, screen contents, and browser activity are never collected.
- **Monthly charts:** compare billable and non-billable hours by customer for any recorded month.
- **Session policy:** configure idle minutes, the long-session warning, optional automatic session closing, and minimize-to-tray behaviour.
- **Tenant health:** see GDAP status/expiry and local catalog warnings without requesting additional Microsoft Graph permissions.
- **Crash recovery:** active work is checkpointed every minute. After an unexpected shutdown, the app offers to save time through the last heartbeat or discard it.
- **Notification-area mode:** minimize the launcher while sessions continue; open the dashboard, close all sessions, or exit from the tray icon.
- **Two-computer synchronization:** each computer writes its own tenant catalog, audit log, time log, and recovery file. Catalog records merge by tenant and modification time, deletions use tombstones, conflicts are counted, and daily backups are retained.

- **Faster everyday use:** tenant and work-log data are cached until their files change, search waits briefly until typing pauses, and the customer grid uses recycled virtualized rows.
- **Lighter session monitoring:** Edge processes are inspected once per monitoring pass for all active tenants, and the grid no longer redraws continuously when no sessions are active.
- **Faster secure launch:** temporary Edge profiles omit disposable browser caches while retaining the persistent 1Password extension configuration.

- **PeakNet MSP connection:** sign in interactively to the PeakNet partner tenant with Microsoft MFA and synchronize delegated customers from Microsoft Graph.
- **Read-only GDAP discovery:** the app requests only `User.Read` and `DelegatedAdminRelationship.Read.All`; it does not create, change, or remove GDAP relationships.
- **Relationship visibility:** synchronized customers show GDAP status, expiration, relationship name, and relationship-level role information. Local-only tenants remain available and are labelled `LOCAL`.
- **Local token boundary:** OAuth access and refresh tokens exist only in the running launcher process and are cleared on disconnect or exit. They are never written to OneDrive or the tenant catalog.

- **Customer safety banner and colours:** every tenant can have a colour, role, contact, tags, and non-secret notes. The selected customer is shown prominently before launch.
- **Launch confirmation and work context:** opening a session confirms the customer/account/role and optionally records a ticket, work description, and billable status.
- **Portal shortcuts:** while a customer session is active, **Open portal** opens Microsoft 365, Entra, Azure, Exchange, Intune, Defender, Purview, or Teams in the same isolated Edge profile.
- **Four startup tabs:** every new secure Edge session opens Microsoft 365 Admin, Microsoft Entra, Microsoft Intune, and Microsoft Security/Defender as four tabs routed to the selected tenant and configured account.
- **Session dashboard:** the main grid shows every active session, start time, ticket, live elapsed time, and cleanup status.
- **Favorites and tags:** use **Pin / unpin** to keep important customers first. Search includes customer, tenant, UPN, role, and tags; pinned customers sort before recent and alphabetical entries.
- **Tenant notes:** **Edit** stores contact details and operational notes. Never place passwords, MFA data, recovery codes, tokens, or other secrets in notes.
- **Catalog backup/import:** **Backup / import** exports tenant metadata to JSON or merges/replaces it from a previous backup.
- **Security checks:** detects invalid/duplicate tenants, missing or malformed UPNs, undocumented roles, duplicate UPNs, possible secrets in notes, Global Administrator usage, and sessions open longer than four hours.
- **Role awareness:** each admin UPN has an explicitly documented role. This is operator-maintained metadata and is not a claim derived from Microsoft Graph.
- **Integrity and signed-update support:** **Verify app / update** checks the local release manifest and Authenticode status, and can validate a downloaded signed PowerShell update against a pinned publisher certificate thumbprint.

## External email forwarding

- Select a customer and choose **External email forwarding** in the workspace menu.
- Choose either **MSP delegated access (GDAP)** or **Direct customer administrator** authentication.
- Enter the source mailbox and the external destination, and choose whether Exchange should retain a local copy.
- **Check current** reads the mailbox-level forwarding state before a change.
- **Apply forwarding** validates the addresses and tenant domains, requires a customer-authorization checkbox and final warning confirmation, applies `Set-Mailbox`, and reads the mailbox again to verify the result.
- **Disable forwarding** removes only external SMTP forwarding and verifies that it is gone; an unrelated internal forwarding recipient is left unchanged.
- Every check, enable, disable, and failure is recorded in the metadata-only application audit log.
- The feature uses the installed Microsoft `ExchangeOnlineManagement` module and interactive modern authentication. It does not collect or store credentials or Exchange tokens.
- The tenant outbound spam policy, remote-domain settings, and mail-flow rules can still block external forwarding. The app intentionally does not change those protections.
- Use the Exchange Administrator role or an appropriately scoped GDAP role. Global Administrator is not required merely to configure mailbox forwarding.
## Security model

- Does **not** collect or store passwords, MFA secrets, browser tokens, or recovery codes.
- Keeps one persistent Microsoft Edge **template** containing the 1Password extension and its InPrivate permission.
- Creates a separate temporary copy of that template for every customer, allowing multiple customer sessions at the same time without sharing an Edge profile.
- Opens customer access only in Edge InPrivate windows, with browser sync and background mode disabled.
- Closes only the selected customer's Edge processes and removes that customer's complete temporary profile when you use **Close session**.
- Allows only one launcher instance to manage the profiles, while that launcher can run many customer sessions.
- Terminates and erases orphaned customer profiles at startup if Windows previously interrupted the launcher.
- Stores sync-safe tenant metadata, per-computer time logs, audit records, settings, recovery checkpoints, and backups under `Clients\_PeakNet Tenant Access`.
- Keeps Edge profiles, cookies, 1Password data, and OAuth tokens outside the shared folder. The non-secret MSP Tenant ID, Application ID, and last account name can synchronize between computers.
- Tracks browser-session time without storing credentials, tokens, page contents, or browser activity.

## Run

1. Keep the launcher script, VBS launcher, icon, and tenant catalog together in the application folder.
2. Double-click `Start-MSP-Tenant-Launcher.vbs`. It launches the application without opening a PowerShell or Command Prompt window.
3. Select **Set up 1Password** the first time you use the dedicated Edge profile.
4. Install 1Password in the Edge template. In `edge://extensions`, open its details and enable **Allow in InPrivate**, then close the template window.
5. Add or select a customer and click **Open secure Edge**.
6. Use the 1Password extension to authenticate and complete MFA.
7. Repeat for other customers as needed; each receives a separate Edge process/profile tree.
8. When finished, select each customer and click **Close session**, or close the launcher to end and erase every active customer session.
9. To finish all tenant work at once, click **Close all sessions** and confirm. This stops every launcher-managed tenant Edge process and erases all temporary session profiles without removing the persistent 1Password template.

## Time tracking

- Tracking starts when **Open secure Edge** successfully creates a customer session.
- Tracking stops when you click **Close session**, close that customer's Edge browser, or close the launcher.
- The **ELAPSED** column shows the live duration of every active customer session.
- Select **Work log** to see today's time, total time, session count, and the latest completed session for each customer. The **Monthly by tenant** tab shows total, billable, and non-billable time for every customer month by month, with a separate monthly CSV export. Sessions crossing a month boundary are divided correctly between both months.
- The detailed entries tab includes ticket numbers, work notes, manual positive/negative adjustments, and CSV export.
- Completed sessions are appended to `Clients\_PeakNet Tenant Access\TimeTracking\time-entries-COMPUTER.jsonl`. Each computer writes its own file to avoid synchronization conflicts.
- Records contain only customer/tenant metadata, the configured admin account, timestamps, duration, computer/user names, and how the session ended. They contain no password, MFA secret, token, cookie, or browsing data.
- Time means the duration that the isolated tenant browser session remained open, minus system-idle time when idle exclusion is enabled. The app reads only Windows' last-input timestamp and never records what was typed or viewed.

## Shared two-computer data

The synchronized data root is:

`C:\Users\<user>\PEAKNET\PEAKNET Security - Dokumenter\Clients\_PeakNet Tenant Access`

The launcher creates separate `Catalog`, `TimeTracking`, `Audit`, `Recovery`, `Backups`, and `Logos` folders. Each computer writes files containing its computer name, while the app merges all catalog sources and time logs when reading. A catalog refresh runs every minute so changes arriving from the other computer appear without restarting. If the shared location is unavailable, the app falls back to `%LOCALAPPDATA%\MSPTenantLauncher\SharedDataFallback` rather than preventing secure-session cleanup.

## Microsoft 365 MSP / GDAP connection

See `MSP-CONNECTION-SETUP.md` for the one-time Entra app registration. In the launcher, select **Connect MSP**, enter the partner Tenant ID and public-client Application ID, and complete Microsoft sign-in. The first successful connection synchronizes customers automatically; use **Sync GDAP** for later refreshes.

The Tenant ID, Application ID, and last connected UPN are stored in the shared app-data folder. These identifiers are not credentials. Access and refresh tokens remain in memory only, so the MSP account must reconnect independently on each computer after the launcher exits.

Synchronization matches records by customer Tenant ID. It updates Microsoft-owned fields such as customer display name and GDAP status while preserving local favorites, tags, colours, contacts, notes, portal preference, time records, and any previously configured customer-specific administrator UPN.

## Integrity and code signing

`release-manifest.json` contains the expected SHA-256 hash for the installed launcher. This detects accidental corruption or an incomplete OneDrive update, but a hash stored beside the script is not by itself publisher authentication.

For trusted production updates, PeakNet should sign `MSP-Tenant-Launcher.ps1` with its Authenticode code-signing certificate and place the approved certificate thumbprint (hexadecimal characters only) in `trusted-publisher.txt`. The update verifier accepts a downloaded package as PeakNet-trusted only when the signature is valid and the signer matches that pinned thumbprint. The current build remains usable without a certificate and reports its unsigned status honestly.

No installation or administrator rights are required. Microsoft Edge must be installed.

## Tenant catalog and ordering

The included `tenant-catalog.json` contains 118 customer tenant names and exact Directory/Tenant ID GUIDs from the supplied Microsoft 365 tenant list. It intentionally leaves admin usernames blank where the source did not provide a verified UPN. Those rows show **Choose at sign-in** until you edit them with an exact account such as `admin@customer-domain.dk`.

Opening a tenant records a `lastUsed` timestamp. Previously used tenants are shown first, newest first; tenants that have not been used are sorted alphabetically. This non-secret timestamp is synchronized with the shared tenant catalog.

Customer names are shown prominently, with the technical tenant ID underneath in smaller text. Use the search field to filter by customer name, tenant ID, or configured admin account.

## Recommended Entra controls

- Use a separate cloud-only administrator identity for each tenant; do not use a normal mailbox account.
- Prefer phishing-resistant MFA (FIDO2/passkeys) and Conditional Access.
- Use Privileged Identity Management for just-in-time Global Administrator elevation where licensing allows it.
- Prefer GDAP and least-privileged roles over permanent Global Administrator access wherever possible.
- Maintain two monitored emergency access accounts per tenant, excluded only from controls that could cause lockout.

## Important limitations

- This tool cannot grant access; the configured account must already exist and have the required tenant role.
- For exact tenant routing, enter the Directory/Tenant ID GUID from **Entra ID > Overview > Properties**. A normal email domain is used only as a label because it is not always a registered Entra tenant domain.
- Closing an individual Edge window manually does not update the launcher's status immediately. Use **Close session** to guarantee that every Edge process for that customer profile is stopped and its profile is removed.
- Forced termination can interrupt an unfinished browser download or form submission.
- The audit log records launcher activity, not successful Microsoft authentication. Use Entra sign-in and audit logs as the authoritative record.
- The Edge template, 1Password extension configuration, tenant catalog, and metadata-only audit log remain on the PC by design. Each customer profile—including its cookies, cache, history, and local browser storage—is removed after its Edge processes stop. Windows, network infrastructure, Microsoft, 1Password, or security tooling may still retain appropriate operating-system, DNS, proxy, sign-in, extension, or audit records, so no application can honestly guarantee that absolutely no trace exists anywhere.

## Secure online updates

Version 5.3 adds a professional GitHub Releases update channel. Use **Check for updates** in the left menu. The app verifies a detached PeakNet publisher signature, restricts downloads to the official PeakNet release repository, checks the package size and SHA-256 hash, and refuses installation while any tenant session is active. The updater stages and validates the release, backs up the current program files, installs after the launcher exits, rolls back on failure, and restarts the app. Tenant catalogs, time entries, audit data, customer logos, settings, and MSP credentials are never part of the release package.

Publishing instructions are in `GITHUB-RELEASES-SETUP.md`.