﻿[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$RequestPath,
    [Parameter(Mandatory)][string]$StatusPath,
    [Parameter(Mandatory)][string]$ResultPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-WorkerStatus([string]$Message) {
    $Message | Add-Content -LiteralPath $StatusPath -Encoding UTF8
}

function Test-EmailAddress([string]$Value) {
    try {
        $address = [Net.Mail.MailAddress]::new($Value)
        return $address.Address -eq $Value
    } catch { return $false }
}

function Get-ForwardingDescription($Mailbox) {
    $smtp = [string]$Mailbox.ForwardingSmtpAddress
    $internal = [string]$Mailbox.ForwardingAddress
    if (-not $smtp -and -not $internal) {
        return "Mailbox: $([string]$Mailbox.PrimarySmtpAddress)`r`nForwarding: Disabled"
    }
    return "Mailbox: $([string]$Mailbox.PrimarySmtpAddress)`r`nExternal forwarding: $(if($smtp){$smtp}else{'None'})`r`nInternal forwarding: $(if($internal){$internal}else{'None'})`r`nKeep local copy: $([bool]$Mailbox.DeliverToMailboxAndForward)"
}

$result = [ordered]@{ Success=$false; Message='The Exchange Online operation did not complete.' }
$connected = $false
try {
    $request = Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8 | ConvertFrom-Json
    Import-Module ExchangeOnlineManagement -MinimumVersion 3.0 -ErrorAction Stop
    Write-WorkerStatus 'A Microsoft device sign-in is required. The code shown below is also copied by the PeakNet app.'
    $parameters = @{
        Device = $true
        ShowBanner = $false
        ShowProgress = $false
        SkipLoadingFormatData = $true
        CommandName = @('Get-Mailbox','Set-Mailbox','Get-AcceptedDomain')
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$request.Login)) { $parameters.UserPrincipalName = [string]$request.Login }
    if ([string]$request.Authentication -eq 'GDAP') { $parameters.DelegatedOrganization = [string]$request.Tenant }
    Connect-ExchangeOnline @parameters -ErrorAction Stop 6>&1 | ForEach-Object { Write-WorkerStatus ([string]$_) }
    $connected = $true
    Write-WorkerStatus 'Microsoft sign-in completed. Running the requested Exchange Online operation...'

    $source = ([string]$request.Source).Trim()
    if (-not (Test-EmailAddress $source)) { throw 'Enter a valid source mailbox address.' }
    switch ([string]$request.Action) {
        'Check' {
            $mailbox = Get-Mailbox -Identity $source -ErrorAction Stop
            $result.Success = $true
            $result.Message = Get-ForwardingDescription $mailbox
        }
        'Apply' {
            $destination = ([string]$request.Destination).Trim()
            if (-not (Test-EmailAddress $destination)) { throw 'Enter a valid external destination address.' }
            if ($source -eq $destination) { throw 'The source and destination must be different.' }
            $domain = $destination.Split('@')[-1].ToLowerInvariant()
            $accepted = @(Get-AcceptedDomain -ErrorAction Stop | ForEach-Object { ([string]$_.DomainName).ToLowerInvariant() })
            if ($accepted -contains $domain) { throw "The destination domain $domain belongs to this tenant. Enter an external address." }
            [void](Get-Mailbox -Identity $source -ErrorAction Stop)
            Set-Mailbox -Identity $source -ForwardingAddress $null -ForwardingSmtpAddress $destination -DeliverToMailboxAndForward ([bool]$request.KeepCopy) -ErrorAction Stop
            $verified = Get-Mailbox -Identity $source -ErrorAction Stop
            if (([string]$verified.ForwardingSmtpAddress) -notmatch [regex]::Escape($destination)) { throw 'Exchange did not return the requested destination during verification.' }
            $result.Success = $true
            $result.Message = "Forwarding applied and verified.`r`n`r`n$(Get-ForwardingDescription $verified)"
        }
        'Disable' {
            [void](Get-Mailbox -Identity $source -ErrorAction Stop)
            Set-Mailbox -Identity $source -ForwardingSmtpAddress $null -DeliverToMailboxAndForward $false -ErrorAction Stop
            $verified = Get-Mailbox -Identity $source -ErrorAction Stop
            if (-not [string]::IsNullOrWhiteSpace([string]$verified.ForwardingSmtpAddress)) { throw 'Verification shows external forwarding is still configured.' }
            $result.Success = $true
            $result.Message = "External forwarding disabled and verified.`r`n`r`n$(Get-ForwardingDescription $verified)"
        }
        default { throw 'Unknown Exchange Online action.' }
    }
} catch {
    $result.Message = $_.Exception.Message
} finally {
    if ($connected) { try { Disconnect-ExchangeOnline -Confirm:$false -ErrorAction SilentlyContinue } catch {} }
    $result | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $ResultPath -Encoding UTF8
}
