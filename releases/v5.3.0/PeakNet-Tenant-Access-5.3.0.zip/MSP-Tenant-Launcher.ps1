[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class PeakNetIdleTime {
    [StructLayout(LayoutKind.Sequential)] public struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }
    [DllImport("user32.dll")] static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);
    public static double Seconds() {
        var info = new LASTINPUTINFO(); info.cbSize = (uint)Marshal.SizeOf(info);
        return GetLastInputInfo(ref info) ? unchecked((uint)Environment.TickCount - info.dwTime) / 1000.0 : 0;
    }
}
public static class PeakNetWindowIdentity {
    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    public static extern int SetCurrentProcessExplicitAppUserModelID(string appID);
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    public static extern IntPtr SendMessage(IntPtr hWnd, uint message, IntPtr wParam, IntPtr lParam);
}
'@

# Give the hosted PowerShell process a distinct Windows shell identity. Without this,
# the taskbar groups the window under powershell.exe and shows the PowerShell icon.
[void][PeakNetWindowIdentity]::SetCurrentProcessExplicitAppUserModelID('PeakNet.TenantAccess')
$script:PeakNetUiIconPath = $null

trap {
    [System.Windows.MessageBox]::Show(
        "PeakNet Tenant Access could not start.`n`n$($_.Exception.Message)",
        'PeakNet Tenant Access',
        'OK',
        'Error'
    ) | Out-Null
    break
}

function Set-PeakNetModernControl([System.Windows.Forms.Control]$Control) {
    $ink = [Drawing.ColorTranslator]::FromHtml('#142926')
    $muted = [Drawing.ColorTranslator]::FromHtml('#60706D')
    $surface = [Drawing.Color]::White
    $soft = [Drawing.ColorTranslator]::FromHtml('#EEF5F3')
    $line = [Drawing.ColorTranslator]::FromHtml('#D8DFDC')
    $accent = [Drawing.ColorTranslator]::FromHtml('#197782')

    if ($Control -is [System.Windows.Forms.Form]) {
        $Control.BackColor = [Drawing.ColorTranslator]::FromHtml('#F4F5F2')
        $Control.ForeColor = $ink
        $Control.Font = [Drawing.Font]::new('Segoe UI', 10)
        $Control.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi
        if ($script:PeakNetUiIconPath -and (Test-Path -LiteralPath $script:PeakNetUiIconPath)) {
            try { $Control.Icon = [Drawing.Icon]::new($script:PeakNetUiIconPath) } catch {}
        }
    } elseif ($Control -is [System.Windows.Forms.Button]) {
        $Control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $Control.FlatAppearance.BorderColor = $line
        $Control.FlatAppearance.BorderSize = 1
        $Control.BackColor = $surface
        $Control.ForeColor = $ink
        $Control.Font = [Drawing.Font]::new('Segoe UI Semibold', 9.5)
        $Control.Cursor = [System.Windows.Forms.Cursors]::Hand
        $Control.UseVisualStyleBackColor = $false
        if ($Control.Text -match '^(Save|Start secure|Open portal|Refresh)$') {
            $Control.BackColor = $accent
            $Control.ForeColor = [Drawing.Color]::White
            $Control.FlatAppearance.BorderColor = $accent
        } elseif ($Control.Text -match '^(Remove|Close all)') {
            $Control.ForeColor = [Drawing.ColorTranslator]::FromHtml('#B2473D')
        }
    } elseif ($Control -is [System.Windows.Forms.DataGridView]) {
        $Control.BackgroundColor = $surface
        $Control.BorderStyle = [System.Windows.Forms.BorderStyle]::None
        $Control.CellBorderStyle = [System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal
        $Control.ColumnHeadersBorderStyle = [System.Windows.Forms.DataGridViewHeaderBorderStyle]::None
        $Control.EnableHeadersVisualStyles = $false
        $Control.GridColor = [Drawing.ColorTranslator]::FromHtml('#E5EAE7')
        $Control.RowHeadersVisible = $false
        $Control.RowTemplate.Height = 36
        $Control.ColumnHeadersHeight = 40
        $Control.ColumnHeadersHeightSizeMode = [System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode]::DisableResizing
        $Control.ColumnHeadersDefaultCellStyle.BackColor = [Drawing.ColorTranslator]::FromHtml('#E8ECE9')
        $Control.ColumnHeadersDefaultCellStyle.ForeColor = $muted
        $Control.ColumnHeadersDefaultCellStyle.Font = [Drawing.Font]::new('Segoe UI Semibold', 9)
        $Control.ColumnHeadersDefaultCellStyle.Padding = [System.Windows.Forms.Padding]::new(7, 0, 7, 0)
        $Control.DefaultCellStyle.BackColor = $surface
        $Control.DefaultCellStyle.ForeColor = $ink
        $Control.DefaultCellStyle.SelectionBackColor = [Drawing.ColorTranslator]::FromHtml('#E3F0ED')
        $Control.DefaultCellStyle.SelectionForeColor = $ink
        $Control.DefaultCellStyle.Padding = [System.Windows.Forms.Padding]::new(7, 4, 7, 4)
        $Control.AlternatingRowsDefaultCellStyle.BackColor = [Drawing.ColorTranslator]::FromHtml('#FAFBF9')
    } elseif ($Control -is [System.Windows.Forms.TabControl]) {
        $Control.Appearance = [System.Windows.Forms.TabAppearance]::FlatButtons
        $Control.SizeMode = [System.Windows.Forms.TabSizeMode]::Fixed
        $Control.ItemSize = [Drawing.Size]::new(155, 34)
        $Control.Padding = [Drawing.Point]::new(12, 5)
    } elseif ($Control -is [System.Windows.Forms.TabPage]) {
        $Control.BackColor = $surface
        $Control.ForeColor = $ink
        $Control.Padding = [System.Windows.Forms.Padding]::new(8)
    } elseif ($Control -is [System.Windows.Forms.TextBox]) {
        $Control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $Control.BackColor = $surface
        $Control.ForeColor = $ink
    } elseif ($Control -is [System.Windows.Forms.ComboBox]) {
        $Control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $Control.BackColor = $surface
        $Control.ForeColor = $ink
    } elseif ($Control -is [System.Windows.Forms.ListBox]) {
        $Control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $Control.BackColor = $surface
        $Control.ForeColor = $ink
        $Control.ItemHeight = 28
    } elseif ($Control -is [System.Windows.Forms.NumericUpDown]) {
        $Control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
        $Control.BackColor = $surface
        $Control.ForeColor = $ink
    } elseif ($Control -is [System.Windows.Forms.CheckBox]) {
        $Control.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
        $Control.ForeColor = $ink
    } elseif ($Control -is [System.Windows.Forms.Label]) {
        if ($Control.ForeColor -eq [Drawing.SystemColors]::ControlText) { $Control.ForeColor = $ink }
    }

    foreach ($child in @($Control.Controls)) { Set-PeakNetModernControl $child }
}

function Set-PeakNetModernForm([System.Windows.Forms.Form]$Form) {
    Set-PeakNetModernControl $Form
    $Form.MinimumSize = [Drawing.Size]::new([Math]::Min(520, $Form.Width), [Math]::Min(340, $Form.Height))
}

$createdNew = $false
$LauncherMutex = [Threading.Mutex]::new($true, 'Local\PeakNetTenantAccess', [ref]$createdNew)
if (-not $createdNew) {
    [System.Windows.MessageBox]::Show('PeakNet Tenant Access is already running. Use the existing launcher window for all customer sessions.', 'Already running', 'OK', 'Information') | Out-Null
    $LauncherMutex.Dispose()
    return
}

$AppRoot = Join-Path $env:LOCALAPPDATA 'MSPTenantLauncher'
$safeComputerName = ([string]$env:COMPUTERNAME -replace '[^A-Za-z0-9_.-]', '_')
$LegacyConfigPath = Join-Path $AppRoot 'tenants.json'
$LegacyMspConfigPath = Join-Path $AppRoot 'msp-connection.json'
$SettingsPath = Join-Path $AppRoot 'settings.json'
$SessionRoot = Join-Path $AppRoot 'Sessions'
$EdgeTemplateRoot = Join-Path $AppRoot 'EdgeProfile'
New-Item -ItemType Directory -Force -Path $AppRoot, $SessionRoot, $EdgeTemplateRoot | Out-Null
$ClientsRoot = Join-Path $env:USERPROFILE 'PEAKNET\PEAKNET Security - Dokumenter\Clients'
$SharedDataRoot = Join-Path $ClientsRoot '_PeakNet Tenant Access'
$CatalogRoot = Join-Path $SharedDataRoot 'Catalog'
$TimeTrackingRoot = Join-Path $SharedDataRoot 'TimeTracking'
$RecoveryRoot = Join-Path $SharedDataRoot 'Recovery'
$BackupRoot = Join-Path $SharedDataRoot 'Backups'
$AuditRoot = Join-Path $SharedDataRoot 'Audit'
$LogoRoot = Join-Path $SharedDataRoot 'Logos'
try {
    New-Item -ItemType Directory -Force -Path $SharedDataRoot,$CatalogRoot,$TimeTrackingRoot,$RecoveryRoot,$BackupRoot,$AuditRoot,$LogoRoot -ErrorAction Stop | Out-Null
} catch {
    $SharedDataRoot = Join-Path $AppRoot 'SharedDataFallback'
    $CatalogRoot = Join-Path $SharedDataRoot 'Catalog'; $TimeTrackingRoot = Join-Path $SharedDataRoot 'TimeTracking'
    $RecoveryRoot = Join-Path $SharedDataRoot 'Recovery'; $BackupRoot = Join-Path $SharedDataRoot 'Backups'; $AuditRoot = Join-Path $SharedDataRoot 'Audit'; $LogoRoot = Join-Path $SharedDataRoot 'Logos'
    New-Item -ItemType Directory -Force -Path $SharedDataRoot,$CatalogRoot,$TimeTrackingRoot,$RecoveryRoot,$BackupRoot,$AuditRoot,$LogoRoot | Out-Null
}
$SettingsPath = Join-Path $SharedDataRoot 'settings.json'
$MspConfigPath = Join-Path $SharedDataRoot 'msp-connection.json'
$ConfigPath = Join-Path $CatalogRoot ("tenants-{0}.json" -f $safeComputerName)
$DeletionPath = Join-Path $CatalogRoot ("deleted-{0}.jsonl" -f $safeComputerName)
$RecoveryPath = Join-Path $RecoveryRoot ("active-{0}.json" -f $safeComputerName)
$AuditPath = Join-Path $AuditRoot ("audit-{0}.log" -f $safeComputerName)
$TimeTrackingFile = Join-Path $TimeTrackingRoot ("time-entries-{0}.jsonl" -f $safeComputerName)
$legacyTimeRoot = Join-Path $PSScriptRoot 'TimeTracking'
$migrationMarker = Join-Path $SharedDataRoot ("migration-{0}-v4.done" -f $safeComputerName)
if (-not (Test-Path -LiteralPath $migrationMarker) -and (Test-Path -LiteralPath $LegacyConfigPath)) {
    if (Test-Path -LiteralPath $ConfigPath) { Copy-Item -LiteralPath $ConfigPath -Destination (Join-Path $BackupRoot ("pre-v4-{0}-{1}.json" -f $safeComputerName,[DateTime]::Now.ToString('yyyyMMdd-HHmmss'))) -Force }
    Copy-Item -LiteralPath $LegacyConfigPath -Destination $ConfigPath -Force
    New-Item -ItemType File -Path $migrationMarker -Force | Out-Null
}
if (-not (Test-Path -LiteralPath $MspConfigPath) -and (Test-Path -LiteralPath $LegacyMspConfigPath)) { Copy-Item -LiteralPath $LegacyMspConfigPath -Destination $MspConfigPath -Force }
if (Test-Path -LiteralPath $legacyTimeRoot) {
    foreach ($legacyTimeFile in @(Get-ChildItem -LiteralPath $legacyTimeRoot -Filter 'time-entries-*.jsonl' -File -ErrorAction SilentlyContinue)) {
        $sharedTimeFile = Join-Path $TimeTrackingRoot $legacyTimeFile.Name
        if (-not (Test-Path -LiteralPath $sharedTimeFile)) { Copy-Item -LiteralPath $legacyTimeFile.FullName -Destination $sharedTimeFile -Force; continue }
        $knownSessionIds=@{};foreach($line in @(Get-Content -LiteralPath $sharedTimeFile -Encoding UTF8 -ErrorAction SilentlyContinue)){try{$item=$line|ConvertFrom-Json;$knownSessionIds[[string]$item.sessionId]=$true}catch{}}
        $missingLines=[Collections.Generic.List[string]]::new();foreach($line in @(Get-Content -LiteralPath $legacyTimeFile.FullName -Encoding UTF8 -ErrorAction SilentlyContinue)){try{$item=$line|ConvertFrom-Json;if(-not$knownSessionIds.ContainsKey([string]$item.sessionId)){$missingLines.Add($line);$knownSessionIds[[string]$item.sessionId]=$true}}catch{}}
        if($missingLines.Count){$missingLines|Add-Content -LiteralPath $sharedTimeFile -Encoding UTF8}
    }
}
$ReleaseManifestPath = Join-Path $PSScriptRoot 'release-manifest.json'
$TrustedPublisherPath = Join-Path $PSScriptRoot 'trusted-publisher.txt'
$UpdateConfigPath = Join-Path $PSScriptRoot 'Update-Config.json'
$UpdatePublisherCertificatePath = Join-Path $PSScriptRoot 'PeakNet-Update-Publisher.cer'
$UpdaterScriptPath = Join-Path $PSScriptRoot 'PeakNet-Updater.ps1'
$script:UpdateInProgress = $false
$script:MspConnection = $null
$script:TenantCache = $null
$script:TenantCacheSignature = ''
$script:TimeEntriesCache = $null
$script:TimeEntriesCacheSignature = ''
$script:CatalogComputerCount = 0
$script:CatalogConflictCount = 0
$script:CustomerFolderDirectories = $null

function Write-Audit([string]$Action, [string]$TenantName) {
    $safeName = $TenantName -replace "[\r\n|]", ' '
    $line = '{0:o}|{1}|{2}|{3}' -f [DateTime]::UtcNow, $env:USERNAME, $Action, $safeName
    Add-Content -LiteralPath $AuditPath -Value $line -Encoding UTF8
}

function Format-Duration([double]$Seconds) {
    $sign = if ($Seconds -lt 0) { '-' } else { '' }
    $totalSeconds = [Math]::Floor([Math]::Abs($Seconds))
    $span = [TimeSpan]::FromSeconds($totalSeconds)
    if ($span.TotalHours -ge 1) { return $sign + ('{0}h {1:00}m' -f [Math]::Floor($span.TotalHours), $span.Minutes) }
    if ($span.TotalMinutes -ge 1) { return $sign + ('{0}m {1:00}s' -f [Math]::Floor($span.TotalMinutes), $span.Seconds) }
    return $sign + ('{0}s' -f $span.Seconds)
}

function ConvertTo-UtcDateTime($Value) {
    if ($Value -is [DateTime]) { return ([DateTime]$Value).ToUniversalTime() }
    return [DateTime]::Parse([string]$Value,[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::RoundtripKind).ToUniversalTime()
}

function Get-SystemIdleSeconds { try { return [PeakNetIdleTime]::Seconds() } catch { return 0 } }

function Get-SessionTrackedSeconds($Session, [DateTime]$NowUtc = [DateTime]::UtcNow) {
    $idleSeconds = if ($Session.PSObject.Properties.Name -contains 'IdleSeconds') { [double]$Session.IdleSeconds } else { 0 }
    return [Math]::Max(0, ($NowUtc - $Session.StartedUtc).TotalSeconds - $idleSeconds)
}

function Complete-TimeEntry($Session, [string]$Reason) {
    if (-not $Session -or $Session.TimeSaved) { return $true }
    try {
        $endedUtc = [DateTime]::UtcNow
        $idleSeconds = if ($Session.PSObject.Properties.Name -contains 'IdleSeconds') { [double]$Session.IdleSeconds } else { 0 }
        $durationSeconds = [Math]::Max(0, [Math]::Round(($endedUtc - $Session.StartedUtc).TotalSeconds - $idleSeconds))
        $entry = [ordered]@{
            version = 2
            sessionId = [string]$Session.Id
            computer = [string]$env:COMPUTERNAME
            windowsUser = [string]$env:USERNAME
            customer = [string]$Session.Name
            tenant = [string]$Session.Tenant
            adminAccount = [string]$Session.Admin
            startedUtc = $Session.StartedUtc.ToString('o')
            endedUtc = $endedUtc.ToString('o')
            durationSeconds = [int64]$durationSeconds
            endReason = $Reason
            entryType = 'session'
            ticket = [string]$Session.Ticket
            workNotes = [string]$Session.WorkNotes
            billable = [bool]$Session.Billable
            idleExcludedSeconds = [int64][Math]::Round($idleSeconds)
        }
        ($entry | ConvertTo-Json -Compress) | Add-Content -LiteralPath $TimeTrackingFile -Encoding UTF8 -ErrorAction Stop
        $script:TimeEntriesCacheSignature = ''
        $Session.TimeSaved = $true
        try { Write-Audit 'TIME_ENTRY_SAVED' $Session.Name } catch {}
        return $true
    } catch {
        try { Write-Audit 'TIME_ENTRY_SAVE_FAILED' $Session.Name } catch {}
        return $false
    }
}

function Save-RecoveryState {
    try {
        if (-not $sessions -or $sessions.Count -eq 0) {
            Remove-Item -LiteralPath $RecoveryPath -Force -ErrorAction SilentlyContinue
            return
        }
        $nowUtc = [DateTime]::UtcNow
        $records = @($sessions.Values | ForEach-Object {
            [ordered]@{
                sessionId=[string]$_.Id; customer=[string]$_.Name; tenant=[string]$_.Tenant; adminAccount=[string]$_.Admin
                startedUtc=$_.StartedUtc.ToString('o'); lastHeartbeatUtc=$nowUtc.ToString('o'); idleExcludedSeconds=[double]$_.IdleSeconds
                ticket=[string]$_.Ticket; workNotes=[string]$_.WorkNotes; billable=[bool]$_.Billable; computer=[string]$env:COMPUTERNAME
            }
        })
        $tempPath = Join-Path $RecoveryRoot ('.active-{0}-{1}.tmp' -f $safeComputerName,[guid]::NewGuid().ToString('N'))
        ConvertTo-Json -InputObject $records -Depth 4 | Set-Content -LiteralPath $tempPath -Encoding UTF8
        Move-Item -LiteralPath $tempPath -Destination $RecoveryPath -Force
    } catch { try { Write-Audit 'RECOVERY_CHECKPOINT_FAILED' ([string]$env:COMPUTERNAME) } catch {} }
}

function Recover-InterruptedSessions {
    if (-not (Test-Path -LiteralPath $RecoveryPath)) { return }
    try { $records = @(Get-Content -LiteralPath $RecoveryPath -Raw -Encoding UTF8 | ConvertFrom-Json) } catch { $records=@() }
    if ($records.Count) {
        $names = @($records | ForEach-Object { [string]$_.customer }) -join "`n"
        $choice = [System.Windows.MessageBox]::Show("The previous launcher session did not close normally.`n`nRecovered customer work:`n$names`n`nSelect Yes to save time through the last heartbeat. Select No to discard it.",'Recover interrupted work','YesNo','Warning')
        if ($choice -eq 'Yes') {
            $knownIds = @{}; foreach ($entry in @(Get-TimeEntries)) { $knownIds[[string]$entry.sessionId]=$true }
            foreach ($record in $records) {
                if ($knownIds.ContainsKey([string]$record.sessionId)) { continue }
                try {
                    $startedUtc=ConvertTo-UtcDateTime $record.startedUtc;$endedUtc=ConvertTo-UtcDateTime $record.lastHeartbeatUtc
                    $idle=[double]$record.idleExcludedSeconds;$seconds=[Math]::Max(0,[Math]::Round(($endedUtc-$startedUtc).TotalSeconds-$idle))
                    $entry=[ordered]@{version=2;sessionId=[string]$record.sessionId;computer=[string]$record.computer;windowsUser=[string]$env:USERNAME;customer=[string]$record.customer;tenant=[string]$record.tenant;adminAccount=[string]$record.adminAccount;startedUtc=$startedUtc.ToString('o');endedUtc=$endedUtc.ToString('o');durationSeconds=[int64]$seconds;endReason='Recovered after unexpected shutdown';entryType='session';ticket=[string]$record.ticket;workNotes=[string]$record.workNotes;billable=[bool]$record.billable;idleExcludedSeconds=[int64][Math]::Round($idle);recovered=$true}
                    ($entry|ConvertTo-Json -Compress)|Add-Content -LiteralPath $TimeTrackingFile -Encoding UTF8
                } catch {}
            }
            Write-Audit 'INTERRUPTED_SESSIONS_RECOVERED' ($records.Count.ToString())
        } else { Write-Audit 'INTERRUPTED_SESSIONS_DISCARDED' ($records.Count.ToString()) }
    }
    try {
        $backupName='recovery-{0}-{1}.json' -f $safeComputerName,[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')
        Copy-Item -LiteralPath $RecoveryPath -Destination (Join-Path $BackupRoot $backupName) -Force
    } catch {}
    Remove-Item -LiteralPath $RecoveryPath -Force -ErrorAction SilentlyContinue
    try{$notifyIcon.Visible=$false;$notifyIcon.Dispose();$trayMenu.Dispose()}catch{}
}

function Get-TimeEntries {
    $files = @(Get-ChildItem -LiteralPath $TimeTrackingRoot -Filter 'time-entries-*.jsonl' -File -ErrorAction SilentlyContinue | Sort-Object FullName)
    $signature = ($files | ForEach-Object { '{0}|{1}|{2}' -f $_.FullName, $_.Length, $_.LastWriteTimeUtc.Ticks }) -join ';'
    if ($null -ne $script:TimeEntriesCache -and $script:TimeEntriesCacheSignature -eq $signature) {
        foreach ($cachedEntry in @($script:TimeEntriesCache)) { Write-Output $cachedEntry }
        return
    }
    $loadedEntries = [Collections.Generic.List[object]]::new()
    foreach ($file in $files) {
        foreach ($line in @(Get-Content -LiteralPath $file.FullName -Encoding UTF8 -ErrorAction SilentlyContinue)) {
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            try { $loadedEntries.Add(($line | ConvertFrom-Json)) } catch {}
        }
    }
    $script:TimeEntriesCache = @($loadedEntries)
    $script:TimeEntriesCacheSignature = $signature
    foreach ($loadedEntry in @($script:TimeEntriesCache)) { Write-Output $loadedEntry }
}

function Get-TimeReportRows {
    $totals = @{}
    $todayStartUtc = [DateTime]::Today.ToUniversalTime()
    $nowUtc = [DateTime]::UtcNow
    foreach ($entry in @(Get-TimeEntries)) {
        $key = [string]$entry.tenant
        if (-not $totals.ContainsKey($key)) {
            $totals[$key] = [pscustomobject]@{ Customer=[string]$entry.customer; Tenant=$key; Seconds=[double]0; TodaySeconds=[double]0; BillableSeconds=[double]0; Sessions=0; LastEnded=[DateTime]::MinValue }
        }
        $totals[$key].Seconds += [double]$entry.durationSeconds
        $isAdjustment = $entry.PSObject.Properties.Name -contains 'entryType' -and [string]$entry.entryType -eq 'adjustment'
        $isBillable = -not ($entry.PSObject.Properties.Name -contains 'billable') -or [bool]$entry.billable
        if ($isBillable) { $totals[$key].BillableSeconds += [double]$entry.durationSeconds }
        if (-not $isAdjustment) { $totals[$key].Sessions++ }
        try {
            $started = ConvertTo-UtcDateTime $entry.startedUtc
            $ended = ConvertTo-UtcDateTime $entry.endedUtc
            if ($ended -gt $totals[$key].LastEnded) { $totals[$key].LastEnded = $ended }
            if ($isAdjustment) {
                if ($ended.ToLocalTime().Date -eq [DateTime]::Today) { $totals[$key].TodaySeconds += [double]$entry.durationSeconds }
            } else {
                $overlapStart = if ($started -gt $todayStartUtc) { $started } else { $todayStartUtc }
                if ($ended -gt $overlapStart) { $totals[$key].TodaySeconds += ($ended - $overlapStart).TotalSeconds }
            }
        } catch {}
    }
    foreach ($session in @($sessions.Values)) {
        $key = [string]$session.Tenant
        if (-not $totals.ContainsKey($key)) {
            $totals[$key] = [pscustomobject]@{ Customer=[string]$session.Name; Tenant=$key; Seconds=[double]0; TodaySeconds=[double]0; BillableSeconds=[double]0; Sessions=0; LastEnded=[DateTime]::MinValue }
        }
        $activeSeconds = Get-SessionTrackedSeconds $session $nowUtc
        $totals[$key].Seconds += $activeSeconds
        if ($session.Billable) { $totals[$key].BillableSeconds += $activeSeconds }
        $activeOverlapStart = if ($session.StartedUtc -gt $todayStartUtc) { $session.StartedUtc } else { $todayStartUtc }
        if ($nowUtc -gt $activeOverlapStart) { $totals[$key].TodaySeconds += ($nowUtc - $activeOverlapStart).TotalSeconds }
        $totals[$key].Sessions++
    }
    return @($totals.Values | Sort-Object Seconds -Descending | ForEach-Object {
        [pscustomobject][ordered]@{
            Customer = $_.Customer
            Today = Format-Duration $_.TodaySeconds
            'Total time' = Format-Duration $_.Seconds
            Billable = Format-Duration $_.BillableSeconds
            Sessions = $_.Sessions
            'Last completed' = if ($_.LastEnded -eq [DateTime]::MinValue) { 'Active now' } else { $_.LastEnded.ToLocalTime().ToString('yyyy-MM-dd HH:mm') }
        }
    })
}

function Get-TimeDetailRows {
    return @(Get-TimeEntries | Sort-Object { [string]$_.endedUtc } -Descending | ForEach-Object {
        $ended = try { (ConvertTo-UtcDateTime $_.endedUtc).ToLocalTime().ToString('yyyy-MM-dd HH:mm') } catch { [string]$_.endedUtc }
        [pscustomobject][ordered]@{
            Customer = [string]$_.customer
            Ended = $ended
            Duration = Format-Duration ([double]$_.durationSeconds)
            'Idle excluded' = if ($_.PSObject.Properties.Name -contains 'idleExcludedSeconds') { Format-Duration ([double]$_.idleExcludedSeconds) } else { '0s' }
            Billable = if ($_.PSObject.Properties.Name -contains 'billable' -and -not [bool]$_.billable) { 'No' } else { 'Yes' }
            Ticket = if ($_.PSObject.Properties.Name -contains 'ticket') { [string]$_.ticket } else { '' }
            Notes = if ($_.PSObject.Properties.Name -contains 'workNotes') { [string]$_.workNotes } else { '' }
            Type = if ($_.PSObject.Properties.Name -contains 'entryType') { [string]$_.entryType } else { 'session' }
        }
    })
}

function Get-MonthlyTimeReportRows([switch]$IncludeHours) {
    $buckets = @{}
    $nowUtc = [DateTime]::UtcNow
    $addToMonth = {
        param([DateTime]$MonthStart, [string]$Tenant, [string]$Customer, [double]$Seconds, [bool]$Billable, [bool]$CountSession)
        $bucketKey = '{0}|{1}' -f $MonthStart.ToString('yyyy-MM'), $Tenant.ToLowerInvariant()
        if (-not $buckets.ContainsKey($bucketKey)) {
            $buckets[$bucketKey] = [pscustomobject]@{ MonthStart=$MonthStart; Customer=$Customer; Tenant=$Tenant; Seconds=[double]0; BillableSeconds=[double]0; Sessions=0 }
        }
        $buckets[$bucketKey].Seconds += $Seconds
        if ($Billable) { $buckets[$bucketKey].BillableSeconds += $Seconds }
        if ($CountSession) { $buckets[$bucketKey].Sessions++ }
    }
    $addSession = {
        param([DateTime]$StartedUtc, [DateTime]$EndedUtc, [string]$Tenant, [string]$Customer, [bool]$Billable, [double]$TrackedSeconds = -1)
        if ($EndedUtc -le $StartedUtc) { return }
        $wallSeconds = ($EndedUtc - $StartedUtc).TotalSeconds
        $trackedFactor = if ($TrackedSeconds -ge 0 -and $wallSeconds -gt 0) { [Math]::Max(0,[Math]::Min(1,$TrackedSeconds/$wallSeconds)) } else { 1 }
        $cursor = $StartedUtc.ToLocalTime()
        $localEnd = $EndedUtc.ToLocalTime()
        while ($cursor -lt $localEnd) {
            $monthStart = [DateTime]::new($cursor.Year, $cursor.Month, 1)
            $nextMonth = $monthStart.AddMonths(1)
            $segmentEnd = if ($localEnd -lt $nextMonth) { $localEnd } else { $nextMonth }
            $seconds = ($segmentEnd.ToUniversalTime() - $cursor.ToUniversalTime()).TotalSeconds * $trackedFactor
            & $addToMonth $monthStart $Tenant $Customer $seconds $Billable $true | Out-Null
            $cursor = $segmentEnd
        }
    }
    foreach ($entry in @(Get-TimeEntries)) {
        $tenant = [string]$entry.tenant
        $customer = [string]$entry.customer
        $isAdjustment = $entry.PSObject.Properties.Name -contains 'entryType' -and [string]$entry.entryType -eq 'adjustment'
        $isBillable = -not ($entry.PSObject.Properties.Name -contains 'billable') -or [bool]$entry.billable
        try {
            $endedUtc = ConvertTo-UtcDateTime $entry.endedUtc
            if ($isAdjustment) {
                $localEnd = $endedUtc.ToLocalTime()
                $monthStart = [DateTime]::new($localEnd.Year, $localEnd.Month, 1)
                & $addToMonth $monthStart $tenant $customer ([double]$entry.durationSeconds) $isBillable $false | Out-Null
            } else {
                $startedUtc = ConvertTo-UtcDateTime $entry.startedUtc
                & $addSession $startedUtc $endedUtc $tenant $customer $isBillable ([double]$entry.durationSeconds) | Out-Null
            }
        } catch {
            # Damaged rows remain visible in the detailed export, but cannot be assigned to a month safely.
        }
    }
    foreach ($session in @($sessions.Values)) {
        & $addSession ([DateTime]$session.StartedUtc).ToUniversalTime() $nowUtc ([string]$session.Tenant) ([string]$session.Name) ([bool]$session.Billable) (Get-SessionTrackedSeconds $session $nowUtc) | Out-Null
    }
    return @($buckets.Values | Sort-Object @{Expression='MonthStart';Descending=$true}, @{Expression='Customer';Descending=$false} | ForEach-Object {
        if ($IncludeHours) {
            [pscustomobject][ordered]@{MonthKey=$_.MonthStart.ToString('yyyy-MM');Month=$_.MonthStart.ToString('yyyy-MM (MMMM)',[Globalization.CultureInfo]::CurrentCulture);Customer=$_.Customer;TotalHours=[Math]::Round($_.Seconds/3600,2);BillableHours=[Math]::Round($_.BillableSeconds/3600,2);NonBillableHours=[Math]::Round(($_.Seconds-$_.BillableSeconds)/3600,2);Sessions=$_.Sessions}
        } else {
            [pscustomobject][ordered]@{Month=$_.MonthStart.ToString('yyyy-MM (MMMM)',[Globalization.CultureInfo]::CurrentCulture);Customer=$_.Customer;'Total time'=Format-Duration $_.Seconds;Billable=Format-Duration $_.BillableSeconds;'Non-billable'=Format-Duration ($_.Seconds-$_.BillableSeconds);Sessions=$_.Sessions}
        }
    })
}

function Get-DeduplicatedTenants([array]$Items) {
    $bestByTenant = @{}
    $bestMetadata = @{}
    $latestUseByTenant = @{}
    foreach ($item in @($Items)) {
        if ($null -eq $item) { continue }
        if ($item.PSObject.Properties.Name -notcontains 'tenant') { continue }
        $tenantId = ([string]$item.tenant).Trim()
        if ([string]::IsNullOrWhiteSpace($tenantId)) { continue }
        $item.tenant = $tenantId
        $key = $tenantId.ToLowerInvariant()
        $modified = if ($item.PSObject.Properties.Name -contains 'modifiedUtc') {
            try { ConvertTo-UtcDateTime $item.modifiedUtc } catch { [DateTime]::MinValue }
        } else { [DateTime]::MinValue }
        $quality = 0
        if ($item.PSObject.Properties.Name -contains 'source' -and [string]$item.source -like 'Microsoft Graph*') { $quality += 4 }
        if ($item.PSObject.Properties.Name -contains 'username' -and -not [string]::IsNullOrWhiteSpace([string]$item.username)) { $quality += 2 }
        if ($item.PSObject.Properties.Name -contains 'favorite' -and [bool]$item.favorite) { $quality += 1 }
        if ($item.PSObject.Properties.Name -contains 'lastUsed' -and -not [string]::IsNullOrWhiteSpace([string]$item.lastUsed)) {
            try {
                $used = ConvertTo-UtcDateTime $item.lastUsed
                if (-not $latestUseByTenant.ContainsKey($key) -or $used -gt $latestUseByTenant[$key]) { $latestUseByTenant[$key] = $used }
            } catch {}
        }
        if (-not $bestByTenant.ContainsKey($key) -or $modified -gt $bestMetadata[$key].Modified -or ($modified -eq $bestMetadata[$key].Modified -and $quality -gt $bestMetadata[$key].Quality)) {
            $bestByTenant[$key] = $item
            $bestMetadata[$key] = [pscustomobject]@{ Modified=$modified; Quality=$quality }
        }
    }
    foreach ($key in @($latestUseByTenant.Keys)) {
        if ($bestByTenant.ContainsKey($key)) { $bestByTenant[$key] | Add-Member NoteProperty lastUsed ($latestUseByTenant[$key].ToString('o')) -Force }
    }
    return @($bestByTenant.Values)
}

function Load-Tenants {
    try {
        $catalogFiles = @(Get-ChildItem -LiteralPath $CatalogRoot -Filter 'tenants-*.json' -File -ErrorAction SilentlyContinue | Sort-Object FullName)
        $script:CatalogComputerCount = $catalogFiles.Count
        $deletionFiles = @(Get-ChildItem -LiteralPath $CatalogRoot -Filter 'deleted-*.jsonl' -File -ErrorAction SilentlyContinue | Sort-Object FullName)
        $allFiles = @($catalogFiles) + @($deletionFiles)
        $signature = ($allFiles | ForEach-Object { '{0}|{1}|{2}' -f $_.FullName,$_.Length,$_.LastWriteTimeUtc.Ticks }) -join ';'
        if ($null -ne $script:TenantCache -and $script:TenantCacheSignature -eq $signature) {
            foreach ($cachedTenant in @($script:TenantCache)) { Write-Output $cachedTenant }
            return
        }
        $script:CatalogConflictCount = 0
$script:CustomerFolderDirectories = $null
        $latestByTenant = @{}
        $latestUseByTenant = @{}
        foreach ($catalogFile in $catalogFiles) {
            $raw = Get-Content -LiteralPath $catalogFile.FullName -Raw -Encoding UTF8
            if ([string]::IsNullOrWhiteSpace($raw)) { continue }
            foreach ($tenantItem in @($raw | ConvertFrom-Json)) {
                if ([string]::IsNullOrWhiteSpace([string]$tenantItem.tenant)) { continue }
                $key = ([string]$tenantItem.tenant).ToLowerInvariant()
                if ($tenantItem.PSObject.Properties.Name -notcontains 'modifiedUtc' -or [string]::IsNullOrWhiteSpace([string]$tenantItem.modifiedUtc)) {
                    $tenantItem | Add-Member NoteProperty modifiedUtc $catalogFile.LastWriteTimeUtc.ToString('o') -Force
                }
                $modified = try { ConvertTo-UtcDateTime $tenantItem.modifiedUtc } catch { $catalogFile.LastWriteTimeUtc }
                if (-not [string]::IsNullOrWhiteSpace([string]$tenantItem.lastUsed)) {
                    try { $used=ConvertTo-UtcDateTime $tenantItem.lastUsed;if(-not $latestUseByTenant.ContainsKey($key) -or $used -gt $latestUseByTenant[$key]){$latestUseByTenant[$key]=$used} } catch {}
                }
                if (-not $latestByTenant.ContainsKey($key) -or $modified -gt $latestByTenant[$key].ModifiedUtc) {
                    $latestByTenant[$key] = [pscustomobject]@{ Item=$tenantItem; ModifiedUtc=$modified }
                } elseif ($modified -eq $latestByTenant[$key].ModifiedUtc) {
                    $compareProperties=@('name','tenant','username','portal','favorite','tags','role','notes','contact','color','source','gdapStatus','gdapExpires','gdapRelationship','gdapRoles')
                    $currentJson=ConvertTo-Json ($tenantItem|Select-Object $compareProperties) -Compress
                    $existingJson=ConvertTo-Json ($latestByTenant[$key].Item|Select-Object $compareProperties) -Compress
                    if($currentJson -ne $existingJson){$script:CatalogConflictCount++}
                }
            }
        }
        $deletedByTenant = @{}
        foreach ($deletionFile in $deletionFiles) {
            foreach ($line in @(Get-Content -LiteralPath $deletionFile.FullName -Encoding UTF8 -ErrorAction SilentlyContinue)) {
                if ([string]::IsNullOrWhiteSpace($line)) { continue }
                try {
                    $deleted = $line | ConvertFrom-Json
                    $key = ([string]$deleted.tenant).ToLowerInvariant()
                    $deletedUtc = ConvertTo-UtcDateTime $deleted.deletedUtc
                    if (-not $deletedByTenant.ContainsKey($key) -or $deletedUtc -gt $deletedByTenant[$key]) { $deletedByTenant[$key] = $deletedUtc }
                } catch {}
            }
        }
        foreach ($key in @($deletedByTenant.Keys)) {
            if ($latestByTenant.ContainsKey($key) -and $deletedByTenant[$key] -ge $latestByTenant[$key].ModifiedUtc) { $latestByTenant.Remove($key) }
        }
        foreach ($key in @($latestUseByTenant.Keys)) { if($latestByTenant.ContainsKey($key)){$latestByTenant[$key].Item|Add-Member NoteProperty lastUsed ($latestUseByTenant[$key].ToString('o')) -Force} }
        $script:TenantCache = @(Get-DeduplicatedTenants @($latestByTenant.Values | ForEach-Object { $_.Item }))
        $script:TenantCacheSignature = $signature
        foreach ($tenantItem in @($script:TenantCache)) { Write-Output $tenantItem }
        return
    } catch {
        [System.Windows.MessageBox]::Show("Could not read tenants.json. The file may be damaged.`n`n$($_.Exception.Message)", 'MSP Tenant Launcher', 'OK', 'Error') | Out-Null
        return @()
    }
}

function Save-Tenants([array]$Tenants) {
    $transientProperties = @('status','elapsedDisplay','usernameDisplay','favoriteDisplay','customerSubline','workDisplay','logoPath','logoVisibility','initialsVisibility','customerInitials')
    $cleanTenants = @(Get-DeduplicatedTenants @($Tenants | Select-Object -Property * -ExcludeProperty $transientProperties))
    $saved=$false
    for($attempt=0;$attempt -lt 3;$attempt++){
        $tempPath = Join-Path $CatalogRoot ('.tenants-{0}-{1}.tmp' -f $safeComputerName,[guid]::NewGuid().ToString('N'))
        try{ConvertTo-Json -InputObject $cleanTenants -Depth 4 | Set-Content -LiteralPath $tempPath -Encoding UTF8;Move-Item -LiteralPath $tempPath -Destination $ConfigPath -Force;$saved=$true;break}catch{Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue;Start-Sleep -Milliseconds 150}
    }
    if(-not $saved){throw 'The shared tenant catalog is temporarily unavailable. Wait for synchronization to finish and try again.'}
    $dailyBackup = Join-Path $BackupRoot ('catalog-{0}-{1}.json' -f $safeComputerName,[DateTime]::Now.ToString('yyyyMMdd'))
    Copy-Item -LiteralPath $ConfigPath -Destination $dailyBackup -Force -ErrorAction SilentlyContinue
    $script:TenantCache = $cleanTenants
    $script:TenantCacheSignature = ''
}

function Register-TenantDeletion([string]$TenantKey) {
    $record = [ordered]@{ tenant=$TenantKey; deletedUtc=[DateTime]::UtcNow.ToString('o'); computer=[string]$env:COMPUTERNAME }
    ($record | ConvertTo-Json -Compress) | Add-Content -LiteralPath $DeletionPath -Encoding UTF8
    $script:TenantCacheSignature = ''
}

function Ensure-TenantFields($TenantItem) {
    $changed = $false
    $defaults = @(
        @{Name='username';Value=''},
        @{Name='portal';Value='Microsoft 365 admin center'},
        @{Name='lastUsed';Value=$null},
        @{Name='favorite';Value=$false},
        @{Name='tags';Value=''},
        @{Name='role';Value='Global Administrator'},
        @{Name='notes';Value=''},
        @{Name='contact';Value=''},
        @{Name='website';Value=''},
        @{Name='color';Value='#2D6D76'},
        @{Name='source';Value='Local'},
        @{Name='gdapStatus';Value=''},
        @{Name='gdapExpires';Value=''},
        @{Name='gdapRelationship';Value=''},
        @{Name='gdapRoles';Value=''},
        @{Name='modifiedUtc';Value=[DateTime]::MinValue.ToString('o')}
    )
    foreach ($property in $defaults) {
        if ($TenantItem.PSObject.Properties.Name -notcontains $property.Name) {
            $TenantItem | Add-Member NoteProperty $property.Name $property.Value
            $changed = $true
        }
    }
    return $changed
}

function ConvertTo-LogoCacheKey([string]$Value) {
    $safe = ($Value -replace '[^A-Za-z0-9_.-]', '_').Trim('._')
    if ([string]::IsNullOrWhiteSpace($safe)) { $safe = [guid]::NewGuid().ToString('N') }
    return $safe
}

function ConvertTo-NormalizedCustomerName([string]$Value) {
    return (($Value -replace '[^a-zA-Z0-9]', '').ToLowerInvariant())
}

function Find-TenantCustomerFolder($TenantItem) {
    if (-not (Test-Path -LiteralPath $ClientsRoot)) { return $null }
    if ($null -eq $script:CustomerFolderDirectories) { $script:CustomerFolderDirectories = @(Get-ChildItem -LiteralPath $ClientsRoot -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -ne '_PeakNet Tenant Access' }) }
    $directories = @($script:CustomerFolderDirectories)
    $normalized = ConvertTo-NormalizedCustomerName ([string]$TenantItem.name)
    if ([string]::IsNullOrWhiteSpace($normalized)) { return $null }
    $exact = $directories | Where-Object { (ConvertTo-NormalizedCustomerName $_.Name) -eq $normalized } | Select-Object -First 1
    if ($exact) { return $exact.FullName }
    $partial = $directories | Where-Object {
        $candidate = ConvertTo-NormalizedCustomerName $_.Name
        $candidate.Length -ge 4 -and ($candidate.Contains($normalized) -or $normalized.Contains($candidate))
    } | Sort-Object { [Math]::Abs($_.Name.Length - ([string]$TenantItem.name).Length) } | Select-Object -First 1
    if ($partial) { return $partial.FullName }
    return $null
}

function Get-TenantWebsite($TenantItem) {
    if (-not [string]::IsNullOrWhiteSpace([string]$TenantItem.website)) { return ([string]$TenantItem.website).Trim() }
    $customerFolder = Find-TenantCustomerFolder $TenantItem
    if ($customerFolder) {
        foreach ($configName in @('brand-kit.json','branding-source.json')) {
            $brandingRoot = Join-Path $customerFolder 'Microsoft 365 Branding'
            if (-not (Test-Path -LiteralPath $brandingRoot)) { continue }
            $configFile = Get-ChildItem -LiteralPath $brandingRoot -Filter $configName -File -Recurse -ErrorAction SilentlyContinue | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
            if ($configFile) {
                try {
                    $website = [string]((Get-Content -LiteralPath $configFile.FullName -Raw -Encoding UTF8 | ConvertFrom-Json).website)
                    if (-not [string]::IsNullOrWhiteSpace($website)) { return $website.Trim() }
                } catch {}
            }
        }
    }
    if (([string]$TenantItem.username) -match '@([^@\s]+)$') {
        $domain = $Matches[1].ToLowerInvariant()
        if ($domain -notin @('peaknet.dk','peaknet.eu') -and $domain -notmatch '\.onmicrosoft\.com$') { return 'https://' + $domain }
    }
    if (([string]$TenantItem.tenant) -match '^(?=.{4,253}$)(?!.*\.onmicrosoft\.com$)[A-Za-z0-9.-]+\.[A-Za-z]{2,}$') {
        return 'https://' + ([string]$TenantItem.tenant).ToLowerInvariant()
    }
    return ''
}

function Get-TenantLogoPath($TenantItem) {
    $tenantLogoFolder = Join-Path $LogoRoot (ConvertTo-LogoCacheKey ([string]$TenantItem.tenant))
    $cached = Get-ChildItem -LiteralPath $tenantLogoFolder -Filter 'company-logo.*' -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
    if ($cached) { return $cached.FullName }
    $customerFolder = Find-TenantCustomerFolder $TenantItem
    if (-not $customerFolder) { return '' }
    $brandingRoot = Join-Path $customerFolder 'Microsoft 365 Branding'
    $candidates = @()
    foreach ($known in @((Join-Path $brandingRoot 'Ready to upload'),(Join-Path $brandingRoot 'Source'))) {
        if (Test-Path -LiteralPath $known) {
            $candidates += @(Get-ChildItem -LiteralPath $known -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(?i)^(03-Entra-Square-Logo-Light-240x240|normalized-logo|original-logo|website-logo)' })
        }
    }
    $logo = $candidates | Sort-Object @{Expression={ if ($_.Name -match '^03-') { 0 } elseif ($_.Name -match '^normalized') { 1 } else { 2 } }}, LastWriteTimeUtc -Descending | Select-Object -First 1
    if ($logo) { return $logo.FullName }
    return ''
}

function Update-SelectedTenantLogo($TenantItem) {
    if (-not $TenantItem) { [Windows.MessageBox]::Show('Select a customer first.','Company logo','OK','Information') | Out-Null; return }
    [void](Ensure-TenantFields $TenantItem)
    $website = Get-TenantWebsite $TenantItem
    if ([string]::IsNullOrWhiteSpace($website)) {
        [Windows.MessageBox]::Show('No customer website is known. Use Edit to add the company website, then try again.','Company logo','OK','Information') | Out-Null
        return
    }
    $enginePath = Join-Path $PSScriptRoot 'Branding-Engine.ps1'
    if (-not (Test-Path -LiteralPath $enginePath)) { [Windows.MessageBox]::Show('Branding-Engine.ps1 is missing.','Company logo','OK','Error') | Out-Null; return }
    $logoFolder = Join-Path $LogoRoot (ConvertTo-LogoCacheKey ([string]$TenantItem.tenant))
    $downloadFolder = Join-Path $logoFolder 'download'
    try {
        $window.IsEnabled = $false
        $footerText.Text = "Finding the best logo on $website ..."
        [Windows.Threading.Dispatcher]::CurrentDispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Background)
        . $enginePath
        $analysis = Get-WebsiteAnalysis $website $downloadFolder
        if (-not $analysis.LogoPath -or -not (Test-Path -LiteralPath $analysis.LogoPath)) { throw 'No usable company logo was found on the website. You can add one with Branding Studio instead.' }
        $extension = [IO.Path]::GetExtension([string]$analysis.LogoPath).ToLowerInvariant()
        if ($extension -notin @('.png','.jpg','.jpeg','.bmp','.gif','.ico')) { $extension = '.png' }
        New-Item -ItemType Directory -Force -Path $logoFolder | Out-Null
        Get-ChildItem -LiteralPath $logoFolder -Filter 'company-logo.*' -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        $destination = Join-Path $logoFolder ('company-logo' + $extension)
        Copy-Item -LiteralPath $analysis.LogoPath -Destination $destination -Force
        $all = @(Load-Tenants)
        foreach ($item in $all) {
            if ([string]$item.tenant -eq [string]$TenantItem.tenant) {
                [void](Ensure-TenantFields $item)
                $item.website = [string]$analysis.Website
                Touch-Tenant $item
                break
            }
        }
        Save-Tenants $all
        Write-Audit 'CUSTOMER_LOGO_UPDATED' "$([string]$TenantItem.name) | $([string]$analysis.Website)"
        Refresh-Grid
    } catch {
        [Windows.MessageBox]::Show("The customer logo could not be updated.`n`n$($_.Exception.Message)",'Company logo','OK','Warning') | Out-Null
    } finally {
        $window.IsEnabled = $true
        $footerText.Text = 'Shared tenant data  |  Isolated Edge sessions  |  Company logos cached locally'
    }
}

function Touch-Tenant($TenantItem) {
    $TenantItem | Add-Member NoteProperty modifiedUtc ([DateTime]::UtcNow.ToString('o')) -Force
}

function Load-MspConfig {
    if(-not(Test-Path -LiteralPath $MspConfigPath)){return $null}
    try{return Get-Content -LiteralPath $MspConfigPath -Raw -Encoding UTF8|ConvertFrom-Json}catch{return $null}
}

function Save-MspConfig($Config) {
    $safe=[ordered]@{partnerTenantId=[string]$Config.partnerTenantId;clientId=[string]$Config.clientId;lastAccount=[string]$Config.lastAccount}
    $safe|ConvertTo-Json|Set-Content -LiteralPath $MspConfigPath -Encoding UTF8
}

function Load-AppSettings {
    $defaults = [ordered]@{ idleMinutes=5; warningHours=4; autoCloseEnabled=$false; autoCloseHours=8; minimizeToTray=$true }
    if (Test-Path -LiteralPath $SettingsPath) {
        try {
            $saved = Get-Content -LiteralPath $SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
            foreach ($name in @($defaults.Keys)) { if ($saved.PSObject.Properties.Name -contains $name) { $defaults[$name] = $saved.$name } }
        } catch {}
    }
    return [pscustomobject]$defaults
}

function Save-AppSettings($Settings) {
    [ordered]@{
        idleMinutes=[int]$Settings.idleMinutes; warningHours=[double]$Settings.warningHours
        autoCloseEnabled=[bool]$Settings.autoCloseEnabled; autoCloseHours=[double]$Settings.autoCloseHours
        minimizeToTray=[bool]$Settings.minimizeToTray
    } | ConvertTo-Json | Set-Content -LiteralPath $SettingsPath -Encoding UTF8
    $script:AppSettings = Load-AppSettings
}

function ConvertTo-Base64Url([byte[]]$Bytes) {
    return [Convert]::ToBase64String($Bytes).TrimEnd('=').Replace('+','-').Replace('/','_')
}

function New-SecureRandomBytes([int]$Count) {
    $bytes=New-Object byte[] $Count;$rng=[Security.Cryptography.RandomNumberGenerator]::Create();try{$rng.GetBytes($bytes)}finally{$rng.Dispose()};return $bytes
}

function ConvertFrom-QueryString([string]$Query) {
    $values=@{}
    foreach($pair in $Query.TrimStart('?').Split('&',[StringSplitOptions]::RemoveEmptyEntries)){
        $parts=$pair.Split('=',2);$key=[Uri]::UnescapeDataString($parts[0].Replace('+',' '));$value=if($parts.Count-gt 1){[Uri]::UnescapeDataString($parts[1].Replace('+',' '))}else{''};$values[$key]=$value
    }
    return $values
}

function Show-MspSetupDialog {
    $existing=Load-MspConfig
    $dialog=New-Object System.Windows.Forms.Form;$dialog.Text='PeakNet | Configure Microsoft 365 MSP connection';$dialog.Width=650;$dialog.Height=470;$dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false;$dialog.BackColor=[Drawing.ColorTranslator]::FromHtml('#F5F3EF');$dialog.Font=New-Object Drawing.Font('Segoe UI',9)
    $intro=New-Object System.Windows.Forms.Label;$intro.Left=18;$intro.Top=18;$intro.Width=595;$intro.Height=88;$intro.Text="Create a public-client app registration in the PeakNet partner tenant.`r`nAdd Mobile and desktop applications redirect URI: http://localhost`r`nAdd delegated Microsoft Graph permissions: User.Read and DelegatedAdminRelationship.Read.All`r`nGrant administrator consent. No client secret is used."
    $tenantLabel=New-Object System.Windows.Forms.Label;$tenantLabel.Text='Partner Tenant ID';$tenantLabel.Left=18;$tenantLabel.Top=128;$tenantLabel.Width=170
    $tenant=New-Object System.Windows.Forms.TextBox;$tenant.Left=195;$tenant.Top=124;$tenant.Width=418
    $clientLabel=New-Object System.Windows.Forms.Label;$clientLabel.Text='Application (client) ID';$clientLabel.Left=18;$clientLabel.Top=180;$clientLabel.Width=170
    $client=New-Object System.Windows.Forms.TextBox;$client.Left=195;$client.Top=176;$client.Width=418
    $localNote=New-Object System.Windows.Forms.Label;$localNote.Left=18;$localNote.Top=230;$localNote.Width=595;$localNote.Height=64;$localNote.Text="These two identifiers are not secrets and are stored only in:`r`n$MspConfigPath`r`nAuthentication tokens remain in memory and are never synchronized through OneDrive.";$localNote.ForeColor=[Drawing.ColorTranslator]::FromHtml('#526267')
    $openRegistrations=New-Object System.Windows.Forms.Button;$openRegistrations.Text='Open Entra app registrations';$openRegistrations.Left=18;$openRegistrations.Top=315;$openRegistrations.Width=210;$openRegistrations.Height=34;$openRegistrations.Add_Click({Start-Process 'https://entra.microsoft.com/#view/Microsoft_AAD_RegisteredApps/ApplicationsListBlade'|Out-Null})
    $save=New-Object System.Windows.Forms.Button;$save.Text='Save';$save.Left=443;$save.Top=365;$save.Width=80;$save.Height=34
    $cancel=New-Object System.Windows.Forms.Button;$cancel.Text='Cancel';$cancel.Left=533;$cancel.Top=365;$cancel.Width=80;$cancel.Height=34;$cancel.DialogResult='Cancel'
    if($existing){$tenant.Text=[string]$existing.partnerTenantId;$client.Text=[string]$existing.clientId}
    $script:MspSetupResult=$null;$save.Add_Click({if($tenant.Text.Trim()-notmatch'^[0-9a-fA-F-]{36}$'-or$client.Text.Trim()-notmatch'^[0-9a-fA-F-]{36}$'){[System.Windows.Forms.MessageBox]::Show('Enter valid GUID values for both Tenant ID and Application ID.','Check configuration','OK','Warning')|Out-Null;return};$script:MspSetupResult=[pscustomobject]@{partnerTenantId=$tenant.Text.Trim();clientId=$client.Text.Trim();lastAccount=if($existing){[string]$existing.lastAccount}else{''}};$dialog.DialogResult='OK';$dialog.Close()})
    $dialog.Controls.AddRange(@($intro,$tenantLabel,$tenant,$clientLabel,$client,$localNote,$openRegistrations,$save,$cancel));$dialog.CancelButton=$cancel;Set-PeakNetModernForm $dialog;$result=$null;if($dialog.ShowDialog()-eq'OK'){$result=$script:MspSetupResult};$dialog.Dispose();return $result
}

function Invoke-MspInteractiveLogin {
    param($Config)
    $random=New-SecureRandomBytes 48;$verifier=ConvertTo-Base64Url $random;$sha=[Security.Cryptography.SHA256]::Create();try{$challenge=ConvertTo-Base64Url ($sha.ComputeHash([Text.Encoding]::ASCII.GetBytes($verifier)))}finally{$sha.Dispose()}
    $state=ConvertTo-Base64Url (New-SecureRandomBytes 24)
    $listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0);$listener.Start();$port=([Net.IPEndPoint]$listener.LocalEndpoint).Port;$redirectUri="http://localhost:$port/"
    $scope='openid profile offline_access User.Read DelegatedAdminRelationship.Read.All'
    $authorize='https://login.microsoftonline.com/{0}/oauth2/v2.0/authorize?client_id={1}&response_type=code&redirect_uri={2}&response_mode=query&scope={3}&state={4}&code_challenge={5}&code_challenge_method=S256&prompt=select_account' -f [Uri]::EscapeDataString([string]$Config.partnerTenantId),[Uri]::EscapeDataString([string]$Config.clientId),[Uri]::EscapeDataString($redirectUri),[Uri]::EscapeDataString($scope),[Uri]::EscapeDataString($state),[Uri]::EscapeDataString($challenge)
    $client=$null;$stream=$null;$reader=$null
    try{
        Start-Process $authorize|Out-Null;$deadline=[DateTime]::UtcNow.AddMinutes(4)
        while(-not$listener.Pending() -and [DateTime]::UtcNow-lt$deadline){[System.Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 100}
        if(-not$listener.Pending()){throw 'Microsoft sign-in timed out after four minutes.'}
        $client=$listener.AcceptTcpClient();try{
            if(-not[Net.IPAddress]::IsLoopback(([Net.IPEndPoint]$client.Client.RemoteEndPoint).Address)){throw 'Rejected a non-local authentication callback.'}
            $stream=$client.GetStream();$reader=[IO.StreamReader]::new($stream,[Text.Encoding]::ASCII,$false,1024,$true);$requestLine=$reader.ReadLine();while(-not[string]::IsNullOrEmpty($reader.ReadLine())){}
            if($requestLine-notmatch'^GET\s+([^\s]+)\s+HTTP/'){throw 'Invalid authentication callback.'};$callback=[Uri]("http://localhost:$port"+$Matches[1]);$query=ConvertFrom-QueryString $callback.Query
            $success=$query.ContainsKey('code')-and$query.ContainsKey('state')-and$query['state']-eq$state;$body=if($success){'<h2>PeakNet connection completed</h2><p>You may close this browser tab and return to Tenant Access.</p>'}else{'<h2>PeakNet connection was not completed</h2><p>Return to Tenant Access for details.</p>'};$bytes=[Text.Encoding]::UTF8.GetBytes($body);$header=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 200 OK`r`nContent-Type: text/html; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`n`r`n");$stream.Write($header,0,$header.Length);$stream.Write($bytes,0,$bytes.Length);$stream.Flush()
            if($query.ContainsKey('error')){throw "Microsoft sign-in failed: $($query['error_description'])"};if(-not$success){throw 'Microsoft sign-in returned an invalid state or no authorization code.'};$code=[string]$query['code']
        }finally{if($reader){$reader.Dispose()};if($stream){$stream.Dispose()};$client.Dispose()}
    }finally{$listener.Stop()}
    $tokenUri="https://login.microsoftonline.com/$([Uri]::EscapeDataString([string]$Config.partnerTenantId))/oauth2/v2.0/token";$token=Invoke-RestMethod -Method Post -Uri $tokenUri -ContentType 'application/x-www-form-urlencoded' -Body @{client_id=[string]$Config.clientId;grant_type='authorization_code';code=$code;redirect_uri=$redirectUri;scope=$scope;code_verifier=$verifier}
    $me=Invoke-RestMethod -Uri 'https://graph.microsoft.com/v1.0/me?$select=id,displayName,userPrincipalName' -Headers @{Authorization="Bearer $([string]$token.access_token)"}
    $script:MspConnection=[pscustomobject]@{AccessToken=[string]$token.access_token;RefreshToken=[string]$token.refresh_token;ExpiresUtc=[DateTime]::UtcNow.AddSeconds([Math]::Max(60,[int]$token.expires_in-120));TenantId=[string]$Config.partnerTenantId;ClientId=[string]$Config.clientId;DisplayName=[string]$me.displayName;UserPrincipalName=[string]$me.userPrincipalName}
    $Config.lastAccount=[string]$me.userPrincipalName;Save-MspConfig $Config;Write-Audit 'MSP_ACCOUNT_CONNECTED' ([string]$me.userPrincipalName);return $script:MspConnection
}

function Get-MspAccessToken {
    if(-not$script:MspConnection){throw 'Connect the PeakNet MSP account first.'}
    if([DateTime]::UtcNow-lt$script:MspConnection.ExpiresUtc){return [string]$script:MspConnection.AccessToken}
    if([string]::IsNullOrWhiteSpace([string]$script:MspConnection.RefreshToken)){throw 'The Microsoft session expired. Connect again.'}
    $scope='openid profile offline_access User.Read DelegatedAdminRelationship.Read.All';$tokenUri="https://login.microsoftonline.com/$([Uri]::EscapeDataString([string]$script:MspConnection.TenantId))/oauth2/v2.0/token";$token=Invoke-RestMethod -Method Post -Uri $tokenUri -ContentType 'application/x-www-form-urlencoded' -Body @{client_id=[string]$script:MspConnection.ClientId;grant_type='refresh_token';refresh_token=[string]$script:MspConnection.RefreshToken;scope=$scope}
    $script:MspConnection.AccessToken=[string]$token.access_token;if($token.refresh_token){$script:MspConnection.RefreshToken=[string]$token.refresh_token};$script:MspConnection.ExpiresUtc=[DateTime]::UtcNow.AddSeconds([Math]::Max(60,[int]$token.expires_in-120));return [string]$script:MspConnection.AccessToken
}

function Invoke-GraphCollection([string]$Uri) {
    $items=[Collections.Generic.List[object]]::new();$next=$Uri
    while(-not[string]::IsNullOrWhiteSpace($next)){$response=Invoke-RestMethod -Uri $next -Headers @{Authorization="Bearer $(Get-MspAccessToken)"};foreach($item in @($response.value)){$items.Add($item)};$next=if($response.PSObject.Properties.Name-contains'@odata.nextLink'){[string]$response.'@odata.nextLink'}else{''}}
    return @($items)
}

function Get-GdapRoleName([string]$RoleId) {
    $roles=@{'62e90394-69f5-4237-9190-012177145e10'='Global Administrator';'e8611ab8-c189-46e8-94e1-60213ab1f814'='Privileged Role Administrator';'29232cdf-9323-42fd-ade2-1d097af3e4de'='Exchange Administrator';'3a2c62db-5318-420d-8d74-23affee5d9d5'='Intune Administrator';'194ae4cb-b126-40b2-bd5b-6091b380977d'='Security Administrator';'fe930be7-5e62-47db-91af-98c3a49a38b1'='User Administrator';'729827e3-9c14-49f7-bb1b-9608f156bbb8'='Helpdesk Administrator';'69091246-20e8-4a56-aa4d-066075b2a7a8'='Teams Administrator'}
    if($roles.ContainsKey($RoleId.ToLowerInvariant())){return $roles[$RoleId.ToLowerInvariant()]};return "Role $RoleId"
}

function Sync-GdapCustomers {
    $customers=@(Invoke-GraphCollection 'https://graph.microsoft.com/v1.0/tenantRelationships/delegatedAdminCustomers?$select=id,tenantId,displayName&$top=300')
    $relationships=@(Invoke-GraphCollection 'https://graph.microsoft.com/v1.0/tenantRelationships/delegatedAdminRelationships?$select=id,displayName,status,endDateTime,customer,accessDetails&$top=300')
    $relationshipByTenant=@{};foreach($relationship in $relationships){$customerTenant=[string]$relationship.customer.tenantId;if([string]::IsNullOrWhiteSpace($customerTenant)){continue};if(-not$relationshipByTenant.ContainsKey($customerTenant)-or[string]$relationship.status-eq'active'){$relationshipByTenant[$customerTenant]=$relationship}}
    $all=@(Load-Tenants);$byTenant=@{};foreach($item in $all){[void](Ensure-TenantFields $item);if([string]$item.source -like 'Microsoft Graph*'){$item.gdapStatus='Not returned by latest sync'};$byTenant[([string]$item.tenant).ToLowerInvariant()]=$item};$added=0;$updated=0
    foreach($customer in $customers){$tenantId=if(-not[string]::IsNullOrWhiteSpace([string]$customer.tenantId)){[string]$customer.tenantId}else{[string]$customer.id};$key=$tenantId.ToLowerInvariant();$relationship=if($relationshipByTenant.ContainsKey($tenantId)){$relationshipByTenant[$tenantId]}else{$null};$roleNames=@();if($relationship-and$relationship.accessDetails-and$relationship.accessDetails.unifiedRoles){foreach($roleEntry in @($relationship.accessDetails.unifiedRoles)){$roleNames+=Get-GdapRoleName([string]$roleEntry.roleDefinitionId)}};$status=if($relationship){[string]$relationship.status}else{'Customer listed'};$expires=if($relationship-and$relationship.endDateTime){[string]$relationship.endDateTime}else{''}
        if($byTenant.ContainsKey($key)){$item=$byTenant[$key];$item.name=[string]$customer.displayName;$item.source='Microsoft Graph (GDAP)';$item.gdapStatus=$status;$item.gdapExpires=$expires;$item.gdapRelationship=if($relationship){[string]$relationship.displayName}else{''};$item.gdapRoles=$roleNames -join ', ';Touch-Tenant $item;$updated++}
        else{$item=[pscustomobject]@{name=[string]$customer.displayName;tenant=$tenantId;username=[string]$script:MspConnection.UserPrincipalName;portal='Microsoft 365 admin center';lastUsed=$null;favorite=$false;tags='GDAP';role='MSP account via GDAP';notes='';contact='';color='#2D6D76';source='Microsoft Graph (GDAP)';gdapStatus=$status;gdapExpires=$expires;gdapRelationship=if($relationship){[string]$relationship.displayName}else{''};gdapRoles=$roleNames -join ', ';modifiedUtc=[DateTime]::UtcNow.ToString('o')};$all+=$item;$byTenant[$key]=$item;$added++}
    }
    Save-Tenants $all;Refresh-Grid;Write-Audit 'GDAP_CUSTOMERS_SYNCHRONIZED' "$added added; $updated updated";return [pscustomobject]@{Added=$added;Updated=$updated;Customers=$customers.Count;Relationships=$relationships.Count}
}

function Import-TenantCatalog {
    $catalogPath = Join-Path $PSScriptRoot 'tenant-catalog.json'
    if (-not (Test-Path -LiteralPath $catalogPath)) { return }
    $existing = @(Load-Tenants)
    $knownIds = @{}
    $existingById = @{}
    $changed = $false
    foreach ($tenantItem in $existing) {
        $existingKey = [string]$tenantItem.tenant.ToLowerInvariant()
        $knownIds[$existingKey] = $true
        $existingById[$existingKey] = $tenantItem
        if (Ensure-TenantFields $tenantItem) { $changed = $true }
    }
    $catalogParsed = Get-Content -LiteralPath $catalogPath -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($catalogItem in $catalogParsed) {
        $key = [string]$catalogItem.tenant.ToLowerInvariant()
        if (-not $knownIds.ContainsKey($key)) {
            [void](Ensure-TenantFields $catalogItem)
            Touch-Tenant $catalogItem
            $existing += $catalogItem
            $knownIds[$key] = $true
            $existingById[$key] = $catalogItem
            $changed = $true
        } else {
            $savedName = [string]$existingById[$key].name
            if ($savedName.Contains([char]0x00C3) -or $savedName.Contains([char]0x00C2)) {
                $existingById[$key].name = [string]$catalogItem.name
                Touch-Tenant $existingById[$key]
                $changed = $true
            }
        }
    }
    if ($changed) { Save-Tenants $existing }
}

function Find-EdgeBrowser {
    $candidates = @(
        [pscustomobject]@{ Name='Microsoft Edge'; Path=(Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe') },
        [pscustomobject]@{ Name='Microsoft Edge'; Path=(Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe') },
        [pscustomobject]@{ Name='Microsoft Edge'; Path=(Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\Application\msedge.exe') }
    )
    return $candidates | Where-Object { $_.Path -and (Test-Path -LiteralPath $_.Path) } | Select-Object -First 1
}

function Is-ValidTenant([string]$Value) {
    return $Value -match '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$' -or
           $Value -match '^[A-Za-z0-9][A-Za-z0-9.-]*\.[A-Za-z]{2,}$'
}

function New-LoginUrl($Tenant) {
    $tenantId = [Uri]::EscapeDataString([string]$Tenant.tenant)
    $hint = [Uri]::EscapeDataString([string]$Tenant.username)
    # A GUID or the tenant's initial onmicrosoft.com domain is suitable for
    # explicit directory routing. An email/custom domain may not be registered
    # as a tenant alias, so let Microsoft discover the user's home tenant.
    $explicitTenant = ([string]$Tenant.tenant -match '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$') -or
                      ([string]$Tenant.tenant -match '\.onmicrosoft\.com$')
    $commonParts = @()
    if (-not [string]::IsNullOrWhiteSpace([string]$Tenant.username)) { $commonParts += "login_hint=$hint" }
    if ($explicitTenant) { $commonParts += "tenantId=$tenantId" }
    $commonQuery = if ($commonParts.Count) { '?' + ($commonParts -join '&') } else { '' }
    switch ([string]$Tenant.portal) {
        'Entra admin center' { return "https://entra.microsoft.com/$commonQuery" }
        'Microsoft 365 admin center' { return "https://admin.microsoft.com/$commonQuery" }
        'Azure portal' {
            $azureParts = @()
            if (-not [string]::IsNullOrWhiteSpace([string]$Tenant.username)) { $azureParts += "login_hint=$hint" }
            if ($explicitTenant) { $azureParts += "tenant=$tenantId" }
            $azureQuery = if ($azureParts.Count) { '?' + ($azureParts -join '&') } else { '' }
            return "https://portal.azure.com/$azureQuery"
        }
        default { return "https://entra.microsoft.com/$commonQuery" }
    }
}

function Get-PortalDefinitions {
    return @(
        [pscustomobject]@{ Name='Microsoft 365 admin center'; BaseUrl='https://admin.microsoft.com/' },
        [pscustomobject]@{ Name='Microsoft Entra'; BaseUrl='https://entra.microsoft.com/' },
        [pscustomobject]@{ Name='Azure portal'; BaseUrl='https://portal.azure.com/' },
        [pscustomobject]@{ Name='Exchange admin center'; BaseUrl='https://admin.exchange.microsoft.com/' },
        [pscustomobject]@{ Name='Microsoft Intune'; BaseUrl='https://intune.microsoft.com/' },
        [pscustomobject]@{ Name='Microsoft Defender'; BaseUrl='https://security.microsoft.com/' },
        [pscustomobject]@{ Name='Microsoft Purview'; BaseUrl='https://purview.microsoft.com/' },
        [pscustomobject]@{ Name='Teams admin center'; BaseUrl='https://admin.teams.microsoft.com/' }
    )
}

function Get-PortalUrl($Tenant, [string]$PortalName) {
    $definition = Get-PortalDefinitions | Where-Object Name -eq $PortalName | Select-Object -First 1
    if (-not $definition) { $definition = Get-PortalDefinitions | Select-Object -First 1 }
    $tenantValue = [string]$Tenant.tenant
    $isGuid = $tenantValue -match '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
    $queryParts = @()
    if ($isGuid) {
        $parameterName = if ($PortalName -eq 'Azure portal') { 'tenant' } else { 'tenantId' }
        $queryParts += '{0}={1}' -f $parameterName, [Uri]::EscapeDataString($tenantValue)
    }
    if (-not [string]::IsNullOrWhiteSpace([string]$Tenant.username)) { $queryParts += 'login_hint=' + [Uri]::EscapeDataString([string]$Tenant.username) }
    return [string]$definition.BaseUrl + $(if ($queryParts.Count) { '?' + ($queryParts -join '&') } else { '' })
}

function Get-SecurityFindings {
    $all = @(Load-Tenants)
    $findings = [Collections.Generic.List[object]]::new()
    $seenTenants = @{}
    $seenAccounts = @{}
    foreach ($tenantItem in $all) {
        [void](Ensure-TenantFields $tenantItem)
        $name = [string]$tenantItem.name
        $tenantKey = ([string]$tenantItem.tenant).ToLowerInvariant()
        if (-not (Is-ValidTenant ([string]$tenantItem.tenant))) { $findings.Add([pscustomobject]@{Severity='High';Customer=$name;Issue='Tenant ID/domain is invalid'}) }
        if ($seenTenants.ContainsKey($tenantKey)) { $findings.Add([pscustomobject]@{Severity='High';Customer=$name;Issue='Duplicate tenant ID/domain'}) } else { $seenTenants[$tenantKey]=$true }
        if ([string]::IsNullOrWhiteSpace([string]$tenantItem.username)) {
            $findings.Add([pscustomobject]@{Severity='Medium';Customer=$name;Issue='No administrator UPN is configured'})
        } elseif ([string]$tenantItem.username -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') {
            $findings.Add([pscustomobject]@{Severity='High';Customer=$name;Issue='Administrator UPN format is invalid'})
        } else {
            $accountKey=([string]$tenantItem.username).ToLowerInvariant()
            if($seenAccounts.ContainsKey($accountKey)){$findings.Add([pscustomobject]@{Severity='Medium';Customer=$name;Issue='The same administrator UPN is configured for more than one tenant'})}else{$seenAccounts[$accountKey]=$true}
        }
        if ([string]::IsNullOrWhiteSpace([string]$tenantItem.role)) { $findings.Add([pscustomobject]@{Severity='Medium';Customer=$name;Issue='Administrator role has not been documented'}) }
        if ([string]$tenantItem.role -match '(?i)global administrator|\bGA\b') { $findings.Add([pscustomobject]@{Severity='Info';Customer=$name;Issue='Global Administrator documented; prefer GDAP/PIM and least privilege when possible'}) }
        if([string]$tenantItem.source -like 'Microsoft Graph*'){
            if([string]$tenantItem.gdapStatus -notmatch '^(?i)active$'){$findings.Add([pscustomobject]@{Severity='High';Customer=$name;Issue="GDAP relationship status: $([string]$tenantItem.gdapStatus)"})}
            if(-not[string]::IsNullOrWhiteSpace([string]$tenantItem.gdapExpires)){try{$days=((ConvertTo-UtcDateTime $tenantItem.gdapExpires)-[DateTime]::UtcNow).TotalDays;if($days-lt 0){$findings.Add([pscustomobject]@{Severity='High';Customer=$name;Issue='GDAP relationship has expired'})}elseif($days-lt 30){$findings.Add([pscustomobject]@{Severity='Medium';Customer=$name;Issue=('GDAP relationship expires in {0} days' -f [Math]::Ceiling($days))})}}catch{}}
            if([string]$tenantItem.gdapRoles -match '(?i)Global Administrator'){$findings.Add([pscustomobject]@{Severity='Medium';Customer=$name;Issue='GDAP relationship includes Global Administrator; review whether narrower roles are sufficient'})}
        }
        if ([string]$tenantItem.notes -match '(?i)password|passcode|recovery code|secret|token') { $findings.Add([pscustomobject]@{Severity='High';Customer=$name;Issue='Notes may contain secret material; move secrets to 1Password'}) }
    }
    foreach ($session in @($sessions.Values)) {
        if (([DateTime]::UtcNow - $session.StartedUtc).TotalHours -ge [double]$script:AppSettings.warningHours) { $findings.Add([pscustomobject]@{Severity='Medium';Customer=[string]$session.Name;Issue="Tenant session has exceeded the $([double]$script:AppSettings.warningHours)-hour warning"}) }
    }
    return @($findings)
}

function Get-IntegrityStatus {
    $scriptPath = $PSCommandPath
    $actualHash = (Get-FileHash -LiteralPath $scriptPath -Algorithm SHA256).Hash
    $manifestHash = ''
    $workerHashMatches = $true
    $releaseVersion = 'Unknown'
    if (Test-Path -LiteralPath $ReleaseManifestPath) {
        try {
            $manifest = Get-Content -LiteralPath $ReleaseManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($manifest.PSObject.Properties.Name -contains 'files') {
                $mainEntry=@($manifest.files|Where-Object{[string]$_.path -eq 'MSP-Tenant-Launcher.ps1'}|Select-Object -First 1)
                if($mainEntry.Count){$manifestHash=[string]$mainEntry[0].sha256}
                foreach($entry in @($manifest.files)){
                    $candidate=Join-Path $PSScriptRoot ([string]$entry.path)
                    if(-not(Test-Path -LiteralPath $candidate -PathType Leaf)-or(Get-FileHash -LiteralPath $candidate -Algorithm SHA256).Hash-ne[string]$entry.sha256){$workerHashMatches=$false;break}
                }
            } else {
                $manifestHash = [string]$manifest.scriptSha256
                if ($manifest.PSObject.Properties.Name -contains 'forwardingWorkerSha256') { $workerFile=Join-Path $PSScriptRoot ([string]$manifest.forwardingWorker); $workerHashMatches=(Test-Path -LiteralPath $workerFile)-and((Get-FileHash -LiteralPath $workerFile -Algorithm SHA256).Hash-eq[string]$manifest.forwardingWorkerSha256) }
            }
            $releaseVersion = [string]$manifest.version
        } catch {}
    }
    $signature = Get-AuthenticodeSignature -LiteralPath $scriptPath
    $trustedThumbprint = if (Test-Path -LiteralPath $TrustedPublisherPath) { ([string](Get-Content -LiteralPath $TrustedPublisherPath -Raw)).Trim().Replace(' ','') } else { '' }
    $signed = $signature.Status -eq 'Valid'
    $publisherTrusted = $signed -and ([string]::IsNullOrWhiteSpace($trustedThumbprint) -or $signature.SignerCertificate.Thumbprint -eq $trustedThumbprint)
    $hashMatches = -not [string]::IsNullOrWhiteSpace($manifestHash) -and $actualHash -eq $manifestHash -and $workerHashMatches
    $label = if ($publisherTrusted) { 'SIGNED PUBLISHER VERIFIED' } elseif ($hashMatches) { 'LOCAL HASH VERIFIED' } elseif (-not [string]::IsNullOrWhiteSpace($manifestHash)) { 'INTEGRITY WARNING' } else { 'UNVERIFIED BUILD' }
    return [pscustomobject]@{
        Label=$label; Version=$releaseVersion; ActualHash=$actualHash; ExpectedHash=$manifestHash
        HashMatches=$hashMatches; WorkerHashMatches=$workerHashMatches; SignatureStatus=[string]$signature.Status
        Publisher=if ($signature.SignerCertificate) { [string]$signature.SignerCertificate.Subject } else { 'Unsigned' }
        PublisherTrusted=$publisherTrusted
    }
}

function Get-InstalledAppVersion {
    try { if (Test-Path -LiteralPath $ReleaseManifestPath) { return [version]([string](Get-Content -LiteralPath $ReleaseManifestPath -Raw -Encoding UTF8 | ConvertFrom-Json).version) } } catch {}
    return [version]'0.0.0'
}
function Assert-PeakNetUpdateUri([string]$Value,[string]$ExpectedHost,[string]$ExpectedPathPrefix) {
    $uri=[Uri]$Value
    if ($uri.Scheme -ne 'https' -or $uri.Host -ne $ExpectedHost -or -not $uri.AbsolutePath.StartsWith($ExpectedPathPrefix,[StringComparison]::Ordinal)) { throw "The update address is not an approved PeakNet GitHub location: $Value" }
    return $uri
}
function Get-SignedOnlineUpdate {
    if (-not (Test-Path -LiteralPath $UpdateConfigPath)) { throw 'Update-Config.json is missing.' }
    if (-not (Test-Path -LiteralPath $UpdatePublisherCertificatePath)) { throw 'The pinned PeakNet update certificate is missing.' }
    $config=Get-Content -LiteralPath $UpdateConfigPath -Raw -Encoding UTF8 | ConvertFrom-Json
    [void](Assert-PeakNetUpdateUri ([string]$config.feedUrl) 'raw.githubusercontent.com' '/KORSBJERG/PeakNet-Tenant-Access-Releases/')
    [void](Assert-PeakNetUpdateUri ([string]$config.signatureUrl) 'raw.githubusercontent.com' '/KORSBJERG/PeakNet-Tenant-Access-Releases/')
    $temporary=Join-Path $AppRoot ('UpdateCheck-'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $temporary|Out-Null
    $feedPath=Join-Path $temporary 'latest.json';$signaturePath=Join-Path $temporary 'latest.json.p7s'
    try {
        [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri ([string]$config.feedUrl) -OutFile $feedPath -UseBasicParsing -TimeoutSec 20
        Invoke-WebRequest -Uri ([string]$config.signatureUrl) -OutFile $signaturePath -UseBasicParsing -TimeoutSec 20
        if ((Get-Item -LiteralPath $feedPath).Length -gt 1048576 -or (Get-Item -LiteralPath $signaturePath).Length -gt 1048576) { throw 'The update metadata is unexpectedly large.' }
        Add-Type -AssemblyName System.Security
        $certificate=[Security.Cryptography.X509Certificates.X509Certificate2]::new($UpdatePublisherCertificatePath)
        $content=[Security.Cryptography.Pkcs.ContentInfo]::new([IO.File]::ReadAllBytes($feedPath))
        $cms=[Security.Cryptography.Pkcs.SignedCms]::new($content,$true);$cms.Decode([IO.File]::ReadAllBytes($signaturePath))
        $extra=[Security.Cryptography.X509Certificates.X509Certificate2Collection]::new();[void]$extra.Add($certificate);$cms.CheckSignature($extra,$true)
        if ($cms.SignerInfos.Count -ne 1 -or $cms.SignerInfos[0].Certificate.Thumbprint -ne $certificate.Thumbprint) { throw 'The update feed was not signed by the pinned PeakNet publisher certificate.' }
        $feed=Get-Content -LiteralPath $feedPath -Raw -Encoding UTF8|ConvertFrom-Json
        if ([string]$feed.product -ne 'PeakNet Tenant Access' -or [string]$feed.channel -ne [string]$config.channel) { throw 'The signed feed is for a different product or release channel.' }
        [void](Assert-PeakNetUpdateUri ([string]$feed.packageUrl) 'github.com' '/KORSBJERG/PeakNet-Tenant-Access-Releases/releases/download/')
        if ([string]$feed.packageUrl -notlike (([string]$config.allowedDownloadPrefix)+'*')) { throw 'The package URL is outside the approved repository.' }
        if ([string]$feed.packageSha256 -notmatch '^[A-Fa-f0-9]{64}$') { throw 'The signed package hash is invalid.' }
        if ([int64]$feed.packageSize -lt 1 -or [int64]$feed.packageSize -gt 262144000) { throw 'The signed package size is invalid.' }
        return [pscustomobject]@{Config=$config;Feed=$feed;Publisher=$certificate.Subject;Thumbprint=$certificate.Thumbprint}
    } finally { Remove-Item -LiteralPath $temporary -Recurse -Force -ErrorAction SilentlyContinue }
}
function Start-PeakNetOnlineUpdate($UpdateInfo) {
    if ($sessions.Count -gt 0) { [System.Windows.MessageBox]::Show('Close all tenant sessions before installing an update. This protects active work and guarantees clean browser-profile removal.','Active sessions','OK','Warning')|Out-Null;return }
    if (-not (Test-Path -LiteralPath $UpdaterScriptPath)) { throw 'PeakNet-Updater.ps1 is missing.' }
    $feed=$UpdateInfo.Feed;$downloadRoot=Join-Path $AppRoot 'Updates\Downloads';New-Item -ItemType Directory -Force -Path $downloadRoot|Out-Null
    $packagePath=Join-Path $downloadRoot ("PeakNet-$([string]$feed.version)-$([guid]::NewGuid().ToString('N')).zip")
    try {
        $window.Cursor=[Windows.Input.Cursors]::Wait
        Invoke-WebRequest -Uri ([string]$feed.packageUrl) -OutFile $packagePath -UseBasicParsing -TimeoutSec 180
        $file=Get-Item -LiteralPath $packagePath
        if ($file.Length -ne [int64]$feed.packageSize) { throw 'The downloaded package size does not match the signed feed.' }
        if ((Get-FileHash -LiteralPath $packagePath -Algorithm SHA256).Hash -ne ([string]$feed.packageSha256).ToUpperInvariant()) { throw 'The downloaded package failed SHA-256 verification.' }
    } catch { Remove-Item -LiteralPath $packagePath -Force -ErrorAction SilentlyContinue;throw } finally { $window.Cursor=[Windows.Input.Cursors]::Arrow }
    $arguments='-NoProfile -ExecutionPolicy Bypass -STA -File "{0}" -PackagePath "{1}" -InstallRoot "{2}" -ExpectedSha256 "{3}" -ExpectedVersion "{4}" -ParentProcessId {5}' -f $UpdaterScriptPath,$packagePath,$PSScriptRoot,[string]$feed.packageSha256,[string]$feed.version,$PID
    Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -WindowStyle Hidden
    $script:UpdateInProgress=$true;Write-Audit 'SIGNED_UPDATE_STARTED' ([string]$feed.version);$window.Close()
}
Import-TenantCatalog
$script:AppSettings = Load-AppSettings

$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PeakNet | Tenant Access 5.3.0" Height="820" Width="1380" MinHeight="700" MinWidth="1100"
        WindowStartupLocation="CenterScreen" Background="#F4F5F2" FontFamily="Segoe UI">
  <Window.Resources>
    <SolidColorBrush x:Key="Ink" Color="#142926"/>
    <SolidColorBrush x:Key="MutedInk" Color="#60706D"/>
    <SolidColorBrush x:Key="Primary" Color="#197782"/>
    <SolidColorBrush x:Key="Card" Color="#FFFFFF"/>
    <SolidColorBrush x:Key="Soft" Color="#EEF5F3"/>
    <SolidColorBrush x:Key="Line" Color="#D8DFDC"/>
    <Style TargetType="Button">
      <Setter Property="Background" Value="#FFFFFF"/><Setter Property="Foreground" Value="#142926"/>
      <Setter Property="BorderBrush" Value="#D8DFDC"/><Setter Property="BorderThickness" Value="1"/>
      <Setter Property="Padding" Value="14,8"/><Setter Property="FontSize" Value="12.5"/>
      <Setter Property="FontWeight" Value="SemiBold"/><Setter Property="Cursor" Value="Hand"/>
      <Setter Property="Template">
        <Setter.Value><ControlTemplate TargetType="Button">
          <Border x:Name="ButtonBorder" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="{TemplateBinding BorderThickness}" CornerRadius="9" Padding="{TemplateBinding Padding}">
            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
          </Border>
          <ControlTemplate.Triggers>
            <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="ButtonBorder" Property="Opacity" Value="0.86"/></Trigger>
            <Trigger Property="IsPressed" Value="True"><Setter TargetName="ButtonBorder" Property="Opacity" Value="0.72"/></Trigger>
            <Trigger Property="IsEnabled" Value="False"><Setter TargetName="ButtonBorder" Property="Opacity" Value="0.42"/></Trigger>
          </ControlTemplate.Triggers>
        </ControlTemplate></Setter.Value>
      </Setter>
    </Style>
    <Style x:Key="PrimaryButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}">
      <Setter Property="Background" Value="#197782"/><Setter Property="Foreground" Value="#FFFFFF"/><Setter Property="BorderBrush" Value="#197782"/>
    </Style>
    <Style x:Key="DangerButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}"><Setter Property="Foreground" Value="#B2473D"/></Style>
    <Style x:Key="MenuButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}">
      <Setter Property="HorizontalContentAlignment" Value="Left"/><Setter Property="Padding" Value="12,9"/><Setter Property="Margin" Value="0,0,0,6"/><Setter Property="Background" Value="#FFFFFF"/>
    </Style>
    <Style x:Key="PortalButton" TargetType="Button" BasedOn="{StaticResource {x:Type Button}}">
      <Setter Property="Padding" Value="9,10"/><Setter Property="Margin" Value="0,0,7,0"/><Setter Property="MinWidth" Value="61"/>
    </Style>
    <Style TargetType="DataGridColumnHeader">
      <Setter Property="Background" Value="#E8ECE9"/><Setter Property="Foreground" Value="#60706D"/><Setter Property="FontSize" Value="11"/><Setter Property="FontWeight" Value="SemiBold"/>
      <Setter Property="Padding" Value="13,10"/><Setter Property="BorderThickness" Value="0,0,0,1"/><Setter Property="BorderBrush" Value="#D8DFDC"/>
    </Style>
    <Style TargetType="DataGridRow">
      <Setter Property="Background" Value="#FFFFFF"/><Setter Property="Foreground" Value="#142926"/><Setter Property="MinHeight" Value="58"/>
      <Style.Triggers>
        <Trigger Property="AlternationIndex" Value="1"><Setter Property="Background" Value="#FAFBF9"/></Trigger>
        <Trigger Property="IsSelected" Value="True"><Setter Property="Background" Value="#E3F0ED"/><Setter Property="Foreground" Value="#142926"/></Trigger>
        <Trigger Property="IsMouseOver" Value="True"><Setter Property="Background" Value="#EEF5F3"/></Trigger>
      </Style.Triggers>
    </Style>
    <Style TargetType="DataGridCell"><Setter Property="Padding" Value="13,8"/><Setter Property="BorderThickness" Value="0,0,0,1"/><Setter Property="BorderBrush" Value="#E5EAE7"/><Setter Property="FocusVisualStyle" Value="{x:Null}"/></Style>
    <Style TargetType="ListBoxItem">
      <Setter Property="Padding" Value="0"/><Setter Property="Margin" Value="0,0,8,0"/><Setter Property="Background" Value="Transparent"/><Setter Property="BorderThickness" Value="0"/>
      <Setter Property="Template"><Setter.Value><ControlTemplate TargetType="ListBoxItem">
        <Border x:Name="SessionBorder" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="9" Padding="11,7">
          <ContentPresenter/>
        </Border>
        <ControlTemplate.Triggers>
          <Trigger Property="IsSelected" Value="True"><Setter TargetName="SessionBorder" Property="Background" Value="#E3F0ED"/><Setter TargetName="SessionBorder" Property="BorderBrush" Value="#197782"/></Trigger>
          <Trigger Property="IsMouseOver" Value="True"><Setter TargetName="SessionBorder" Property="Background" Value="#EEF5F3"/></Trigger>
        </ControlTemplate.Triggers>
      </ControlTemplate></Setter.Value></Setter>
    </Style>
  </Window.Resources>

  <Grid>
    <Grid.RowDefinitions><RowDefinition Height="78"/><RowDefinition Height="70"/><RowDefinition Height="*"/><RowDefinition Height="34"/></Grid.RowDefinitions>

    <Border Grid.Row="0" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="0,0,0,1" Padding="24,14">
      <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
        <StackPanel Orientation="Horizontal" VerticalAlignment="Center">
          <Viewbox Width="38" Height="38" Margin="0,0,12,0"><Canvas Width="24" Height="24"><Path Data="M20,13 C20,18 16.5,20.5 12.34,21.95 A1,1 0 0 1 11.67,21.94 C7.5,20.5 4,18 4,13 L4,6 A1,1 0 0 1 5,5 C7,5 9.5,3.8 11.24,2.28 A1.17,1.17 0 0 1 12.76,2.28 C14.51,3.81 17,5 19,5 A1,1 0 0 1 20,6 Z" Fill="Transparent" Stroke="#197782" StrokeThickness="2" StrokeLineJoin="Round"/></Canvas></Viewbox>
          <StackPanel VerticalAlignment="Center"><StackPanel Orientation="Horizontal"><TextBlock Text="Peak" FontSize="24" FontWeight="Bold" Foreground="#142926"/><TextBlock Text="Net" FontSize="24" FontWeight="Bold" Foreground="#197782"/></StackPanel><TextBlock Text="TENANT ACCESS  |  VERSION 5.3.0" FontSize="9.5" FontWeight="SemiBold" Foreground="#60706D"/></StackPanel>
        </StackPanel>
        <StackPanel Grid.Column="1" Margin="34,0" VerticalAlignment="Center"><TextBlock Text="Secure tenant workspace" FontSize="16" FontWeight="SemiBold" Foreground="#142926"/><TextBlock Text="Separate Edge profile per customer | session data erased on close" FontSize="11" Foreground="#60706D" Margin="0,2,0,0"/></StackPanel>
        <StackPanel Grid.Column="2" Orientation="Horizontal" VerticalAlignment="Center"><Border Background="#EEF5F3" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="16" Padding="11,6" Margin="0,0,8,0"><StackPanel Orientation="Horizontal"><Ellipse Width="7" Height="7" Fill="#26775E" Margin="0,0,7,0" VerticalAlignment="Center"/><TextBlock Text="LOCAL AND ISOLATED" FontSize="10" FontWeight="SemiBold" Foreground="#60706D"/></StackPanel></Border><Button x:Name="CloseAllButton" Content="Close all sessions" Style="{StaticResource DangerButton}"/></StackPanel>
      </Grid>
    </Border>

    <Border Grid.Row="1" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="0,0,0,1" Padding="22,10">
      <Grid><Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/><ColumnDefinition Width="Auto"/></Grid.ColumnDefinitions>
        <StackPanel VerticalAlignment="Center" Margin="0,0,14,0"><TextBlock Text="ACTIVE SESSIONS" FontSize="10" FontWeight="Bold" Foreground="#60706D"/><TextBlock x:Name="SessionSummary" Text="0 ACTIVE" FontSize="12" FontWeight="SemiBold" Foreground="#197782" Margin="0,3,0,0"/></StackPanel>
        <ListBox x:Name="ActiveSessionList" Grid.Column="1" BorderThickness="0" Background="Transparent" ScrollViewer.HorizontalScrollBarVisibility="Auto" ScrollViewer.VerticalScrollBarVisibility="Disabled" SelectionMode="Single">
          <ListBox.ItemsPanel><ItemsPanelTemplate><StackPanel Orientation="Horizontal"/></ItemsPanelTemplate></ListBox.ItemsPanel>
          <ListBox.ItemTemplate><DataTemplate><StackPanel Orientation="Horizontal"><Ellipse Width="7" Height="7" Fill="#26775E" Margin="0,0,7,0" VerticalAlignment="Center"/><TextBlock Text="{Binding name}" FontWeight="SemiBold"/><TextBlock Text="{Binding elapsedDisplay}" Foreground="#60706D" Margin="9,0,0,0"/></StackPanel></DataTemplate></ListBox.ItemTemplate>
        </ListBox>
        <Button Grid.Column="2" x:Name="LaunchButton" Content="+  Open secure session" Style="{StaticResource PrimaryButton}" Margin="12,0,0,0"/>
      </Grid>
    </Border>

    <Grid Grid.Row="2" Margin="20,18,20,12">
      <Grid.ColumnDefinitions><ColumnDefinition Width="310"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions>
      <Grid Grid.Column="1" Margin="30,0,0,0">
        <Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/></Grid.RowDefinitions>
        <Grid Grid.Row="0" Margin="0,0,0,12"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="340"/></Grid.ColumnDefinitions>
          <StackPanel><TextBlock Text="Customer tenants" FontSize="22" FontWeight="SemiBold" Foreground="#142926"/><TextBlock Text="Recent and pinned customers stay at the top; the rest remain alphabetical." FontSize="11.5" Foreground="#60706D" Margin="0,3,0,0"/></StackPanel>
          <Border Grid.Column="1" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="9" Padding="11,7" VerticalAlignment="Center"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="Auto"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><TextBlock Text="Search" FontSize="11" Foreground="#60706D" Margin="0,0,9,0" VerticalAlignment="Center"/><TextBox x:Name="SearchBox" Grid.Column="1" BorderThickness="0" Background="Transparent" Foreground="#142926" FontSize="12.5" ToolTip="Search customer, tenant ID, admin account, tags, or role"/></Grid></Border>
        </Grid>
        <Border Grid.Row="1" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="12" ClipToBounds="True">
          <DataGrid x:Name="TenantGrid" AutoGenerateColumns="False" IsReadOnly="True" SelectionMode="Single" CanUserAddRows="False" GridLinesVisibility="None" HeadersVisibility="Column" Background="#FFFFFF" BorderThickness="0" RowHeaderWidth="0" SelectionUnit="FullRow" FontSize="12.5" AlternationCount="2" EnableRowVirtualization="True" EnableColumnVirtualization="True" VirtualizingPanel.IsVirtualizing="True" VirtualizingPanel.VirtualizationMode="Recycling" ScrollViewer.CanContentScroll="True">
            <DataGrid.Columns>
              <DataGridTemplateColumn Header="CUSTOMER" Width="2.8*"><DataGridTemplateColumn.CellTemplate><DataTemplate><Grid Margin="0,1"><Grid.ColumnDefinitions><ColumnDefinition Width="5"/><ColumnDefinition Width="48"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Border Background="{Binding color}" CornerRadius="3" Margin="0,1,9,1"/><Grid Grid.Column="1" Width="38" Height="38" VerticalAlignment="Center" HorizontalAlignment="Left"><Border Background="{Binding color}" CornerRadius="8" Visibility="{Binding initialsVisibility}"><TextBlock Text="{Binding customerInitials}" Foreground="#FFFFFF" FontSize="13" FontWeight="Bold" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border><Border Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="8" Visibility="{Binding logoVisibility}" Padding="2"><Image Source="{Binding logoPath}" Stretch="Uniform"/></Border></Grid><StackPanel Grid.Column="2" Margin="2"><TextBlock FontSize="15" FontWeight="SemiBold" Foreground="#142926" TextTrimming="CharacterEllipsis"><Run Text="{Binding favoriteDisplay}"/><Run Text="{Binding name}"/></TextBlock><TextBlock Text="{Binding customerSubline}" FontSize="10.5" Foreground="#60706D" Margin="0,3,0,0" TextTrimming="CharacterEllipsis"/></StackPanel></Grid></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
              <DataGridTemplateColumn Header="ADMIN / ROLE" Width="2.1*"><DataGridTemplateColumn.CellTemplate><DataTemplate><StackPanel><TextBlock Text="{Binding usernameDisplay}" TextTrimming="CharacterEllipsis"/><TextBlock Text="{Binding role}" FontSize="10.5" Foreground="#60706D" Margin="0,3,0,0" TextTrimming="CharacterEllipsis"/></StackPanel></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
              <DataGridTemplateColumn Header="WORKSPACE" Width="1.7*"><DataGridTemplateColumn.CellTemplate><DataTemplate><StackPanel><TextBlock Text="{Binding portal}" TextTrimming="CharacterEllipsis"/><TextBlock Text="{Binding workDisplay}" FontSize="10.5" Foreground="#60706D" Margin="0,3,0,0" TextTrimming="CharacterEllipsis"/></StackPanel></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
              <DataGridTextColumn Header="TIME" Binding="{Binding elapsedDisplay}" Width="0.7*"/>
              <DataGridTemplateColumn Header="STATE" Width="0.8*"><DataGridTemplateColumn.CellTemplate><DataTemplate><TextBlock Text="{Binding status}" VerticalAlignment="Center"><TextBlock.Style><Style TargetType="TextBlock"><Setter Property="Foreground" Value="#60706D"/><Style.Triggers><DataTrigger Binding="{Binding status}" Value="Active"><Setter Property="Foreground" Value="#197782"/><Setter Property="FontWeight" Value="Bold"/></DataTrigger></Style.Triggers></Style></TextBlock.Style></TextBlock></DataTemplate></DataGridTemplateColumn.CellTemplate></DataGridTemplateColumn>
            </DataGrid.Columns>
          </DataGrid>
        </Border>
      </Grid>

      <Border Grid.Column="0" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="12" Padding="17">
        <ScrollViewer VerticalScrollBarVisibility="Auto" HorizontalScrollBarVisibility="Disabled"><StackPanel>
          <TextBlock Text="SELECTED WORKSPACE" FontSize="10" FontWeight="Bold" Foreground="#60706D"/>
          <Border x:Name="SelectedBanner" Margin="0,10,0,12" Background="#EEF5F3" BorderBrush="#D8DFDC" BorderThickness="1" CornerRadius="10"><Grid><Grid.ColumnDefinitions><ColumnDefinition Width="7"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Border x:Name="SelectedColorBar" Background="#197782" CornerRadius="9,0,0,9"/><StackPanel Grid.Column="1" Margin="13,11"><TextBlock x:Name="SelectedCustomerName" Text="Select a customer" FontSize="18" FontWeight="Bold" Foreground="#142926" TextWrapping="Wrap"/><TextBlock x:Name="SelectedCustomerDetails" Text="Customer details will appear here." FontSize="10.5" Foreground="#60706D" Margin="0,4,0,0" TextWrapping="Wrap" MaxHeight="56"/></StackPanel></Grid></Border>
          <TextBlock Text="PORTALS" FontSize="10" FontWeight="Bold" Foreground="#60706D" Margin="0,2,0,8"/>
          <StackPanel Orientation="Horizontal" Margin="0,0,0,8"><Button x:Name="PortalButton" Content="Admin" Style="{StaticResource PortalButton}" ToolTip="Open Microsoft 365 admin center in the selected active session"/><Button x:Name="EntraPortalButton" Content="Entra" Style="{StaticResource PortalButton}"/><Button x:Name="IntunePortalButton" Content="Intune" Style="{StaticResource PortalButton}"/><Button x:Name="SecurityPortalButton" Content="Security" Style="{StaticResource PortalButton}"/></StackPanel>
          <Button x:Name="LaunchWorkspaceButton" Content="Open secure Edge workspace  &gt;" Style="{StaticResource PrimaryButton}" Padding="14,11" Margin="0,0,0,8"/>
          <Grid Margin="0,0,0,15"><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Button x:Name="EndButton" Content="Close session" Margin="0,0,4,0"/><Button x:Name="WorkspaceCloseAllButton" Grid.Column="1" Content="Close all" Style="{StaticResource DangerButton}" Margin="4,0,0,0"/></Grid>

          <Separator Background="#D8DFDC" Margin="0,0,0,13"/>
          <TextBlock Text="WORKSPACE" FontSize="10" FontWeight="Bold" Foreground="#60706D" Margin="0,0,0,8"/>
          <Button x:Name="DashboardButton" Content="Overview &amp; tenant health" Style="{StaticResource MenuButton}"/><Button x:Name="TimeButton" Content="Time by tenant &amp; work log" Style="{StaticResource MenuButton}"/><Button x:Name="ForwardingButton" Content="External email forwarding" Style="{StaticResource MenuButton}"/><Button x:Name="BrandingButton" Content="Microsoft 365 Branding Studio 2.0" Style="{StaticResource MenuButton}"/><Button x:Name="PolicyButton" Content="Session policy" Style="{StaticResource MenuButton}"/>
          <TextBlock Text="TENANT MANAGEMENT" FontSize="10" FontWeight="Bold" Foreground="#60706D" Margin="0,9,0,8"/>
          <Grid><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="Auto"/></Grid.RowDefinitions><Grid.ColumnDefinitions><ColumnDefinition Width="*"/><ColumnDefinition Width="*"/></Grid.ColumnDefinitions><Button x:Name="AddButton" Content="Add" Style="{StaticResource MenuButton}" Margin="0,0,4,6"/><Button x:Name="EditButton" Grid.Column="1" Content="Edit" Style="{StaticResource MenuButton}" Margin="4,0,0,6"/><Button x:Name="FavoriteButton" Grid.Row="1" Content="Pin / unpin" Style="{StaticResource MenuButton}" Margin="0,0,4,6"/><Button x:Name="RemoveButton" Grid.Row="1" Grid.Column="1" Content="Remove" Style="{StaticResource DangerButton}" Margin="4,0,0,6"/></Grid>
          <TextBlock Text="TOOLS &amp; CONNECTIONS" FontSize="10" FontWeight="Bold" Foreground="#60706D" Margin="0,9,0,8"/>
          <Button x:Name="LogoButton" Content="Update selected company logo" Style="{StaticResource MenuButton}"/><Button x:Name="MspButton" Content="Connect MSP" Style="{StaticResource MenuButton}"/><Button x:Name="SyncMspButton" Content="Sync GDAP customers" Style="{StaticResource MenuButton}"/><Button x:Name="CatalogButton" Content="Backup / import" Style="{StaticResource MenuButton}"/><Button x:Name="SecurityButton" Content="Security checks" Style="{StaticResource MenuButton}"/><Button x:Name="IntegrityButton" Content="Check for updates" Style="{StaticResource MenuButton}"/><Button x:Name="SetupButton" Content="Set up 1Password template" Style="{StaticResource MenuButton}"/>
          <TextBlock x:Name="MspSummary" Text="MSP ACCOUNT DISCONNECTED" FontSize="9.5" Foreground="#60706D" Margin="2,7,0,0" TextWrapping="Wrap"/><TextBlock x:Name="IntegritySummary" Text="INTEGRITY CHECK" FontSize="9.5" Foreground="#60706D" Margin="2,3,0,0" TextWrapping="Wrap"/>
        </StackPanel></ScrollViewer>
      </Border>
    </Grid>

    <Border Grid.Row="3" Background="#FFFFFF" BorderBrush="#D8DFDC" BorderThickness="0,1,0,0"><TextBlock x:Name="FooterText" Text="1Password template  |  Separate Edge profile per customer  |  Session profile erased on close" FontSize="10" Foreground="#60706D" HorizontalAlignment="Center" VerticalAlignment="Center"/></Border>
  </Grid>
</Window>
'@

$reader = [System.Xml.XmlNodeReader]::new([xml]$xaml)
$window = [Windows.Markup.XamlReader]::Load($reader)
$iconPath = Join-Path $PSScriptRoot 'PeakNet-Tenant-Access.ico'
$script:PeakNetUiIconPath = $iconPath
if (Test-Path -LiteralPath $iconPath) {
    $iconStream = [IO.File]::OpenRead($iconPath)
    try {
        $iconDecoder = [System.Windows.Media.Imaging.IconBitmapDecoder]::new(
            $iconStream,
            [System.Windows.Media.Imaging.BitmapCreateOptions]::PreservePixelFormat,
            [System.Windows.Media.Imaging.BitmapCacheOption]::OnLoad
        )
        $window.Icon = $iconDecoder.Frames | Sort-Object PixelWidth -Descending | Select-Object -First 1
    } finally { $iconStream.Dispose() }
}
$window.Add_SourceInitialized({
    if (-not (Test-Path -LiteralPath $iconPath)) { return }
    try {
        $handle = [System.Windows.Interop.WindowInteropHelper]::new($window).Handle
        $script:TaskbarLargeIcon = [System.Drawing.Icon]::new($iconPath, 32, 32)
        $script:TaskbarSmallIcon = [System.Drawing.Icon]::new($iconPath, 16, 16)
        [void][PeakNetWindowIdentity]::SendMessage($handle, 0x0080, [IntPtr]1, $script:TaskbarLargeIcon.Handle)
        [void][PeakNetWindowIdentity]::SendMessage($handle, 0x0080, [IntPtr]0, $script:TaskbarSmallIcon.Handle)
    } catch {}
})
$grid = $window.FindName('TenantGrid')
$searchBox = $window.FindName('SearchBox')
$selectedColorBar = $window.FindName('SelectedColorBar')
$selectedCustomerName = $window.FindName('SelectedCustomerName')
$selectedCustomerDetails = $window.FindName('SelectedCustomerDetails')
$sessionSummary = $window.FindName('SessionSummary')
$activeSessionList = $window.FindName('ActiveSessionList')
$mspSummary = $window.FindName('MspSummary')
$integritySummary = $window.FindName('IntegritySummary')
$footerText = $window.FindName('FooterText')
$tenants = [System.Collections.ObjectModel.ObservableCollection[object]]::new()
$activeSessionsView = [System.Collections.ObjectModel.ObservableCollection[object]]::new()
$activeSessionList.ItemsSource = $activeSessionsView
$sessions = @{}
$script:IntegrityCache = $null
$script:TrayHintShown = $false
$notifyIcon = New-Object System.Windows.Forms.NotifyIcon
$notifyIcon.Text = 'PeakNet Tenant Access'
if (Test-Path -LiteralPath $iconPath) { $notifyIcon.Icon = New-Object System.Drawing.Icon($iconPath) }
$trayMenu = New-Object System.Windows.Forms.ContextMenuStrip
$trayOpen = $trayMenu.Items.Add('Open PeakNet Tenant Access')
$trayDashboard = $trayMenu.Items.Add('Dashboard')
$trayCloseAll = $trayMenu.Items.Add('Close all tenant sessions')
[void]$trayMenu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
$trayExit = $trayMenu.Items.Add('Exit')
$notifyIcon.ContextMenuStrip = $trayMenu
$notifyIcon.Visible = $true
$showLauncher = { $window.Show();$window.WindowState=[Windows.WindowState]::Normal;$window.Activate()|Out-Null }
$trayOpen.Add_Click($showLauncher);$notifyIcon.Add_DoubleClick($showLauncher)
$trayDashboard.Add_Click({$window.Show();$window.WindowState=[Windows.WindowState]::Normal;Show-OperationsDashboard})
$trayCloseAll.Add_Click({$button=$window.FindName('CloseAllButton');$button.RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Button]::ClickEvent))})
$trayExit.Add_Click({$window.Close()})
$window.Add_StateChanged({
    if($window.WindowState -eq [Windows.WindowState]::Minimized -and [bool]$script:AppSettings.minimizeToTray){
        $window.Hide()
        if(-not$script:TrayHintShown){$notifyIcon.BalloonTipTitle='PeakNet Tenant Access';$notifyIcon.BalloonTipText='The launcher is still running and tracking active tenant sessions.';$notifyIcon.ShowBalloonTip(3000);$script:TrayHintShown=$true}
    }
})

function Get-EdgeProcessRows {
    try { return @(Get-CimInstance -ClassName Win32_Process -Filter "Name = 'msedge.exe'" -ErrorAction Stop) } catch { return @() }
}

function Get-SessionBrowserProcesses($Session, [array]$EdgeRows) {
    $found = @{}
    try {
        if ($Session.Process -and -not $Session.Process.HasExited) { $found[[int]$Session.Process.Id] = $Session.Process }
    } catch {}
    try {
        $profilePath = [string]$Session.Profile
        $browserRows = if ($PSBoundParameters.ContainsKey('EdgeRows')) { @($EdgeRows) } else { @(Get-EdgeProcessRows) }
        $browserRows = $browserRows | Where-Object {
            $_.Name -eq 'msedge.exe' -and $_.CommandLine -and
            $_.CommandLine.IndexOf($profilePath, [StringComparison]::OrdinalIgnoreCase) -ge 0
        }
        foreach ($row in $browserRows) {
            try { $found[[int]$row.ProcessId] = Get-Process -Id $row.ProcessId -ErrorAction Stop } catch {}
        }
    } catch {}
    return @($found.Values)
}

function Get-TemplateEdgeProcesses {
    $profileSession = [pscustomobject]@{ Process=$null; Profile=$EdgeTemplateRoot }
    return @(Get-SessionBrowserProcesses $profileSession)
}

function Test-OnePasswordTemplate {
    $extensionPath = Join-Path $EdgeTemplateRoot 'Default\Extensions\dppgmdbiimibapkepcbdbmkaabgiofem'
    return Test-Path -LiteralPath $extensionPath
}

function New-SessionProfileFromTemplate([string]$Destination) {
    if (Test-Path -LiteralPath $Destination) { throw 'The new session profile already exists.' }
    New-Item -ItemType Directory -Path $Destination | Out-Null
    $robocopy = Join-Path $env:SystemRoot 'System32\robocopy.exe'
    if (Test-Path -LiteralPath $robocopy) {
        $copyArguments = @(
            ('"{0}"' -f $EdgeTemplateRoot), ('"{0}"' -f $Destination), '/E', '/R:1', '/W:1', '/NFL', '/NDL', '/NJH', '/NJS', '/NP',
            '/XD', 'Cache', '"Code Cache"', 'GPUCache', 'DawnCache', 'DawnWebGPUCache', 'GrShaderCache', 'ShaderCache',
            'CacheStorage', 'ScriptCache', '"Media Cache"', 'blob_storage', 'Crashpad', 'SessionCache',
            '/XF', 'Singleton*'
        )
        $copyProcess = Start-Process -FilePath $robocopy -ArgumentList $copyArguments -WindowStyle Hidden -Wait -PassThru
        $copyExitCode = $copyProcess.ExitCode
        $copyProcess.Dispose()
        if ($copyExitCode -ge 8) { throw "Could not create the isolated Edge profile (copy code $copyExitCode)." }
    } else {
        foreach ($item in @(Get-ChildItem -LiteralPath $EdgeTemplateRoot -Force -ErrorAction Stop)) {
            if ($item.Name -like 'Singleton*' -or $item.Name -eq 'SessionCache') { continue }
            Copy-Item -LiteralPath $item.FullName -Destination $Destination -Recurse -Force -ErrorAction Stop
        }
    }
    foreach ($lockFile in @(Get-ChildItem -LiteralPath $Destination -Force -Filter 'Singleton*' -ErrorAction SilentlyContinue)) {
        Remove-Item -LiteralPath $lockFile.FullName -Force -ErrorAction SilentlyContinue
    }
}

function Stop-SessionBrowserProcesses($Session) {
    foreach ($candidate in @(Get-SessionBrowserProcesses $Session)) {
        try { if ($candidate.MainWindowHandle -ne [IntPtr]::Zero) { $candidate.CloseMainWindow() | Out-Null } } catch {}
    }
    for ($attempt = 0; $attempt -lt 12; $attempt++) {
        if (@(Get-SessionBrowserProcesses $Session).Count -eq 0) { break }
        Start-Sleep -Milliseconds 250
    }
    foreach ($candidate in @(Get-SessionBrowserProcesses $Session)) {
        try { if (-not $candidate.HasExited) { Stop-Process -Id $candidate.Id -Force -ErrorAction SilentlyContinue } } catch {}
    }
    Start-Sleep -Milliseconds 350
}

function Remove-SessionProfile([string]$ProfilePath) {
    if ([string]::IsNullOrWhiteSpace($ProfilePath)) { return $true }
    $resolvedRoot = [IO.Path]::GetFullPath($SessionRoot).TrimEnd('\') + '\'
    $resolvedProfile = [IO.Path]::GetFullPath($ProfilePath)
    if (-not $resolvedProfile.StartsWith($resolvedRoot, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Refusing to remove a session profile outside the launcher session folder.'
    }
    for ($attempt = 0; $attempt -lt 10; $attempt++) {
        if (-not (Test-Path -LiteralPath $resolvedProfile)) { return $true }
        try { Remove-Item -LiteralPath $resolvedProfile -Recurse -Force -ErrorAction Stop } catch {}
        Start-Sleep -Milliseconds 250
    }
    return -not (Test-Path -LiteralPath $resolvedProfile)
}

function Remove-StaleSessionProfiles {
    try {
        Get-CimInstance -ClassName Win32_Process -ErrorAction Stop | Select-Object -First 1 | Out-Null
    } catch {
        Write-Audit 'STALE_CLEANUP_SKIPPED' 'Could not inspect Edge processes'
        return
    }
    foreach ($directory in @(Get-ChildItem -LiteralPath $SessionRoot -Directory -ErrorAction SilentlyContinue)) {
        $orphanSession = [pscustomobject]@{ Process=$null; Profile=$directory.FullName; Name=$directory.Name }
        try { Stop-SessionBrowserProcesses $orphanSession } catch {}
        if (Remove-SessionProfile $directory.FullName) {
            Write-Audit 'ORPHANED_SESSION_ENDED_AND_ERASED' $directory.Name
        }
    }
}

function Refresh-Grid {
    $selectedKey = if ($grid.SelectedItem) { [string]$grid.SelectedItem.tenant } else { '' }
    # Detach while rebuilding so WPF does not redraw once for every tenant added.
    $grid.ItemsSource = $null
    $tenants.Clear()
    $items = @(Get-DeduplicatedTenants @(Load-Tenants))
    foreach ($t in $items) {
        [void](Ensure-TenantFields $t)
        $tenantKey = [string]$t.tenant
        $status = if ($sessions.ContainsKey($tenantKey)) { 'Active' } else { 'Closed' }
        $elapsed = if ($sessions.ContainsKey($tenantKey)) { Format-Duration (Get-SessionTrackedSeconds $sessions[$tenantKey]) } else { '' }
        $displayAccount = if ([string]::IsNullOrWhiteSpace([string]$t.username)) { 'Choose at sign-in' } else { [string]$t.username }
        $favoriteDisplay = if ([bool]$t.favorite) { [char]0x2605 + '  ' } else { '' }
        $sublineParts = @([string]$t.tenant)
        if([string]$t.source -like 'Microsoft Graph*'){$gdapText=if([string]::IsNullOrWhiteSpace([string]$t.gdapStatus)){'GDAP'}else{'GDAP: '+[string]$t.gdapStatus};$sublineParts+=$gdapText}else{$sublineParts+='LOCAL'}
        if (-not [string]::IsNullOrWhiteSpace([string]$t.tags)) { $sublineParts += [string]$t.tags }
        $workDisplay = if ($sessions.ContainsKey($tenantKey)) {
            $sessionWork = $sessions[$tenantKey]
            $ticketText = if ([string]::IsNullOrWhiteSpace([string]$sessionWork.Ticket)) { 'No ticket' } else { 'Ticket: ' + [string]$sessionWork.Ticket }
            "$ticketText  |  Started $($sessionWork.StartedUtc.ToLocalTime().ToString('HH:mm'))"
        } elseif (-not [string]::IsNullOrWhiteSpace([string]$t.tags)) { [string]$t.tags } else { 'No active work' }
        $t | Add-Member NoteProperty status $status -Force
        $t | Add-Member NoteProperty elapsedDisplay $elapsed -Force
        $t | Add-Member NoteProperty usernameDisplay $displayAccount -Force
        $t | Add-Member NoteProperty favoriteDisplay $favoriteDisplay -Force
        $t | Add-Member NoteProperty customerSubline ($sublineParts -join '  |  ') -Force
        $t | Add-Member NoteProperty workDisplay $workDisplay -Force
        $logoPath = Get-TenantLogoPath $t
        $nameParts = @(([string]$t.name -split '[^\p{L}\p{Nd}]+' | Where-Object { -not [string]::IsNullOrWhiteSpace($_) }))
        $initials = if ($nameParts.Count -ge 2) { ([string]$nameParts[0]).Substring(0,1) + ([string]$nameParts[1]).Substring(0,1) } elseif ($nameParts.Count -eq 1) { ([string]$nameParts[0]).Substring(0,[Math]::Min(2,([string]$nameParts[0]).Length)) } else { '?' }
        $t | Add-Member NoteProperty logoPath $logoPath -Force
        $t | Add-Member NoteProperty customerInitials $initials.ToUpperInvariant() -Force
        $t | Add-Member NoteProperty logoVisibility $(if ([string]::IsNullOrWhiteSpace($logoPath)) { 'Collapsed' } else { 'Visible' }) -Force
        $t | Add-Member NoteProperty initialsVisibility $(if ([string]::IsNullOrWhiteSpace($logoPath)) { 'Visible' } else { 'Collapsed' }) -Force
    }
    $activeSessionsView.Clear()
    foreach ($activeTenant in @($items | Where-Object { [string]$_.status -eq 'Active' } | Sort-Object @{Expression={ConvertTo-UtcDateTime $sessions[[string]$_.tenant].StartedUtc};Ascending=$true})) {
        $activeSessionsView.Add($activeTenant)
    }
    $searchText = [string]$searchBox.Text
    if (-not [string]::IsNullOrWhiteSpace($searchText)) {
        $needle = $searchText.Trim()
        $items = @($items | Where-Object {
            ([string]$_.name).IndexOf($needle, [StringComparison]::CurrentCultureIgnoreCase) -ge 0 -or
            ([string]$_.tenant).IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
            ([string]$_.username).IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
            ([string]$_.website).IndexOf($needle, [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
            ([string]$_.tags).IndexOf($needle, [StringComparison]::CurrentCultureIgnoreCase) -ge 0 -or
            ([string]$_.role).IndexOf($needle, [StringComparison]::CurrentCultureIgnoreCase) -ge 0
        })
    }
    $sorted = @($items | Sort-Object `
        @{Expression={ if ([bool]$_.favorite) { 0 } else { 1 } }; Ascending=$true}, `
        @{Expression={ if ([string]::IsNullOrWhiteSpace([string]$_.lastUsed)) { 1 } else { 0 } }; Ascending=$true}, `
        @{Expression={ if ([string]::IsNullOrWhiteSpace([string]$_.lastUsed)) { [DateTime]::MinValue } else { ConvertTo-UtcDateTime $_.lastUsed } }; Descending=$true}, `
        @{Expression={ [string]$_.name }; Ascending=$true})
    foreach ($t in $sorted) {
        $tenants.Add($t)
    }
    $grid.ItemsSource = $tenants
    if (-not [string]::IsNullOrWhiteSpace($selectedKey)) { $grid.SelectedItem = $tenants | Where-Object { [string]$_.tenant -eq $selectedKey } | Select-Object -First 1 }
    Update-Dashboard
}

function Update-Dashboard {
    $activeCount = $sessions.Count
    $profileCount = @(Get-ChildItem -LiteralPath $SessionRoot -Directory -ErrorAction SilentlyContinue).Count
    $pendingCleanup = [Math]::Max(0, $profileCount - $activeCount)
    $sessionSummary.Text = "$activeCount ACTIVE SESSION$(if ($activeCount -ne 1) { 'S' })$(if ($pendingCleanup) { "  |  $pendingCleanup CLEANUP PENDING" })"
    if($notifyIcon){$notifyIcon.Text="PeakNet Tenant Access - $activeCount active"}
    $selected = $grid.SelectedItem
    if ($selected) {
        $selectedCustomerName.Text = "$(if ([bool]$selected.favorite) { [char]0x2605 + '  ' })$([string]$selected.name)"
        $parts = @()
        if (-not [string]::IsNullOrWhiteSpace([string]$selected.username)) { $parts += [string]$selected.username }
        if (-not [string]::IsNullOrWhiteSpace([string]$selected.role)) { $parts += 'Role: ' + [string]$selected.role }
        if (-not [string]::IsNullOrWhiteSpace([string]$selected.contact)) { $parts += 'Contact: ' + [string]$selected.contact }
        if (-not [string]::IsNullOrWhiteSpace([string]$selected.website)) { $parts += 'Website: ' + [string]$selected.website }
        if (-not [string]::IsNullOrWhiteSpace([string]$selected.notes)) { $parts += 'Note: ' + (([string]$selected.notes -replace '[\r\n]+',' ') -replace '\s+',' ') }
        if([string]$selected.source -like 'Microsoft Graph*'){$parts+='GDAP: '+[string]$selected.gdapStatus;if(-not[string]::IsNullOrWhiteSpace([string]$selected.gdapExpires)){try{$parts+='Expires '+((ConvertTo-UtcDateTime $selected.gdapExpires).ToLocalTime().ToString('yyyy-MM-dd'))}catch{}};if(-not[string]::IsNullOrWhiteSpace([string]$selected.gdapRoles)){$parts+='Relationship roles: '+[string]$selected.gdapRoles}}
        $selectedKey=[string]$selected.tenant
        if($sessions.ContainsKey($selectedKey)){$active=$sessions[$selectedKey];$parts += "Active since $($active.StartedUtc.ToLocalTime().ToString('HH:mm'))";if(-not [string]::IsNullOrWhiteSpace([string]$active.Ticket)){$parts += 'Ticket: '+[string]$active.Ticket}}
        $selectedCustomerDetails.Text = if ($parts.Count) { $parts -join '  |  ' } else { [string]$selected.tenant }
        try { $selectedColorBar.Background = [Windows.Media.BrushConverter]::new().ConvertFromString([string]$selected.color) } catch { $selectedColorBar.Background = [Windows.Media.Brushes]::Teal }
    } else {
        $selectedCustomerName.Text = 'Select a customer'
        $selectedCustomerDetails.Text = 'Customer identity, role, notes, and active work will appear here.'
        $selectedColorBar.Background = [Windows.Media.Brushes]::Teal
    }
    if($script:MspConnection){$mspSummary.Text="MSP: $([string]$script:MspConnection.UserPrincipalName)";$mspSummary.Foreground=[Windows.Media.Brushes]::SeaGreen;$window.FindName('MspButton').Content='Disconnect MSP'}else{$config=Load-MspConfig;$mspSummary.Text=if($config-and-not[string]::IsNullOrWhiteSpace([string]$config.lastAccount)){"MSP DISCONNECTED: $([string]$config.lastAccount)"}else{'MSP ACCOUNT DISCONNECTED'};$mspSummary.Foreground=[Windows.Media.Brushes]::SlateGray;$window.FindName('MspButton').Content='Connect MSP'}
    try {
        if (-not $script:IntegrityCache) { $script:IntegrityCache = Get-IntegrityStatus }
        $integrity = $script:IntegrityCache
        $integritySummary.Text = $integrity.Label
        $integritySummary.Foreground = if ($integrity.Label -eq 'INTEGRITY WARNING') { [Windows.Media.Brushes]::Firebrick } else { [Windows.Media.Brushes]::SlateGray }
    } catch { $integritySummary.Text = 'INTEGRITY CHECK UNAVAILABLE' }
    $footerText.Text = "Shared data: $safeComputerName  |  $activeCount isolated session$(if ($activeCount -ne 1) { 's' }) active  |  $pendingCleanup cleanup pending  |  Profiles erased on close"
}

function Set-TenantLastUsed([string]$TenantKey) {
    $all = @(Load-Tenants)
    foreach ($tenantItem in $all) {
        if ([string]$tenantItem.tenant -eq $TenantKey) {
            $tenantItem | Add-Member NoteProperty lastUsed ([DateTime]::UtcNow.ToString('o')) -Force
            break
        }
    }
    Save-Tenants $all
}

function Show-TenantDialog($Existing) {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = if ($Existing) { 'PeakNet | Edit tenant' } else { 'PeakNet | Add tenant' }
    $dialog.Width = 650; $dialog.Height = 710; $dialog.StartPosition = 'CenterParent'; $dialog.FormBorderStyle = 'FixedDialog'
    $dialog.MaximizeBox = $false; $dialog.MinimizeBox = $false; $dialog.BackColor = [System.Drawing.ColorTranslator]::FromHtml('#F5F3EF')
    $dialog.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $labels = @('Customer name', 'Tenant ID (GUID preferred)', 'Admin username (optional)', 'Default portal', 'Documented admin role', 'Tags (comma separated)', 'Customer contact', 'Company website', 'Customer colour', 'Non-secret tenant notes')
    $tops = @(22,70,118,166,214,262,310,358,406,454)
    for ($i=0; $i -lt $labels.Count; $i++) {
        $l = New-Object System.Windows.Forms.Label; $l.Text=$labels[$i]; $l.Left=18; $l.Top=$tops[$i]; $l.Width=190; $dialog.Controls.Add($l)
    }
    $name = New-Object System.Windows.Forms.TextBox; $name.Left=215; $name.Top=18; $name.Width=390
    $tenant = New-Object System.Windows.Forms.TextBox; $tenant.Left=215; $tenant.Top=66; $tenant.Width=390
    $user = New-Object System.Windows.Forms.TextBox; $user.Left=215; $user.Top=114; $user.Width=390
    $portal = New-Object System.Windows.Forms.ComboBox; $portal.Left=215; $portal.Top=162; $portal.Width=390; $portal.DropDownStyle='DropDownList'
    [void]$portal.Items.AddRange(@('Entra admin center','Microsoft 365 admin center','Azure portal'))
    $portal.SelectedIndex=0
    $role = New-Object System.Windows.Forms.ComboBox; $role.Left=215; $role.Top=210; $role.Width=390; $role.DropDownStyle='DropDown'
    [void]$role.Items.AddRange(@('Global Administrator','Privileged Role Administrator','Exchange Administrator','Intune Administrator','Security Administrator','User Administrator','Helpdesk Administrator','GDAP - least privileged','Other / documented in notes'))
    $tags = New-Object System.Windows.Forms.TextBox; $tags.Left=215; $tags.Top=258; $tags.Width=390
    $contact = New-Object System.Windows.Forms.TextBox; $contact.Left=215; $contact.Top=306; $contact.Width=390
    $website = New-Object System.Windows.Forms.TextBox; $website.Left=215; $website.Top=354; $website.Width=390
    $color = New-Object System.Windows.Forms.TextBox; $color.Left=215; $color.Top=402; $color.Width=290; $color.Text='#2D6D76'
    $chooseColor = New-Object System.Windows.Forms.Button; $chooseColor.Text='Choose'; $chooseColor.Left=515; $chooseColor.Top=400; $chooseColor.Width=90; $chooseColor.Height=28
    $notes = New-Object System.Windows.Forms.TextBox; $notes.Left=215; $notes.Top=450; $notes.Width=390; $notes.Height=100; $notes.Multiline=$true; $notes.ScrollBars='Vertical'
    $secretWarning = New-Object System.Windows.Forms.Label; $secretWarning.Text='Do not enter passwords, MFA recovery codes, tokens, or other secrets here. Use 1Password.'; $secretWarning.Left=215; $secretWarning.Top=555; $secretWarning.Width=390; $secretWarning.Height=34; $secretWarning.ForeColor=[Drawing.ColorTranslator]::FromHtml('#A35245')
    if ($Existing) {
        [void](Ensure-TenantFields $Existing)
        $name.Text=$Existing.name; $tenant.Text=$Existing.tenant; $user.Text=$Existing.username; $portal.SelectedItem=$Existing.portal
        $role.Text=[string]$Existing.role; $tags.Text=[string]$Existing.tags; $contact.Text=[string]$Existing.contact; $website.Text=[string]$Existing.website; $color.Text=[string]$Existing.color; $notes.Text=[string]$Existing.notes
    } else { $role.Text='Global Administrator' }
    $chooseColor.Add_Click({
        $picker = New-Object System.Windows.Forms.ColorDialog
        try { $picker.Color=[Drawing.ColorTranslator]::FromHtml($color.Text) } catch {}
        if ($picker.ShowDialog() -eq 'OK') { $color.Text = '#{0:X2}{1:X2}{2:X2}' -f $picker.Color.R,$picker.Color.G,$picker.Color.B }
        $picker.Dispose()
    })
    $ok = New-Object System.Windows.Forms.Button; $ok.Text='Save'; $ok.Left=439; $ok.Top=603; $ok.Width=78
    $cancel = New-Object System.Windows.Forms.Button; $cancel.Text='Cancel'; $cancel.Left=527; $cancel.Top=603; $cancel.Width=78; $cancel.DialogResult='Cancel'
    $ok.FlatStyle='Flat'; $ok.BackColor=[System.Drawing.ColorTranslator]::FromHtml('#2D6D76'); $ok.ForeColor=[System.Drawing.ColorTranslator]::FromHtml('#FAF8F5'); $ok.FlatAppearance.BorderColor=$ok.BackColor
    $cancel.FlatStyle='Flat'; $cancel.BackColor=[System.Drawing.ColorTranslator]::FromHtml('#FBFAF8'); $cancel.ForeColor=[System.Drawing.ColorTranslator]::FromHtml('#152328'); $cancel.FlatAppearance.BorderColor=[System.Drawing.ColorTranslator]::FromHtml('#DCD8D0')
    $dialog.Controls.AddRange(@($name,$tenant,$user,$portal,$role,$tags,$contact,$website,$color,$chooseColor,$notes,$secretWarning,$ok,$cancel)); $dialog.CancelButton=$cancel
    $result = $null
    $ok.Add_Click({
        $userIsValid = [string]::IsNullOrWhiteSpace($user.Text) -or $user.Text -match '^[^@\s]+@[^@\s]+$'
        $colorIsValid = $color.Text -match '^#[0-9a-fA-F]{6}$'
        $websiteIsValid = [string]::IsNullOrWhiteSpace($website.Text) -or $website.Text.Trim() -match '^(https?://)?[^\s/]+(?:/.*)?$'
        if ([string]::IsNullOrWhiteSpace($name.Text) -or -not (Is-ValidTenant $tenant.Text.Trim()) -or -not $userIsValid -or -not $colorIsValid -or -not $websiteIsValid) {
            [System.Windows.Forms.MessageBox]::Show('Enter a customer name, valid tenant GUID/domain, optional valid admin UPN, optional public website, and a colour in #RRGGBB format.','Check details','OK','Warning') | Out-Null; return
        }
        $previousLastUsed = if ($Existing -and $Existing.PSObject.Properties['lastUsed']) { $Existing.lastUsed } else { $null }
        $previousFavorite = if ($Existing -and $Existing.PSObject.Properties['favorite']) { [bool]$Existing.favorite } else { $false }
        $previousSource = if ($Existing -and $Existing.PSObject.Properties['source']) { [string]$Existing.source } else { 'Local' }
        $previousGdapStatus = if ($Existing -and $Existing.PSObject.Properties['gdapStatus']) { [string]$Existing.gdapStatus } else { '' }
        $previousGdapExpires = if ($Existing -and $Existing.PSObject.Properties['gdapExpires']) { [string]$Existing.gdapExpires } else { '' }
        $previousGdapRelationship = if ($Existing -and $Existing.PSObject.Properties['gdapRelationship']) { [string]$Existing.gdapRelationship } else { '' }
        $previousGdapRoles = if ($Existing -and $Existing.PSObject.Properties['gdapRoles']) { [string]$Existing.gdapRoles } else { '' }
        $script:DialogResult = [pscustomobject]@{
            name=$name.Text.Trim(); tenant=$tenant.Text.Trim(); username=$user.Text.Trim(); portal=[string]$portal.SelectedItem
            role=$role.Text.Trim(); tags=$tags.Text.Trim(); contact=$contact.Text.Trim(); website=$website.Text.Trim(); color=$color.Text.ToUpperInvariant(); notes=$notes.Text.Trim()
            favorite=$previousFavorite; lastUsed=$previousLastUsed; status='Closed'
            source=$previousSource;gdapStatus=$previousGdapStatus;gdapExpires=$previousGdapExpires;gdapRelationship=$previousGdapRelationship;gdapRoles=$previousGdapRoles
            modifiedUtc=[DateTime]::UtcNow.ToString('o')
        }
        $dialog.DialogResult='OK'; $dialog.Close()
    })
    $script:DialogResult = $null
    Set-PeakNetModernForm $dialog
    if ($dialog.ShowDialog() -eq 'OK') { $result = $script:DialogResult }
    $dialog.Dispose()
    return $result
}

function Show-WorkDetailsDialog($TenantItem) {
    [void](Ensure-TenantFields $TenantItem)
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text='PeakNet | Confirm customer and start work'; $dialog.Width=620; $dialog.Height=510; $dialog.StartPosition='CenterParent'; $dialog.FormBorderStyle='FixedDialog'
    $dialog.MaximizeBox=$false; $dialog.MinimizeBox=$false; $dialog.BackColor=[Drawing.ColorTranslator]::FromHtml('#F5F3EF'); $dialog.Font=New-Object Drawing.Font('Segoe UI',9)
    $identity = New-Object System.Windows.Forms.Panel; $identity.Left=18; $identity.Top=18; $identity.Width=565; $identity.Height=95
    try { $identity.BackColor=[Drawing.ColorTranslator]::FromHtml([string]$TenantItem.color) } catch { $identity.BackColor=[Drawing.ColorTranslator]::FromHtml('#2D6D76') }
    $customer = New-Object System.Windows.Forms.Label; $customer.Left=18; $customer.Top=14; $customer.Width=525; $customer.Height=32; $customer.Font=New-Object Drawing.Font('Segoe UI',17,[Drawing.FontStyle]::Bold); $customer.ForeColor=[Drawing.Color]::White; $customer.Text=[string]$TenantItem.name
    $identityDetail = New-Object System.Windows.Forms.Label; $identityDetail.Left=20; $identityDetail.Top=52; $identityDetail.Width=525; $identityDetail.Height=31; $identityDetail.ForeColor=[Drawing.Color]::White; $identityDetail.Text="$([string]$TenantItem.username)  |  $([string]$TenantItem.role)"
    $identity.Controls.AddRange(@($customer,$identityDetail))
    $ticketLabel=New-Object System.Windows.Forms.Label; $ticketLabel.Text='Ticket / case number (optional)'; $ticketLabel.Left=18; $ticketLabel.Top=134; $ticketLabel.Width=190
    $ticket=New-Object System.Windows.Forms.TextBox; $ticket.Left=220; $ticket.Top=130; $ticket.Width=363
    $notesLabel=New-Object System.Windows.Forms.Label; $notesLabel.Text='Work description (optional)'; $notesLabel.Left=18; $notesLabel.Top=182; $notesLabel.Width=190
    $workNotes=New-Object System.Windows.Forms.TextBox; $workNotes.Left=220; $workNotes.Top=178; $workNotes.Width=363; $workNotes.Height=105; $workNotes.Multiline=$true; $workNotes.ScrollBars='Vertical'
    $billable=New-Object System.Windows.Forms.CheckBox; $billable.Text='Billable work'; $billable.Left=220; $billable.Top=298; $billable.Checked=$true; $billable.Width=160
    $excludeIdle=New-Object System.Windows.Forms.CheckBox; $excludeIdle.Text="Pause tracking after $([int]$script:AppSettings.idleMinutes) minutes of computer inactivity"; $excludeIdle.Left=220; $excludeIdle.Top=324; $excludeIdle.Checked=$true; $excludeIdle.Width=363
    $summary=New-Object System.Windows.Forms.Label; $summary.Left=18; $summary.Top=352; $summary.Width=565; $summary.Height=55; $summary.Text="Portal: $([string]$TenantItem.portal)`r`nTenant: $([string]$TenantItem.tenant)$(if([string]$TenantItem.source -like 'Microsoft Graph*'){"`r`nGDAP: $([string]$TenantItem.gdapStatus)  |  $([string]$TenantItem.gdapRoles)"})"; $summary.ForeColor=[Drawing.ColorTranslator]::FromHtml('#526267')
    $start=New-Object System.Windows.Forms.Button; $start.Text='Start secure session'; $start.Left=395; $start.Top=415; $start.Width=188; $start.Height=34
    $cancel=New-Object System.Windows.Forms.Button; $cancel.Text='Cancel'; $cancel.Left=300; $cancel.Top=415; $cancel.Width=85; $cancel.Height=34; $cancel.DialogResult='Cancel'
    $start.BackColor=[Drawing.ColorTranslator]::FromHtml('#2D6D76'); $start.ForeColor=[Drawing.Color]::White; $start.FlatStyle='Flat'
    $dialog.Controls.AddRange(@($identity,$ticketLabel,$ticket,$notesLabel,$workNotes,$billable,$excludeIdle,$summary,$start,$cancel)); $dialog.CancelButton=$cancel
    $script:WorkDetailsResult=$null
    $start.Add_Click({
        $script:WorkDetailsResult=[pscustomobject]@{Ticket=$ticket.Text.Trim();WorkNotes=$workNotes.Text.Trim();Billable=[bool]$billable.Checked;ExcludeIdle=[bool]$excludeIdle.Checked}
        $dialog.DialogResult='OK'; $dialog.Close()
    })
    Set-PeakNetModernForm $dialog
    $result=$null; if($dialog.ShowDialog() -eq 'OK'){$result=$script:WorkDetailsResult}; $dialog.Dispose(); return $result
}

function Add-ManualTimeAdjustment {
    $all=@(Load-Tenants | Sort-Object name); if(-not $all.Count){return $false}
    $dialog=New-Object System.Windows.Forms.Form; $dialog.Text='PeakNet | Add time adjustment'; $dialog.Width=590; $dialog.Height=470; $dialog.StartPosition='CenterParent'; $dialog.FormBorderStyle='FixedDialog'; $dialog.MaximizeBox=$false; $dialog.MinimizeBox=$false
    $dialog.BackColor=[Drawing.ColorTranslator]::FromHtml('#F5F3EF'); $dialog.Font=New-Object Drawing.Font('Segoe UI',9)
    $labels=@('Customer','Date','Minutes (+/-)','Ticket / case','Work note'); $tops=@(24,72,120,168,216)
    for($i=0;$i -lt $labels.Count;$i++){$l=New-Object System.Windows.Forms.Label;$l.Text=$labels[$i];$l.Left=18;$l.Top=$tops[$i];$l.Width=150;$dialog.Controls.Add($l)}
    $customer=New-Object System.Windows.Forms.ComboBox;$customer.Left=175;$customer.Top=20;$customer.Width=370;$customer.DropDownStyle='DropDownList';foreach($item in $all){[void]$customer.Items.Add($item)};$customer.DisplayMember='name';$customer.SelectedIndex=0
    $date=New-Object System.Windows.Forms.DateTimePicker;$date.Left=175;$date.Top=68;$date.Width=200;$date.Format='Short'
    $minutes=New-Object System.Windows.Forms.NumericUpDown;$minutes.Left=175;$minutes.Top=116;$minutes.Width=120;$minutes.Minimum=-1440;$minutes.Maximum=1440;$minutes.Value=15
    $ticket=New-Object System.Windows.Forms.TextBox;$ticket.Left=175;$ticket.Top=164;$ticket.Width=370
    $note=New-Object System.Windows.Forms.TextBox;$note.Left=175;$note.Top=212;$note.Width=370;$note.Height=105;$note.Multiline=$true;$note.ScrollBars='Vertical'
    $billable=New-Object System.Windows.Forms.CheckBox;$billable.Text='Billable';$billable.Left=175;$billable.Top=330;$billable.Checked=$true
    $save=New-Object System.Windows.Forms.Button;$save.Text='Save adjustment';$save.Left=395;$save.Top=375;$save.Width=150;$save.Height=34
    $cancel=New-Object System.Windows.Forms.Button;$cancel.Text='Cancel';$cancel.Left=300;$cancel.Top=375;$cancel.Width=85;$cancel.Height=34;$cancel.DialogResult='Cancel'
    $dialog.Controls.AddRange(@($customer,$date,$minutes,$ticket,$note,$billable,$save,$cancel));$dialog.CancelButton=$cancel
    $saved=$false
    $save.Add_Click({
        if([int]$minutes.Value -eq 0){[System.Windows.Forms.MessageBox]::Show('Minutes cannot be zero. Use a negative value to correct previously tracked time.','Check adjustment')|Out-Null;return}
        $selectedTenant=$customer.SelectedItem;$localEnd=$date.Value.Date.AddHours([DateTime]::Now.Hour).AddMinutes([DateTime]::Now.Minute);$endedUtc=$localEnd.ToUniversalTime();$seconds=[int64]([int]$minutes.Value*60)
        $entry=[ordered]@{version=1;sessionId=[guid]::NewGuid().ToString('N');computer=[string]$env:COMPUTERNAME;windowsUser=[string]$env:USERNAME;customer=[string]$selectedTenant.name;tenant=[string]$selectedTenant.tenant;adminAccount=[string]$selectedTenant.username;startedUtc=$endedUtc.AddSeconds(-$seconds).ToString('o');endedUtc=$endedUtc.ToString('o');durationSeconds=$seconds;endReason='Manual adjustment';entryType='adjustment';ticket=$ticket.Text.Trim();workNotes=$note.Text.Trim();billable=[bool]$billable.Checked}
        try{($entry|ConvertTo-Json -Compress)|Add-Content -LiteralPath $TimeTrackingFile -Encoding UTF8 -ErrorAction Stop;$script:AdjustmentSaved=$true;$dialog.DialogResult='OK';$dialog.Close();Write-Audit 'TIME_ADJUSTMENT_SAVED' ([string]$selectedTenant.name)}catch{[System.Windows.Forms.MessageBox]::Show("Could not save the adjustment.`n`n$($_.Exception.Message)",'Save failed','OK','Error')|Out-Null}
    })
    Set-PeakNetModernForm $dialog
    $script:AdjustmentSaved=$false;[void]$dialog.ShowDialog();$saved=$script:AdjustmentSaved;$dialog.Dispose();return $saved
}

function Export-TimeCsv {
    $entries=@(Get-TimeEntries);if(-not $entries.Count){[System.Windows.MessageBox]::Show('There are no completed time entries to export.','Export time')|Out-Null;return}
    $save=New-Object System.Windows.Forms.SaveFileDialog;$save.Filter='CSV file (*.csv)|*.csv';$save.FileName='PeakNet-time-{0}.csv' -f [DateTime]::Now.ToString('yyyy-MM-dd')
    if($save.ShowDialog() -ne 'OK'){$save.Dispose();return}
    $rows=$entries|Sort-Object {[string]$_.endedUtc}|ForEach-Object{[pscustomobject][ordered]@{Customer=[string]$_.customer;Tenant=[string]$_.tenant;AdminAccount=[string]$_.adminAccount;StartedLocal=try{(ConvertTo-UtcDateTime $_.startedUtc).ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss')}catch{[string]$_.startedUtc};EndedLocal=try{(ConvertTo-UtcDateTime $_.endedUtc).ToLocalTime().ToString('yyyy-MM-dd HH:mm:ss')}catch{[string]$_.endedUtc};Hours=[Math]::Round(([double]$_.durationSeconds/3600),2);IdleExcludedHours=if($_.PSObject.Properties.Name -contains 'idleExcludedSeconds'){[Math]::Round(([double]$_.idleExcludedSeconds/3600),2)}else{0};Billable=if($_.PSObject.Properties.Name -contains 'billable'){[bool]$_.billable}else{$true};Ticket=if($_.PSObject.Properties.Name -contains 'ticket'){[string]$_.ticket}else{''};WorkNotes=if($_.PSObject.Properties.Name -contains 'workNotes'){[string]$_.workNotes}else{''};Type=if($_.PSObject.Properties.Name -contains 'entryType'){[string]$_.entryType}else{'session'};Recovered=if($_.PSObject.Properties.Name -contains 'recovered'){[bool]$_.recovered}else{$false};Computer=[string]$_.computer}}
    try{$rows|Export-Csv -LiteralPath $save.FileName -NoTypeInformation -Encoding UTF8;Write-Audit 'TIME_EXPORTED_CSV' $save.FileName;[System.Windows.MessageBox]::Show("Time exported to:`n$($save.FileName)",'Export complete')|Out-Null}catch{[System.Windows.MessageBox]::Show("Could not export time.`n`n$($_.Exception.Message)",'Export failed','OK','Error')|Out-Null};$save.Dispose()
}

function Export-MonthlyTimeCsv {
    $rows = @(Get-MonthlyTimeReportRows)
    if (-not $rows.Count) { [System.Windows.MessageBox]::Show('There is no monthly time to export.','Export monthly time') | Out-Null; return }
    $save = New-Object System.Windows.Forms.SaveFileDialog
    $save.Filter = 'CSV file (*.csv)|*.csv'
    $save.FileName = 'PeakNet-monthly-time-{0}.csv' -f [DateTime]::Now.ToString('yyyy-MM-dd')
    if ($save.ShowDialog() -ne 'OK') { $save.Dispose(); return }
    try {
        $rows | Export-Csv -LiteralPath $save.FileName -NoTypeInformation -Encoding UTF8
        Write-Audit 'MONTHLY_TIME_EXPORTED_CSV' $save.FileName
        [System.Windows.MessageBox]::Show("Monthly time exported to:`n$($save.FileName)",'Export complete') | Out-Null
    } catch {
        [System.Windows.MessageBox]::Show("Could not export monthly time.`n`n$($_.Exception.Message)",'Export failed','OK','Error') | Out-Null
    }
    $save.Dispose()
}

function Set-GridData($GridControl, [array]$Rows) {
    $list=[Collections.ArrayList]::new();foreach($row in @($Rows)){[void]$list.Add($row)};$GridControl.DataSource=$list
}

function Show-PortalPicker {
    $dialog=New-Object System.Windows.Forms.Form;$dialog.Text='PeakNet | Open admin portal';$dialog.Width=430;$dialog.Height=420;$dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false
    $list=New-Object System.Windows.Forms.ListBox;$list.Left=18;$list.Top=18;$list.Width=375;$list.Height=285;$list.Font=New-Object Drawing.Font('Segoe UI',10)
    foreach($portalItem in @(Get-PortalDefinitions)){[void]$list.Items.Add($portalItem.Name)};$list.SelectedIndex=0
    $open=New-Object System.Windows.Forms.Button;$open.Text='Open portal';$open.Left=265;$open.Top=320;$open.Width=128;$open.Height=34
    $cancel=New-Object System.Windows.Forms.Button;$cancel.Text='Cancel';$cancel.Left=170;$cancel.Top=320;$cancel.Width=85;$cancel.Height=34;$cancel.DialogResult='Cancel'
    $script:PortalPickerResult=$null;$open.Add_Click({$script:PortalPickerResult=[string]$list.SelectedItem;$dialog.DialogResult='OK';$dialog.Close()});$list.Add_DoubleClick({if($list.SelectedItem){$script:PortalPickerResult=[string]$list.SelectedItem;$dialog.DialogResult='OK';$dialog.Close()}})
    $dialog.Controls.AddRange(@($list,$open,$cancel));$dialog.CancelButton=$cancel;Set-PeakNetModernForm $dialog;$result=$null;if($dialog.ShowDialog() -eq 'OK'){$result=$script:PortalPickerResult};$dialog.Dispose();return $result
}

function Show-CatalogTools {
    $choice=[System.Windows.MessageBox]::Show("Choose Yes to export a tenant-catalog backup.`nChoose No to import a previous backup.`n`nBackups contain tenant metadata and admin UPNs, but never passwords or browser sessions.",'Backup / import','YesNoCancel','Question')
    if($choice -eq 'Cancel'){return}
    if($choice -eq 'Yes'){
        $save=New-Object System.Windows.Forms.SaveFileDialog;$save.Filter='PeakNet tenant backup (*.json)|*.json';$save.InitialDirectory=$BackupRoot;$save.FileName='PeakNet-tenants-{0}.json' -f [DateTime]::Now.ToString('yyyy-MM-dd')
        if($save.ShowDialog() -eq 'OK'){try{ConvertTo-Json -InputObject @(Load-Tenants) -Depth 6|Set-Content -LiteralPath $save.FileName -Encoding UTF8;Write-Audit 'TENANT_CATALOG_EXPORTED' $save.FileName;[System.Windows.MessageBox]::Show('Tenant catalog backup created.','Backup complete')|Out-Null}catch{[System.Windows.MessageBox]::Show($_.Exception.Message,'Backup failed','OK','Error')|Out-Null}};$save.Dispose();return
    }
    $open=New-Object System.Windows.Forms.OpenFileDialog;$open.Filter='PeakNet tenant backup (*.json)|*.json|JSON file (*.json)|*.json'
    if($open.ShowDialog() -ne 'OK'){$open.Dispose();return}
    try{$imported=@(Get-Content -LiteralPath $open.FileName -Raw -Encoding UTF8|ConvertFrom-Json);foreach($item in $imported){if([string]::IsNullOrWhiteSpace([string]$item.name)-or -not(Is-ValidTenant([string]$item.tenant))){throw 'The selected file contains an invalid customer or tenant ID.'};[void](Ensure-TenantFields $item);Touch-Tenant $item}}catch{[System.Windows.MessageBox]::Show("Could not import this catalog.`n`n$($_.Exception.Message)",'Import failed','OK','Error')|Out-Null;$open.Dispose();return}
    $mode=[System.Windows.MessageBox]::Show("Import $($imported.Count) tenants?`n`nYes = merge and update matching tenant IDs`nNo = replace the current catalog`nCancel = do nothing",'Import tenant catalog','YesNoCancel','Warning');if($mode -eq 'Cancel'){$open.Dispose();return}
    if($mode -eq 'Yes'){$map=@{};foreach($item in @(Load-Tenants)){$map[([string]$item.tenant).ToLowerInvariant()]=$item};foreach($item in $imported){$map[([string]$item.tenant).ToLowerInvariant()]=$item};Save-Tenants @($map.Values)}else{Save-Tenants $imported}
    Write-Audit 'TENANT_CATALOG_IMPORTED' $open.FileName;$open.Dispose();Refresh-Grid
}

function Show-SecurityReport {
    $findings=@(Get-SecurityFindings);if(-not $findings.Count){[System.Windows.MessageBox]::Show('No catalog or session safety findings were detected.','Security checks','OK','Information')|Out-Null;return}
    $form=New-Object System.Windows.Forms.Form;$form.Text='PeakNet | Tenant security checks';$form.Width=900;$form.Height=580;$form.StartPosition='CenterParent'
    $gridView=New-Object System.Windows.Forms.DataGridView;$gridView.Dock='Fill';$gridView.ReadOnly=$true;$gridView.AllowUserToAddRows=$false;$gridView.AutoSizeColumnsMode='Fill';$gridView.SelectionMode='FullRowSelect';Set-GridData $gridView $findings;$form.Controls.Add($gridView);Set-PeakNetModernForm $form;[void]$form.ShowDialog();$form.Dispose()
}

function Get-TenantHealthRows {
    $now=[DateTime]::UtcNow
    return @(Load-Tenants | ForEach-Object {
        $tenantItem=$_;[void](Ensure-TenantFields $tenantItem);$issues=[Collections.Generic.List[string]]::new();$severity=0
        if([string]::IsNullOrWhiteSpace([string]$tenantItem.username)){$issues.Add('Admin account missing');$severity=[Math]::Max($severity,1)}
        if([string]::IsNullOrWhiteSpace([string]$tenantItem.role)){$issues.Add('Role not documented');$severity=[Math]::Max($severity,1)}
        if([string]$tenantItem.source -like 'Microsoft Graph*'){
            if([string]$tenantItem.gdapStatus -notmatch '^(?i)active$'){$issues.Add("GDAP: $([string]$tenantItem.gdapStatus)");$severity=[Math]::Max($severity,2)}
            if(-not[string]::IsNullOrWhiteSpace([string]$tenantItem.gdapExpires)){try{$days=((ConvertTo-UtcDateTime $tenantItem.gdapExpires)-$now).TotalDays;if($days-lt 0){$issues.Add('GDAP expired');$severity=2}elseif($days-lt 30){$issues.Add(('GDAP expires in {0} days'-f[Math]::Ceiling($days)));$severity=[Math]::Max($severity,1)}}catch{$issues.Add('Invalid GDAP expiry');$severity=[Math]::Max($severity,1)}}
        }
        [pscustomobject][ordered]@{Status=@('Healthy','Review','Critical')[$severity];Customer=[string]$tenantItem.name;Source=if([string]$tenantItem.source -like 'Microsoft Graph*'){'Microsoft Graph / GDAP'}else{'Local'};GDAP=[string]$tenantItem.gdapStatus;Expires=if([string]::IsNullOrWhiteSpace([string]$tenantItem.gdapExpires)){''}else{try{(ConvertTo-UtcDateTime $tenantItem.gdapExpires).ToLocalTime().ToString('yyyy-MM-dd')}catch{[string]$tenantItem.gdapExpires}};Issues=if($issues.Count){$issues -join '; '}else{'No catalog or GDAP warning'}}
    } | Sort-Object @{Expression={@{'Critical'=0;'Review'=1;'Healthy'=2}[[string]$_.Status]}},Customer)
}

function Show-OperationsDashboard {
    $form=New-Object System.Windows.Forms.Form;$form.Text='PeakNet | Operations dashboard';$form.Width=1120;$form.Height=720;$form.StartPosition='CenterParent';$form.BackColor=[Drawing.ColorTranslator]::FromHtml('#F5F3EF');$form.Font=New-Object Drawing.Font('Segoe UI',9)
    $headline=New-Object System.Windows.Forms.Label;$headline.Left=18;$headline.Top=16;$headline.Width=1065;$headline.Height=54;$headline.Font=New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold)
    $tabs=New-Object System.Windows.Forms.TabControl;$tabs.Left=18;$tabs.Top=78;$tabs.Width=1065;$tabs.Height=550
    $activeTab=New-Object System.Windows.Forms.TabPage;$activeTab.Text='Active sessions';$monthTab=New-Object System.Windows.Forms.TabPage;$monthTab.Text='This month';$healthTab=New-Object System.Windows.Forms.TabPage;$healthTab.Text='Tenant health';$recentTab=New-Object System.Windows.Forms.TabPage;$recentTab.Text='Recently used'
    $activeGrid=New-Object System.Windows.Forms.DataGridView;$activeGrid.Dock='Fill';$activeGrid.ReadOnly=$true;$activeGrid.AllowUserToAddRows=$false;$activeGrid.AutoSizeColumnsMode='Fill'
    $monthGrid=New-Object System.Windows.Forms.DataGridView;$monthGrid.Dock='Fill';$monthGrid.ReadOnly=$true;$monthGrid.AllowUserToAddRows=$false;$monthGrid.AutoSizeColumnsMode='Fill'
    $healthGrid=New-Object System.Windows.Forms.DataGridView;$healthGrid.Dock='Fill';$healthGrid.ReadOnly=$true;$healthGrid.AllowUserToAddRows=$false;$healthGrid.AutoSizeColumnsMode='Fill'
    $recentGrid=New-Object System.Windows.Forms.DataGridView;$recentGrid.Dock='Fill';$recentGrid.ReadOnly=$true;$recentGrid.AllowUserToAddRows=$false;$recentGrid.AutoSizeColumnsMode='Fill'
    $activeTab.Controls.Add($activeGrid);$monthTab.Controls.Add($monthGrid);$healthTab.Controls.Add($healthGrid);$recentTab.Controls.Add($recentGrid);$tabs.TabPages.AddRange(@($activeTab,$monthTab,$healthTab,$recentTab))
    $refresh=New-Object System.Windows.Forms.Button;$refresh.Text='Refresh';$refresh.Left=18;$refresh.Top=640;$refresh.Width=100;$refresh.Height=32
    $openShared=New-Object System.Windows.Forms.Button;$openShared.Text='Open shared data';$openShared.Left=128;$openShared.Top=640;$openShared.Width=140;$openShared.Height=32;$openShared.Add_Click({Start-Process explorer.exe -ArgumentList ('"'+$SharedDataRoot+'"')})
    $close=New-Object System.Windows.Forms.Button;$close.Text='Close';$close.Left=983;$close.Top=640;$close.Width=100;$close.Height=32;$close.Add_Click({$form.Close()})
    $populate={
        $now=[DateTime]::UtcNow;$idleNow=Get-SystemIdleSeconds
        $activeRows=@($sessions.Values|ForEach-Object{[pscustomobject][ordered]@{Customer=[string]$_.Name;Tracked=(Format-Duration (Get-SessionTrackedSeconds $_ $now));Idle=if([bool]$_.ExcludeIdle -and $idleNow -ge ([double]$script:AppSettings.idleMinutes*60)){'Paused'}else{'Tracking'};Ticket=[string]$_.Ticket;Started=$_.StartedUtc.ToLocalTime().ToString('yyyy-MM-dd HH:mm')}})
        $monthPrefix=[DateTime]::Now.ToString('yyyy-MM');$monthRows=@(Get-MonthlyTimeReportRows|Where-Object{[string]$_.Month -like "$monthPrefix*"});$healthRows=@(Get-TenantHealthRows);$recentRows=@(Load-Tenants|Where-Object{-not[string]::IsNullOrWhiteSpace([string]$_.lastUsed)}|Sort-Object {ConvertTo-UtcDateTime $_.lastUsed} -Descending|Select-Object -First 30|ForEach-Object{[pscustomobject][ordered]@{Customer=[string]$_.name;'Last used'=(ConvertTo-UtcDateTime $_.lastUsed).ToLocalTime().ToString('yyyy-MM-dd HH:mm');Account=[string]$_.username;Tags=[string]$_.tags}})
        Set-GridData $activeGrid $activeRows;Set-GridData $monthGrid $monthRows;Set-GridData $healthGrid $healthRows;Set-GridData $recentGrid $recentRows
        $todaySeconds=0;foreach($entry in @(Get-TimeEntries)){try{$ended=(ConvertTo-UtcDateTime $entry.endedUtc).ToLocalTime();if($ended.Date-eq[DateTime]::Today){$todaySeconds+=[double]$entry.durationSeconds}}catch{}}
        $todayStartUtc=[DateTime]::Today.ToUniversalTime();foreach($active in @($sessions.Values)){$overlapStart=if($active.StartedUtc -gt $todayStartUtc){$active.StartedUtc}else{$todayStartUtc};if($now -gt $overlapStart){$idle=[double]$active.IdleSeconds;$todaySeconds+=[Math]::Max(0,($now-$overlapStart).TotalSeconds-$idle)}}
        $attention=@($healthRows|Where-Object { $_.Status -ne 'Healthy' }).Count;$headline.Text="$($sessions.Count) active session(s)   |   Today: $(Format-Duration $todaySeconds)   |   $attention tenant(s) need attention`r`nShared sources: $script:CatalogComputerCount computer(s)   |   conflicts: $script:CatalogConflictCount   |   $SharedDataRoot"
    }
    $refresh.Add_Click({&$populate});$form.Controls.AddRange(@($headline,$tabs,$refresh,$openShared,$close));&$populate;Set-PeakNetModernForm $form;[void]$form.ShowDialog();$form.Dispose()
}

function Show-MonthlyChart {
    Add-Type -AssemblyName System.Windows.Forms.DataVisualization
    $allRows=@(Get-MonthlyTimeReportRows -IncludeHours)
    if(-not$allRows.Count){[System.Windows.MessageBox]::Show('There is no tracked time to chart.','Monthly chart')|Out-Null;return}
    $form=New-Object System.Windows.Forms.Form;$form.Text='PeakNet | Monthly tenant time';$form.Width=1180;$form.Height=760;$form.StartPosition='CenterParent';$form.BackColor=[Drawing.ColorTranslator]::FromHtml('#F5F3EF')
    $monthLabel=New-Object System.Windows.Forms.Label;$monthLabel.Text='Month';$monthLabel.Left=18;$monthLabel.Top=22;$monthLabel.Width=50
    $month=New-Object System.Windows.Forms.ComboBox;$month.Left=72;$month.Top=18;$month.Width=220;$month.DropDownStyle='DropDownList'
    foreach($monthName in @($allRows|Select-Object -ExpandProperty Month -Unique)){[void]$month.Items.Add($monthName)};$month.SelectedIndex=0
    $note=New-Object System.Windows.Forms.Label;$note.Left=320;$note.Top=21;$note.Width=810;$note.Text='Billable and non-billable hours by customer. The 20 customers with the most time are shown.';$note.ForeColor=[Drawing.ColorTranslator]::FromHtml('#526267')
    $chart=New-Object System.Windows.Forms.DataVisualization.Charting.Chart;$chart.Left=18;$chart.Top=58;$chart.Width=1125;$chart.Height=635;$chart.BackColor=[Drawing.ColorTranslator]::FromHtml('#FBFAF8')
    $area=New-Object System.Windows.Forms.DataVisualization.Charting.ChartArea 'TimeArea';$area.AxisX.Title='Hours';$area.AxisY.Interval=1;$area.AxisY.LabelStyle.Font=New-Object Drawing.Font('Segoe UI',8);$area.AxisX.MajorGrid.LineColor=[Drawing.Color]::Gainsboro;$chart.ChartAreas.Add($area)
    $billableSeries=New-Object System.Windows.Forms.DataVisualization.Charting.Series 'Billable';$billableSeries.ChartType='StackedBar';$billableSeries.Color=[Drawing.ColorTranslator]::FromHtml('#2D6D76');$billableSeries.IsValueShownAsLabel=$true
    $nonSeries=New-Object System.Windows.Forms.DataVisualization.Charting.Series 'Non-billable';$nonSeries.ChartType='StackedBar';$nonSeries.Color=[Drawing.ColorTranslator]::FromHtml('#C9A96E');$nonSeries.IsValueShownAsLabel=$true
    $chart.Series.Add($billableSeries);$chart.Series.Add($nonSeries);$legend=New-Object System.Windows.Forms.DataVisualization.Charting.Legend;$chart.Legends.Add($legend)
    $populateChart={
        $billableSeries.Points.Clear();$nonSeries.Points.Clear();$selectedMonth=[string]$month.SelectedItem
        foreach($row in @($allRows|Where-Object { $_.Month -eq $selectedMonth }|Sort-Object TotalHours -Descending|Select-Object -First 20|Sort-Object TotalHours)){
            [void]$billableSeries.Points.AddXY([string]$row.Customer,[double]$row.BillableHours);[void]$nonSeries.Points.AddXY([string]$row.Customer,[double]$row.NonBillableHours)
        }
    }
    $month.Add_SelectedIndexChanged({&$populateChart});$close=New-Object System.Windows.Forms.Button;$close.Text='Close';$close.Left=1043;$close.Top=700;$close.Width=100;$close.Height=32;$close.Add_Click({$form.Close()})
    $form.Controls.AddRange(@($monthLabel,$month,$note,$chart,$close));&$populateChart;Set-PeakNetModernForm $form;[void]$form.ShowDialog();$form.Dispose()
}

function Show-ExternalForwardingDialog($TenantItem) {
    if(-not$TenantItem){[Windows.Forms.MessageBox]::Show('Select a customer first.','External forwarding')|Out-Null;return}
    [void](Ensure-TenantFields $TenantItem)
    if(-not(Get-Module -ListAvailable ExchangeOnlineManagement)){[Windows.Forms.MessageBox]::Show('Microsoft ExchangeOnlineManagement is required.','Module required','OK','Warning')|Out-Null;return}
    $pwsh=Get-Command pwsh.exe -ErrorAction SilentlyContinue;if(-not$pwsh){[Windows.Forms.MessageBox]::Show('PowerShell 7 is required for secure Microsoft device sign-in.','PowerShell 7 required','OK','Warning')|Out-Null;return}
    $workerPath=Join-Path $PSScriptRoot 'Exchange-Forwarding-Worker.ps1';if(-not(Test-Path -LiteralPath $workerPath)){[Windows.Forms.MessageBox]::Show('Exchange-Forwarding-Worker.ps1 is missing from the application folder.','Forwarding worker missing','OK','Error')|Out-Null;return}
    $nl=[Environment]::NewLine
    $dialog=New-Object Windows.Forms.Form;$dialog.Text='PeakNet | External email forwarding';$dialog.Width=790;$dialog.Height=720;$dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false;$dialog.BackColor=[Drawing.ColorTranslator]::FromHtml('#F5F3EF')
    $identity=New-Object Windows.Forms.Panel;$identity.Left=22;$identity.Top=18;$identity.Width=730;$identity.Height=72;try{$identity.BackColor=[Drawing.ColorTranslator]::FromHtml([string]$TenantItem.color)}catch{$identity.BackColor=[Drawing.ColorTranslator]::FromHtml('#2D6D76')}
    $customer=New-Object Windows.Forms.Label;$customer.Left=18;$customer.Top=10;$customer.Width=690;$customer.Height=27;$customer.Font=New-Object Drawing.Font('Segoe UI',15,[Drawing.FontStyle]::Bold);$customer.ForeColor=[Drawing.Color]::White;$customer.Text=[string]$TenantItem.name
    $tenantInfo=New-Object Windows.Forms.Label;$tenantInfo.Left=18;$tenantInfo.Top=42;$tenantInfo.Width=690;$tenantInfo.ForeColor=[Drawing.Color]::White;$tenantInfo.Text="Tenant: $([string]$TenantItem.tenant)";$identity.Controls.AddRange(@($customer,$tenantInfo))
    $labels=@('Authentication','Administrator sign-in UPN','Mailbox to forward','External destination');$tops=@(116,162,208,254);for($i=0;$i-lt4;$i++){$l=New-Object Windows.Forms.Label;$l.Text=$labels[$i];$l.Left=24;$l.Top=$tops[$i];$l.Width=190;$dialog.Controls.Add($l)}
    $auth=New-Object Windows.Forms.ComboBox;$auth.Left=220;$auth.Top=112;$auth.Width=510;$auth.DropDownStyle='DropDownList';[void]$auth.Items.AddRange(@('MSP delegated access (GDAP)','Direct customer administrator'));$auth.SelectedIndex=if([string]$TenantItem.source-like'Microsoft Graph*'){0}else{1}
    $cfg=Load-MspConfig;$partnerUpn=if($script:MspConnection-and-not[string]::IsNullOrWhiteSpace([string]$script:MspConnection.UserPrincipalName)){[string]$script:MspConnection.UserPrincipalName}elseif($cfg-and-not[string]::IsNullOrWhiteSpace([string]$cfg.lastAccount)){[string]$cfg.lastAccount}else{''};$login=New-Object Windows.Forms.TextBox;$login.Left=220;$login.Top=158;$login.Width=510;$login.Text=if($auth.SelectedIndex-eq0){$partnerUpn}else{[string]$TenantItem.username};$auth.Add_SelectedIndexChanged({$login.Text=if($auth.SelectedIndex-eq0){$partnerUpn}else{[string]$TenantItem.username}})
    $mailbox=New-Object Windows.Forms.TextBox;$mailbox.Left=220;$mailbox.Top=204;$mailbox.Width=510;$mailbox.Text=if(([string]$TenantItem.username)-match'^[^@\s]+@[^@\s]+$'){[string]$TenantItem.username}else{''}
    $target=New-Object Windows.Forms.TextBox;$target.Left=220;$target.Top=250;$target.Width=510
    $keep=New-Object Windows.Forms.CheckBox;$keep.Left=220;$keep.Top=292;$keep.Width=510;$keep.Checked=$true;$keep.Text='Keep a copy in the original mailbox'
    $authorized=New-Object Windows.Forms.CheckBox;$authorized.Left=24;$authorized.Top=334;$authorized.Width=706;$authorized.Height=38;$authorized.Text='I confirm that the customer has authorized this external forwarding configuration.'
    $warning=New-Object Windows.Forms.Label;$warning.Left=24;$warning.Top=380;$warning.Width=706;$warning.Height=67;$warning.ForeColor=[Drawing.ColorTranslator]::FromHtml('#A35245');$warning.Text='Security notice: External forwarding can disclose customer information. This creates visible mailbox-level forwarding, not a hidden inbox rule. A blocking outbound spam policy still wins and is never weakened by this tool.'
    $status=New-Object Windows.Forms.TextBox;$status.Left=24;$status.Top=456;$status.Width=706;$status.Height=105;$status.Multiline=$true;$status.ReadOnly=$true;$status.ScrollBars='Vertical';$status.Text='Ready. Edge InPrivate will open for secure Microsoft device sign-in.'
    $check=New-Object Windows.Forms.Button;$check.Text='Check current';$check.Left=24;$check.Top=585;$check.Width=120;$check.Height=36
    $apply=New-Object Windows.Forms.Button;$apply.Text='Apply forwarding';$apply.Left=154;$apply.Top=585;$apply.Width=135;$apply.Height=36;$apply.BackColor=[Drawing.ColorTranslator]::FromHtml('#2D6D76');$apply.ForeColor=[Drawing.Color]::White
    $disable=New-Object Windows.Forms.Button;$disable.Text='Disable forwarding';$disable.Left=299;$disable.Top=585;$disable.Width=140;$disable.Height=36
    $policy=New-Object Windows.Forms.Button;$policy.Text='Open forwarding policy';$policy.Left=449;$policy.Top=585;$policy.Width=165;$policy.Height=36
    $close=New-Object Windows.Forms.Button;$close.Text='Close';$close.Left=624;$close.Top=585;$close.Width=106;$close.Height=36;$close.DialogResult='Cancel'
    $isEmail={param([string]$v)try{$m=[Net.Mail.MailAddress]::new($v);$m.Address-eq$v}catch{$false}}
    $busy={param([bool]$on,[string]$message)$check.Enabled=-not$on;$apply.Enabled=-not$on;$disable.Enabled=-not$on;$policy.Enabled=-not$on;$close.Enabled=-not$on;$dialog.ControlBox=-not$on;$dialog.UseWaitCursor=$on;if($message){$status.Text=$message};[Windows.Forms.Application]::DoEvents()}
    $runWorker={
        param([string]$Action,[string]$Destination,[bool]$KeepCopy)
        $jobRoot=Join-Path $AppRoot 'ExchangeJobs';New-Item -ItemType Directory -Force -Path $jobRoot|Out-Null
        $jobFolder=Join-Path $jobRoot ([guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $jobFolder|Out-Null
        $requestPath=Join-Path $jobFolder 'request.json';$statusPath=Join-Path $jobFolder 'status.txt';$resultPath=Join-Path $jobFolder 'result.json'
        [ordered]@{Action=$Action;Authentication=$(if($auth.SelectedIndex-eq0){'GDAP'}else{'Direct'});Login=$login.Text.Trim();Tenant=([string]$TenantItem.tenant).Trim();Source=$mailbox.Text.Trim();Destination=$Destination;KeepCopy=$KeepCopy}|ConvertTo-Json|Set-Content -LiteralPath $requestPath -Encoding UTF8
        $process=$null
        try{
            &$busy $true 'Opening an Edge InPrivate device-login page...'
            $edge=Find-EdgeBrowser;if($edge){Start-Process -FilePath $edge -ArgumentList @('--inprivate','https://microsoft.com/devicelogin')|Out-Null}else{Start-Process 'https://microsoft.com/devicelogin'|Out-Null}
            $psi=[Diagnostics.ProcessStartInfo]::new();$psi.FileName=$pwsh.Source;$psi.Arguments='-NoLogo -NoProfile -ExecutionPolicy Bypass -File "'+$workerPath+'" -RequestPath "'+$requestPath+'" -StatusPath "'+$statusPath+'" -ResultPath "'+$resultPath+'"';$psi.UseShellExecute=$false;$psi.CreateNoWindow=$true;$psi.WindowStyle=[Diagnostics.ProcessWindowStyle]::Hidden
            $process=[Diagnostics.Process]::Start($psi);$deadline=[DateTime]::UtcNow.AddMinutes(8);$lastText='';$copiedCode=''
            while(-not$process.HasExited){
                if(Test-Path -LiteralPath $statusPath){$current=[string](Get-Content -LiteralPath $statusPath -Raw -Encoding UTF8 -ErrorAction SilentlyContinue);if($current-ne$lastText){$lastText=$current;$codeMatch=[regex]::Match($current,'(?i)(?:code|kode)\s+([A-Z0-9]{4}-?[A-Z0-9]{4,5})');if($codeMatch.Success-and$copiedCode-ne$codeMatch.Groups[1].Value){$copiedCode=$codeMatch.Groups[1].Value;try{[Windows.Forms.Clipboard]::SetText($copiedCode)}catch{}};$prefix=if($copiedCode){"SIGN-IN CODE: $copiedCode  (copied to clipboard)"+$nl+"Paste it in Edge InPrivate, then sign in as $($login.Text.Trim())."+$nl+$nl}else{"Waiting for Microsoft to issue the sign-in code..."+$nl+$nl};$status.Text=$prefix+$current;$status.SelectionStart=$status.TextLength;$status.ScrollToCaret()}}
                if([DateTime]::UtcNow-ge$deadline){try{$process.Kill()}catch{};throw 'Microsoft sign-in timed out after eight minutes. No forwarding change was made.'}
                [Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 150
            }
            if(-not(Test-Path -LiteralPath $resultPath)){throw "The Exchange helper ended without a result (exit code $($process.ExitCode)). No forwarding change was confirmed."}
            return Get-Content -LiteralPath $resultPath -Raw -Encoding UTF8|ConvertFrom-Json
        }finally{
            if($process){$process.Dispose()}
            foreach($temporaryPath in @($requestPath,$statusPath,$resultPath)){if(Test-Path -LiteralPath $temporaryPath){try{[IO.File]::Delete($temporaryPath)}catch{}}}
            if(Test-Path -LiteralPath $jobFolder){try{[IO.Directory]::Delete($jobFolder,$false)}catch{}}
            &$busy $false ''
        }
    }
    $check.Add_Click({try{if(-not(&$isEmail $mailbox.Text.Trim())){throw 'Enter a valid source mailbox address.'};$result=&$runWorker 'Check' '' $false;if(-not[bool]$result.Success){throw [string]$result.Message};$status.Text=[string]$result.Message;Write-Audit 'EXTERNAL_FORWARDING_CHECKED' "$([string]$TenantItem.name) | $($mailbox.Text.Trim())"}catch{$status.Text='Could not read forwarding settings.'+$nl+$nl+$_.Exception.Message}})
    $apply.Add_Click({
        try{$source=$mailbox.Text.Trim();$destination=$target.Text.Trim();if(-not(&$isEmail $source)-or-not(&$isEmail $destination)){throw 'Enter valid source and destination email addresses.'};if($source-eq$destination){throw 'The source and destination must be different.'};if(-not$authorized.Checked){throw 'Confirm customer authorization before enabling forwarding.'}
            $message='Apply external mailbox forwarding?'+$nl+$nl+"Customer: $([string]$TenantItem.name)"+$nl+"Source: $source"+$nl+"Destination: $destination"+$nl+"Keep local copy: $([bool]$keep.Checked)"+$nl+$nl+'The mailbox and destination domain are validated before the change. The outbound spam policy is not changed.'
            if([Windows.Forms.MessageBox]::Show($message,'Confirm external forwarding','YesNo','Warning')-ne'Yes'){$status.Text='No changes were made.';return}
            $result=&$runWorker 'Apply' $destination ([bool]$keep.Checked);if(-not[bool]$result.Success){throw [string]$result.Message};$status.Text=[string]$result.Message;Write-Audit 'EXTERNAL_FORWARDING_ENABLED' "$([string]$TenantItem.name) | $source -> $destination | keepCopy=$([bool]$keep.Checked)"
        }catch{$status.Text='Forwarding was not changed.'+$nl+$nl+$_.Exception.Message;try{Write-Audit 'EXTERNAL_FORWARDING_ENABLE_FAILED' ([string]$TenantItem.name)}catch{}}
    })
    $disable.Add_Click({
        try{$source=$mailbox.Text.Trim();if(-not(&$isEmail $source)){throw 'Enter a valid source mailbox address.'};$message="Disable external forwarding for $source in $([string]$TenantItem.name)?"+$nl+$nl+'Internal forwarding, if present, is left unchanged.';if([Windows.Forms.MessageBox]::Show($message,'Confirm disable','YesNo','Warning')-ne'Yes'){return};$result=&$runWorker 'Disable' '' $false;if(-not[bool]$result.Success){throw [string]$result.Message};$status.Text=[string]$result.Message;Write-Audit 'EXTERNAL_FORWARDING_DISABLED' "$([string]$TenantItem.name) | $source"}catch{$status.Text='Forwarding was not changed.'+$nl+$nl+$_.Exception.Message;try{Write-Audit 'EXTERNAL_FORWARDING_DISABLE_FAILED' ([string]$TenantItem.name)}catch{}}
    })
    $policy.Add_Click({Open-SelectedSessionPortal 'Microsoft Defender'});$close.Add_Click({$dialog.Close()})
    $dialog.Controls.AddRange(@($identity,$auth,$login,$mailbox,$target,$keep,$authorized,$warning,$status,$check,$apply,$disable,$policy,$close));$dialog.CancelButton=$close;Set-PeakNetModernForm $dialog;[void]$dialog.ShowDialog();$dialog.Dispose()
}
function Show-PolicyDialog {
    $dialog=New-Object System.Windows.Forms.Form;$dialog.Text='PeakNet | Session and idle policy';$dialog.Width=570;$dialog.Height=390;$dialog.StartPosition='CenterParent';$dialog.FormBorderStyle='FixedDialog';$dialog.MaximizeBox=$false;$dialog.MinimizeBox=$false;$dialog.BackColor=[Drawing.ColorTranslator]::FromHtml('#F5F3EF')
    $labels=@('Pause tracking after idle minutes','Warn after session hours','Automatically close after hours');$tops=@(42,96,150)
    for($i=0;$i-lt$labels.Count;$i++){$label=New-Object System.Windows.Forms.Label;$label.Text=$labels[$i];$label.Left=24;$label.Top=$tops[$i];$label.Width=250;$dialog.Controls.Add($label)}
    $idle=New-Object System.Windows.Forms.NumericUpDown;$idle.Left=300;$idle.Top=38;$idle.Width=100;$idle.Minimum=1;$idle.Maximum=120;$idle.Value=[decimal]$script:AppSettings.idleMinutes
    $warn=New-Object System.Windows.Forms.NumericUpDown;$warn.Left=300;$warn.Top=92;$warn.Width=100;$warn.Minimum=1;$warn.Maximum=24;$warn.DecimalPlaces=1;$warn.Increment=.5;$warn.Value=[decimal]$script:AppSettings.warningHours
    $auto=New-Object System.Windows.Forms.NumericUpDown;$auto.Left=300;$auto.Top=146;$auto.Width=100;$auto.Minimum=1;$auto.Maximum=48;$auto.DecimalPlaces=1;$auto.Increment=.5;$auto.Value=[decimal]$script:AppSettings.autoCloseHours
    $enable=New-Object System.Windows.Forms.CheckBox;$enable.Text='Enable automatic closing of overdue tenant sessions';$enable.Left=24;$enable.Top=205;$enable.Width=390;$enable.Checked=[bool]$script:AppSettings.autoCloseEnabled
    $tray=New-Object System.Windows.Forms.CheckBox;$tray.Text='Minimize the launcher to the notification area';$tray.Left=24;$tray.Top=240;$tray.Width=390;$tray.Checked=[bool]$script:AppSettings.minimizeToTray
    $note=New-Object System.Windows.Forms.Label;$note.Text='Idle detection uses Windows computer activity only. No keys, screen contents, browser activity, or passwords are recorded.';$note.Left=24;$note.Top=275;$note.Width=500;$note.Height=38;$note.ForeColor=[Drawing.ColorTranslator]::FromHtml('#526267')
    $save=New-Object System.Windows.Forms.Button;$save.Text='Save policy';$save.Left=420;$save.Top=315;$save.Width=105;$save.Height=32;$cancel=New-Object System.Windows.Forms.Button;$cancel.Text='Cancel';$cancel.Left=325;$cancel.Top=315;$cancel.Width=85;$cancel.Height=32;$cancel.DialogResult='Cancel'
    $save.Add_Click({Save-AppSettings ([pscustomobject]@{idleMinutes=[int]$idle.Value;warningHours=[double]$warn.Value;autoCloseEnabled=[bool]$enable.Checked;autoCloseHours=[double]$auto.Value;minimizeToTray=[bool]$tray.Checked});$dialog.DialogResult='OK';$dialog.Close()})
    $dialog.Controls.AddRange(@($idle,$warn,$auto,$enable,$tray,$note,$save,$cancel));$dialog.CancelButton=$cancel;Set-PeakNetModernForm $dialog;[void]$dialog.ShowDialog();$dialog.Dispose()
}

function Show-IntegrityDialog {
    $integrity=Get-IntegrityStatus
    try {
        $window.Cursor=[Windows.Input.Cursors]::Wait;$update=Get-SignedOnlineUpdate
        $installed=Get-InstalledAppVersion;$available=[version]([string]$update.Feed.version)
    } catch {
        [System.Windows.MessageBox]::Show("Local version: $($integrity.Version)`nLocal integrity: $($integrity.Label)`n`nThe online update service could not be reached or verified:`n$($_.Exception.Message)`n`nNo files were changed.",'Update check','OK','Warning')|Out-Null;return
    } finally { $window.Cursor=[Windows.Input.Cursors]::Arrow }
    if ($available -le $installed) {
        [System.Windows.MessageBox]::Show("PeakNet Tenant Access is up to date.`n`nInstalled: $installed`nChannel: $([string]$update.Feed.channel)`nPublisher: $($update.Publisher)`nSignature: verified`nLocal integrity: $($integrity.Label)",'No update available','OK','Information')|Out-Null;return
    }
    $notes=[string]$update.Feed.releaseNotes;if($notes.Length -gt 1200){$notes=$notes.Substring(0,1200)+'...'}
    $message="A signed PeakNet update is available.`n`nInstalled: $installed`nAvailable: $available`nChannel: $([string]$update.Feed.channel)`nPublisher signature: verified`n`nRelease notes:`n$notes`n`nThe app will back up the current version, install the update, and restart. Tenant data is not included or changed. Install now?"
    if ([System.Windows.MessageBox]::Show($message,'PeakNet update available','YesNo','Question') -eq 'Yes') {
        try { Start-PeakNetOnlineUpdate $update } catch { [System.Windows.MessageBox]::Show("The update could not be started.`n`n$($_.Exception.Message)`n`nNo installed files were changed.",'Update failed','OK','Error')|Out-Null }
    }
}
$window.FindName('AddButton').Add_Click({
    $newTenant = Show-TenantDialog $null
    if ($newTenant) { $all=@(Load-Tenants)+$newTenant; Save-Tenants $all; Refresh-Grid; Write-Audit 'TENANT_ADDED' $newTenant.name }
})

$window.FindName('EditButton').Add_Click({
    $selected=$grid.SelectedItem; if (-not $selected) { return }
    if ($sessions.ContainsKey([string]$selected.tenant)) { [System.Windows.MessageBox]::Show('End the active session before editing this tenant.','Session active') | Out-Null; return }
    $edited=Show-TenantDialog $selected; if (-not $edited) { return }
    $all=@(Load-Tenants); for($i=0;$i -lt $all.Count;$i++){ if($all[$i].tenant -eq $selected.tenant){$all[$i]=$edited;break} }
    Save-Tenants $all; Refresh-Grid; Write-Audit 'TENANT_EDITED' $edited.name
})

$window.FindName('RemoveButton').Add_Click({
    $selected=$grid.SelectedItem; if (-not $selected) { return }
    if ($sessions.ContainsKey([string]$selected.tenant)) { [System.Windows.MessageBox]::Show('End the active session before removing this tenant.','Session active') | Out-Null; return }
    if ([System.Windows.MessageBox]::Show("Remove $($selected.name) from the launcher?",'Confirm','YesNo','Question') -ne 'Yes') { return }
    $all=@(Load-Tenants | Where-Object { $_.tenant -ne $selected.tenant }); Register-TenantDeletion ([string]$selected.tenant); Save-Tenants $all; Refresh-Grid; Write-Audit 'TENANT_REMOVED' $selected.name
})

$window.FindName('FavoriteButton').Add_Click({
    $selected=$grid.SelectedItem;if(-not $selected){return};$key=[string]$selected.tenant;$all=@(Load-Tenants)
    foreach($item in $all){if([string]$item.tenant -eq $key){[void](Ensure-TenantFields $item);$item.favorite=-not [bool]$item.favorite;Touch-Tenant $item;break}}
    Save-Tenants $all;Refresh-Grid;Write-Audit 'TENANT_FAVORITE_TOGGLED' ([string]$selected.name)
})

$window.FindName('MspButton').Add_Click({
    if($script:MspConnection){
        if([System.Windows.MessageBox]::Show("Disconnect $([string]$script:MspConnection.UserPrincipalName)?`n`nThe local tenant catalog and time records will remain.",'Disconnect MSP account','YesNo','Question')-ne'Yes'){return}
        try{$script:MspConnection.AccessToken='';$script:MspConnection.RefreshToken=''}catch{};$script:MspConnection=$null;Write-Audit 'MSP_ACCOUNT_DISCONNECTED' 'PeakNet MSP';Update-Dashboard;return
    }
    $config=Load-MspConfig
    if($config){$choice=[System.Windows.MessageBox]::Show("Connect using the configured PeakNet app?`n`nPartner tenant: $([string]$config.partnerTenantId)`nLast account: $([string]$config.lastAccount)`n`nYes = connect`nNo = change configuration",'Connect MSP account','YesNoCancel','Question');if($choice-eq'Cancel'){return};if($choice-eq'No'){$config=Show-MspSetupDialog;if(-not$config){return};Save-MspConfig $config}}
    else{$config=Show-MspSetupDialog;if(-not$config){return};Save-MspConfig $config}
    try{[void](Invoke-MspInteractiveLogin $config);Update-Dashboard;$syncResult=Sync-GdapCustomers;[System.Windows.MessageBox]::Show("Connected as $([string]$script:MspConnection.UserPrincipalName).`n`nGDAP customers found: $($syncResult.Customers)`nNew tenants: $($syncResult.Added)`nUpdated tenants: $($syncResult.Updated)",'MSP connection ready','OK','Information')|Out-Null}catch{try{Write-Audit 'MSP_CONNECTION_FAILED' 'PeakNet MSP'}catch{};[System.Windows.MessageBox]::Show("The MSP connection could not be completed.`n`n$($_.Exception.Message)`n`nCheck the app registration, redirect URI, delegated permissions, and administrator consent.",'MSP connection failed','OK','Error')|Out-Null;Update-Dashboard}
})

$window.FindName('SyncMspButton').Add_Click({
    if(-not$script:MspConnection){[System.Windows.MessageBox]::Show('Connect the PeakNet MSP account before synchronizing GDAP customers.','MSP account disconnected','OK','Information')|Out-Null;return}
    try{$syncResult=Sync-GdapCustomers;[System.Windows.MessageBox]::Show("Synchronization complete.`n`nGDAP customers: $($syncResult.Customers)`nNew tenants: $($syncResult.Added)`nUpdated tenants: $($syncResult.Updated)",'GDAP synchronization','OK','Information')|Out-Null}catch{[System.Windows.MessageBox]::Show("Could not synchronize GDAP customers.`n`n$($_.Exception.Message)",'Synchronization failed','OK','Error')|Out-Null}
})

$window.FindName('LogoButton').Add_Click({ Update-SelectedTenantLogo $grid.SelectedItem })
$window.FindName('CatalogButton').Add_Click({ Show-CatalogTools })
$window.FindName('SecurityButton').Add_Click({ Show-SecurityReport })
$window.FindName('IntegrityButton').Add_Click({ Show-IntegrityDialog })
$window.FindName('DashboardButton').Add_Click({ Show-OperationsDashboard })
$window.FindName('PolicyButton').Add_Click({ Show-PolicyDialog })
$window.FindName('ForwardingButton').Add_Click({
    $selected=$grid.SelectedItem
    if(-not$selected){[Windows.MessageBox]::Show('Select a customer first.','External email forwarding','OK','Information')|Out-Null;return}
    Show-ExternalForwardingDialog $selected
})
$window.FindName('BrandingButton').Add_Click({
    $studioPath = Join-Path $PSScriptRoot 'Branding-Studio.ps1'
    if (-not (Test-Path -LiteralPath $studioPath)) {
        [System.Windows.MessageBox]::Show('Branding-Studio.ps1 is missing from the application folder.','Branding Studio','OK','Error') | Out-Null
        return
    }
    $selectedTenant = $grid.SelectedItem
    $customerName = if ($selectedTenant) { [string]$selectedTenant.name } else { '' }
    $customerTenantId = if ($selectedTenant) { [string]$selectedTenant.tenant } else { '' }
    $hostExecutable = try { (Get-Process -Id $PID -ErrorAction Stop).Path } catch { 'powershell.exe' }
    $escapedStudio = $studioPath.Replace('"','\"')
    $escapedCustomer = $customerName.Replace('"','\"')
    $escapedTenantId = $customerTenantId.Replace('"','\"')
    $escapedClients = $ClientsRoot.Replace('"','\"')
    $startInfo = [Diagnostics.ProcessStartInfo]::new()
    $startInfo.FileName = $hostExecutable
    $startInfo.Arguments = "-NoProfile -STA -ExecutionPolicy Bypass -File `"$escapedStudio`" -CustomerName `"$escapedCustomer`" -TenantId `"$escapedTenantId`" -ClientsRoot `"$escapedClients`""
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
    [void][Diagnostics.Process]::Start($startInfo)
})
$grid.Add_SelectionChanged({ Update-Dashboard })
$activeSessionList.Add_SelectionChanged({
    $activeItem = $activeSessionList.SelectedItem
    if (-not $activeItem) { return }
    $tenantKey = [string]$activeItem.tenant
    $matchingRow = $tenants | Where-Object { [string]$_.tenant -eq $tenantKey } | Select-Object -First 1
    if (-not $matchingRow) {
        $searchBox.Text = ''
        Refresh-Grid
        $matchingRow = $tenants | Where-Object { [string]$_.tenant -eq $tenantKey } | Select-Object -First 1
    }
    if ($matchingRow) { $grid.SelectedItem = $matchingRow; $grid.ScrollIntoView($matchingRow) }
})
$window.FindName('LaunchWorkspaceButton').Add_Click({
    $window.FindName('LaunchButton').RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Button]::ClickEvent))
})
$window.FindName('WorkspaceCloseAllButton').Add_Click({
    $window.FindName('CloseAllButton').RaiseEvent([Windows.RoutedEventArgs]::new([Windows.Controls.Button]::ClickEvent))
})

$window.FindName('TimeButton').Add_Click({
    $report = New-Object System.Windows.Forms.Form
    $report.Text = 'PeakNet | Work log and time report'
    $report.Width = 1240; $report.Height = 760; $report.StartPosition = 'CenterScreen'
    $report.BackColor = [Drawing.ColorTranslator]::FromHtml('#F5F3EF')
    $reportHeading=New-Object System.Windows.Forms.Label;$reportHeading.Text='Work log and time reports';$reportHeading.Left=24;$reportHeading.Top=17;$reportHeading.Width=500;$reportHeading.Height=28;$reportHeading.Font=[Drawing.Font]::new('Segoe UI Semibold',16)
    $reportSubheading=New-Object System.Windows.Forms.Label;$reportSubheading.Text='Review customer totals, month-by-month usage, and individual work entries.';$reportSubheading.Left=25;$reportSubheading.Top=46;$reportSubheading.Width=760;$reportSubheading.Height=20;$reportSubheading.ForeColor=[Drawing.ColorTranslator]::FromHtml('#60706D')
    $tabs=New-Object System.Windows.Forms.TabControl;$tabs.Left=24;$tabs.Top=78;$tabs.Width=1176;$tabs.Height=575
    $summaryTab=New-Object System.Windows.Forms.TabPage;$summaryTab.Text='Customer totals';$monthlyTab=New-Object System.Windows.Forms.TabPage;$monthlyTab.Text='Monthly by tenant';$detailTab=New-Object System.Windows.Forms.TabPage;$detailTab.Text='Detailed entries'
    $summaryGrid=New-Object System.Windows.Forms.DataGridView;$summaryGrid.Dock='Fill';$summaryGrid.ReadOnly=$true;$summaryGrid.AllowUserToAddRows=$false;$summaryGrid.AutoSizeColumnsMode='Fill';$summaryGrid.SelectionMode='FullRowSelect'
    $monthlyGrid=New-Object System.Windows.Forms.DataGridView;$monthlyGrid.Dock='Fill';$monthlyGrid.ReadOnly=$true;$monthlyGrid.AllowUserToAddRows=$false;$monthlyGrid.AutoSizeColumnsMode='Fill';$monthlyGrid.SelectionMode='FullRowSelect'
    $detailGrid=New-Object System.Windows.Forms.DataGridView;$detailGrid.Dock='Fill';$detailGrid.ReadOnly=$true;$detailGrid.AllowUserToAddRows=$false;$detailGrid.AutoSizeColumnsMode='Fill';$detailGrid.SelectionMode='FullRowSelect'
    Set-GridData $summaryGrid @(Get-TimeReportRows);Set-GridData $monthlyGrid @(Get-MonthlyTimeReportRows);Set-GridData $detailGrid @(Get-TimeDetailRows);$summaryTab.Controls.Add($summaryGrid);$monthlyTab.Controls.Add($monthlyGrid);$detailTab.Controls.Add($detailGrid);$tabs.TabPages.AddRange(@($summaryTab,$monthlyTab,$detailTab))
    $openFolder = New-Object System.Windows.Forms.Button
    $openFolder.Text='Open tracking folder'; $openFolder.Left=24; $openFolder.Top=674; $openFolder.Width=150; $openFolder.Height=38
    $openFolder.Add_Click({ Start-Process explorer.exe -ArgumentList ('"' + $TimeTrackingRoot + '"') })
    $adjust=New-Object System.Windows.Forms.Button;$adjust.Text='Add adjustment';$adjust.Left=184;$adjust.Top=674;$adjust.Width=130;$adjust.Height=38
    $adjust.Add_Click({if(Add-ManualTimeAdjustment){Set-GridData $summaryGrid @(Get-TimeReportRows);Set-GridData $monthlyGrid @(Get-MonthlyTimeReportRows);Set-GridData $detailGrid @(Get-TimeDetailRows)}})
    $export=New-Object System.Windows.Forms.Button;$export.Text='Export CSV';$export.Left=324;$export.Top=674;$export.Width=110;$export.Height=38;$export.Add_Click({Export-TimeCsv})
    $exportMonthly=New-Object System.Windows.Forms.Button;$exportMonthly.Text='Export monthly CSV';$exportMonthly.Left=444;$export.Top=674;$exportMonthly.Width=150;$exportMonthly.Height=38;$exportMonthly.Add_Click({Export-MonthlyTimeCsv})
    $chartButton=New-Object System.Windows.Forms.Button;$chartButton.Text='Monthly chart';$chartButton.Left=604;$chartButton.Top=674;$chartButton.Width=125;$chartButton.Height=38;$chartButton.Add_Click({Show-MonthlyChart})
    $closeReport = New-Object System.Windows.Forms.Button
    $closeReport.Text='Close'; $closeReport.Left=1100; $closeReport.Top=674; $closeReport.Width=100; $closeReport.Height=38
    $closeReport.Add_Click({ $report.Close() })
    $report.Controls.AddRange(@($reportHeading,$reportSubheading,$tabs,$openFolder,$adjust,$export,$exportMonthly,$chartButton,$closeReport))
    Set-PeakNetModernForm $report
    [void]$report.ShowDialog()
    $report.Dispose()
})

$window.FindName('SetupButton').Add_Click({
    if (@(Get-TemplateEdgeProcesses).Count -gt 0) {
        [System.Windows.MessageBox]::Show('Close the current 1Password template Edge window before starting setup again.', 'Template profile in use', 'OK', 'Information') | Out-Null
        return
    }
    $browser=Find-EdgeBrowser
    if (-not $browser) { [System.Windows.MessageBox]::Show('Microsoft Edge was not found.','PeakNet Tenant Access','OK','Error') | Out-Null; return }
    [System.Windows.MessageBox]::Show("The Edge template window will open.`n`n1. Install the 1Password extension from the page that opens.`n2. Open edge://extensions in that same window.`n3. Select Details under 1Password.`n4. Enable Allow in InPrivate.`n5. Close the template window when finished.`n`nNew customer sessions will receive isolated copies of this template.", 'One-time 1Password setup', 'OK', 'Information') | Out-Null
    $extensionUrl = 'https://microsoftedge.microsoft.com/addons/detail/dppgmdbiimibapkepcbdbmkaabgiofem'
    $setupArgs=@("--user-data-dir=`"$EdgeTemplateRoot`"",'--no-first-run','--no-default-browser-check','--disable-sync','--disable-background-mode','--new-window',$extensionUrl)
    Start-Process -FilePath $browser.Path -ArgumentList $setupArgs | Out-Null
    Write-Audit 'ONEPASSWORD_TEMPLATE_SETUP_OPENED' 'Edge template profile'
})

function Open-SelectedSessionPortal([string]$PortalName) {
    $selected=$grid.SelectedItem;if(-not $selected){[System.Windows.MessageBox]::Show('Select an active customer first.','Open portal')|Out-Null;return};$key=[string]$selected.tenant
    if(-not $sessions.ContainsKey($key) -or @(Get-SessionBrowserProcesses $sessions[$key]).Count -eq 0){[System.Windows.MessageBox]::Show('Open a secure session for this customer before opening another portal.','No active session')|Out-Null;return}
    $browser=Find-EdgeBrowser;if(-not $browser){return};$session=$sessions[$key];$url=Get-PortalUrl $selected $PortalName
    $args=@("--user-data-dir=`"$($session.Profile)`"",'--inprivate','--no-first-run','--no-default-browser-check','--disable-sync','--disable-background-mode','--new-window',$url)
    Start-Process -FilePath $browser.Path -ArgumentList $args|Out-Null;Write-Audit ('PORTAL_OPENED_'+($PortalName -replace '[^A-Za-z0-9]','_').ToUpperInvariant()) ([string]$selected.name)
}
$window.FindName('PortalButton').Add_Click({ Open-SelectedSessionPortal 'Microsoft 365 admin center' })
$window.FindName('EntraPortalButton').Add_Click({ Open-SelectedSessionPortal 'Microsoft Entra' })
$window.FindName('IntunePortalButton').Add_Click({ Open-SelectedSessionPortal 'Microsoft Intune' })
$window.FindName('SecurityPortalButton').Add_Click({ Open-SelectedSessionPortal 'Microsoft Defender' })

$window.FindName('LaunchButton').Add_Click({
    $selected=$grid.SelectedItem; if (-not $selected) { [System.Windows.MessageBox]::Show('Select a tenant first.','MSP Tenant Launcher') | Out-Null; return }
    $key=[string]$selected.tenant
    if([string]$selected.source -like 'Microsoft Graph*' -and [string]$selected.gdapStatus -notmatch '^(?i)active$'){
        if([System.Windows.MessageBox]::Show("The synchronized GDAP relationship is not marked active.`n`nCustomer: $([string]$selected.name)`nStatus: $([string]$selected.gdapStatus)`n`nContinue only if you have confirmed access through another approved relationship.",'GDAP access warning','YesNo','Warning')-ne'Yes'){return}
    }
    if ($sessions.ContainsKey($key) -and @(Get-SessionBrowserProcesses $sessions[$key]).Count -gt 0) {
        [System.Windows.MessageBox]::Show('This customer already has an active session.', 'Session active', 'OK', 'Information') | Out-Null
        return
    }
    if ($sessions.ContainsKey($key)) {
        $previousSession = $sessions[$key]
        Complete-TimeEntry $previousSession 'Browser closed'
        Stop-SessionBrowserProcesses $previousSession
        Remove-SessionProfile $previousSession.Profile | Out-Null
        $sessions.Remove($key)
    }
    if (@(Get-TemplateEdgeProcesses).Count -gt 0) {
        [System.Windows.MessageBox]::Show('Close the 1Password template setup window before opening a customer session.', 'Finish template setup', 'OK', 'Information') | Out-Null
        return
    }
    $browser=Find-EdgeBrowser; if (-not $browser) { [System.Windows.MessageBox]::Show('Microsoft Edge was not found.','PeakNet Tenant Access','OK','Error') | Out-Null; return }
    if (-not (Test-OnePasswordTemplate)) {
        if ([System.Windows.MessageBox]::Show("1Password is not installed in the Edge template yet.`n`nOpen the customer session anyway?", '1Password setup incomplete', 'YesNo', 'Warning') -ne 'Yes') { return }
    }
    $workDetails=Show-WorkDetailsDialog $selected;if(-not $workDetails){return}
    $sessionId=[guid]::NewGuid().ToString('N')
    $profile=Join-Path $SessionRoot $sessionId
    try {
        New-SessionProfileFromTemplate $profile
    } catch {
        if (Test-Path -LiteralPath $profile) { Remove-SessionProfile $profile | Out-Null }
        [System.Windows.MessageBox]::Show("Could not create the isolated Edge session.`n`n$($_.Exception.Message)", 'Session creation failed', 'OK', 'Error') | Out-Null
        return
    }
    $startupUrls=@(
        (Get-PortalUrl $selected 'Microsoft 365 admin center'),
        (Get-PortalUrl $selected 'Microsoft Entra'),
        (Get-PortalUrl $selected 'Microsoft Intune'),
        (Get-PortalUrl $selected 'Microsoft Defender')
    )
    $diskCache = Join-Path $profile 'SessionCache\DiskCache'
    $mediaCache = Join-Path $profile 'SessionCache\MediaCache'
    $args=@("--user-data-dir=`"$profile`"","--disk-cache-dir=`"$diskCache`"","--media-cache-dir=`"$mediaCache`"",'--inprivate','--no-first-run','--no-default-browser-check','--disable-sync','--disable-background-mode','--new-window') + $startupUrls
    $process=Start-Process -FilePath $browser.Path -ArgumentList $args -PassThru
    $sessions[$key]=[pscustomobject]@{
        Id=$sessionId; Process=$process; Profile=$profile; Name=[string]$selected.name
        Tenant=$key; Admin=[string]$selected.username; StartedUtc=[DateTime]::UtcNow; TimeSaved=$false
        Ticket=[string]$workDetails.Ticket; WorkNotes=[string]$workDetails.WorkNotes; Billable=[bool]$workDetails.Billable
        Role=[string]$selected.role; Color=[string]$selected.color; WarnedLongSession=$false
        ExcludeIdle=[bool]$workDetails.ExcludeIdle; IdleSeconds=[double]0; LastTimerUtc=[DateTime]::UtcNow
    }
    Save-RecoveryState
    Set-TenantLastUsed $key
    Refresh-Grid
    $grid.SelectedItem = $tenants | Where-Object { [string]$_.tenant -eq $key } | Select-Object -First 1
    Write-Audit "SESSION_OPENED_$($browser.Name.ToUpper().Replace(' ','_'))" $selected.name
    Write-Audit 'SESSION_STARTUP_TABS_OPENED_ADMIN_ENTRA_INTUNE_SECURITY' $selected.name
})

$window.FindName('EndButton').Add_Click({
    $selected=$grid.SelectedItem; if (-not $selected) { return }; $key=[string]$selected.tenant
    if (-not $sessions.ContainsKey($key)) { return }
    $s=$sessions[$key]
    Complete-TimeEntry $s 'Closed from launcher'
    Stop-SessionBrowserProcesses $s
    $erased = Remove-SessionProfile $s.Profile
    $sessions.Remove($key); Save-RecoveryState; Refresh-Grid
    if ($erased) {
        Write-Audit 'ISOLATED_SESSION_ENDED_AND_ERASED' $selected.name
    } else {
        Write-Audit 'ISOLATED_SESSION_CLEANUP_PENDING' $selected.name
        [System.Windows.MessageBox]::Show("Edge was closed, but Windows still has a lock on part of the isolated profile.`n`nThe launcher will retry cleanup the next time it starts.", 'Cleanup pending', 'OK', 'Warning') | Out-Null
    }
})

$window.FindName('CloseAllButton').Add_Click({
    $sessionCount = $sessions.Count
    if ($sessionCount -eq 0) {
        [System.Windows.MessageBox]::Show('There are no active tenant sessions to close.', 'Close all sessions', 'OK', 'Information') | Out-Null
        return
    }
    $pluralSuffix = if ($sessionCount -ne 1) { 's' } else { '' }
    $confirmation = "Close all $sessionCount active tenant session${pluralSuffix}?`n`nEvery launcher-managed Edge process will be stopped and each isolated session profile will be erased. The persistent 1Password template will remain."
    if ([System.Windows.MessageBox]::Show($confirmation, 'Close all sessions', 'YesNo', 'Warning') -ne 'Yes') { return }

    $cleanupPending = [Collections.Generic.List[string]]::new()
    foreach ($sessionKey in @($sessions.Keys)) {
        $session = $sessions[$sessionKey]
        try { Complete-TimeEntry $session 'Closed all from launcher' | Out-Null } catch {}
        try { Stop-SessionBrowserProcesses $session } catch {}
        $erased = $false
        try { $erased = Remove-SessionProfile $session.Profile } catch {}
        [void]$sessions.Remove($sessionKey)
        if ($erased) {
            try { Write-Audit 'ISOLATED_SESSION_ENDED_BY_CLOSE_ALL_AND_ERASED' $session.Name } catch {}
        } else {
            $cleanupPending.Add([string]$session.Name)
            try { Write-Audit 'ISOLATED_SESSION_CLOSE_ALL_CLEANUP_PENDING' $session.Name } catch {}
        }
    }
    Save-RecoveryState
    Refresh-Grid
    if ($cleanupPending.Count -gt 0) {
        [System.Windows.MessageBox]::Show("All Edge sessions were closed, but Windows still has a lock on $($cleanupPending.Count) isolated profile(s).`n`nThe launcher will retry erasing them the next time it starts.", 'Cleanup pending', 'OK', 'Warning') | Out-Null
    }
})

$window.Add_Closed({
    try { $trackingTimer.Stop() } catch {}
    try { $searchTimer.Stop() } catch {}
    try { if ($script:TaskbarLargeIcon) { $script:TaskbarLargeIcon.Dispose() } } catch {}
    try { if ($script:TaskbarSmallIcon) { $script:TaskbarSmallIcon.Dispose() } } catch {}
    foreach($s in @($sessions.Values)) {
        try { Complete-TimeEntry $s 'Launcher closed' } catch {}
        try { Stop-SessionBrowserProcesses $s } catch {}
        try {
            if (Remove-SessionProfile $s.Profile) { Write-Audit 'ISOLATED_SESSION_ENDED_APP_EXIT_AND_ERASED' $s.Name }
            else { Write-Audit 'ISOLATED_SESSION_ENDED_APP_EXIT_CLEANUP_PENDING' $s.Name }
        } catch { Write-Audit 'SESSION_CLEANUP_FAILED' $s.Name }
    }
    Remove-Item -LiteralPath $RecoveryPath -Force -ErrorAction SilentlyContinue
    try{$script:MspConnection.AccessToken='';$script:MspConnection.RefreshToken=''}catch{};$script:MspConnection=$null
    try { $LauncherMutex.ReleaseMutex() } catch {}
    try { $LauncherMutex.Dispose() } catch {}
})

$searchTimer = [Windows.Threading.DispatcherTimer]::new()
$searchTimer.Interval = [TimeSpan]::FromMilliseconds(250)
$searchTimer.Add_Tick({
    $searchTimer.Stop()
    Refresh-Grid
})
$searchBox.Add_TextChanged({
    $searchTimer.Stop()
    $searchTimer.Start()
})
Recover-InterruptedSessions
Remove-StaleSessionProfiles
Refresh-Grid
$script:trackingTimerTicks = 0
$trackingTimer = [Windows.Threading.DispatcherTimer]::new()
$trackingTimer.Interval = [TimeSpan]::FromSeconds(2)
$trackingTimer.Add_Tick({
    $script:trackingTimerTicks++
    $refreshAll = $false
    $nowUtc = [DateTime]::UtcNow
    $systemIdleSeconds = Get-SystemIdleSeconds
    foreach ($activeSession in @($sessions.Values)) {
        $lastTick = if ($activeSession.PSObject.Properties.Name -contains 'LastTimerUtc') { [DateTime]$activeSession.LastTimerUtc } else { $nowUtc }
        $tickSeconds = [Math]::Max(0,[Math]::Min(10,($nowUtc-$lastTick).TotalSeconds))
        if ([bool]$activeSession.ExcludeIdle -and $systemIdleSeconds -ge ([double]$script:AppSettings.idleMinutes*60)) { $activeSession.IdleSeconds += $tickSeconds }
        $activeSession.LastTimerUtc = $nowUtc
    }
    if (($script:trackingTimerTicks % 5) -eq 0) {
        $edgeRows = @(Get-EdgeProcessRows)
        foreach ($sessionKey in @($sessions.Keys)) {
            $session = $sessions[$sessionKey]
            if (@(Get-SessionBrowserProcesses -Session $session -EdgeRows $edgeRows).Count -eq 0) {
                try { Complete-TimeEntry $session 'Browser closed' } catch {}
                try { Remove-SessionProfile $session.Profile | Out-Null } catch {}
                $sessions.Remove($sessionKey)
                Write-Audit 'SESSION_BROWSER_CLOSED_TIME_SAVED' $session.Name
                $refreshAll = $true
            }
        }
    }
    if (($script:trackingTimerTicks % 30) -eq 0) {
        $longSessions=[Collections.Generic.List[string]]::new()
        $autoClosed=[Collections.Generic.List[string]]::new()
        foreach($sessionKey in @($sessions.Keys)){
            $activeSession=$sessions[$sessionKey];$openHours=($nowUtc-$activeSession.StartedUtc).TotalHours
            if(-not [bool]$activeSession.WarnedLongSession -and $openHours -ge [double]$script:AppSettings.warningHours){$activeSession.WarnedLongSession=$true;$longSessions.Add([string]$activeSession.Name);try{Write-Audit 'LONG_SESSION_WARNING' $activeSession.Name}catch{}}
            if([bool]$script:AppSettings.autoCloseEnabled -and $openHours -ge [double]$script:AppSettings.autoCloseHours){
                try{Complete-TimeEntry $activeSession 'Automatically closed by session policy'|Out-Null}catch{};try{Stop-SessionBrowserProcesses $activeSession}catch{};try{Remove-SessionProfile $activeSession.Profile|Out-Null}catch{};[void]$sessions.Remove($sessionKey);$autoClosed.Add([string]$activeSession.Name);try{Write-Audit 'SESSION_AUTOMATICALLY_CLOSED' $activeSession.Name}catch{};$refreshAll=$true
            }
        }
        Save-RecoveryState
        if($longSessions.Count){[System.Windows.MessageBox]::Show("These tenant sessions have exceeded the $([double]$script:AppSettings.warningHours)-hour warning:`n`n$($longSessions -join "`n")`n`nClose sessions that are no longer needed.",'Long-running tenant sessions','OK','Warning')|Out-Null}
        if($autoClosed.Count){[System.Windows.MessageBox]::Show("Session policy automatically closed:`n`n$($autoClosed -join "`n")",'Sessions closed','OK','Information')|Out-Null}
    }
    if ($refreshAll) {
        Save-RecoveryState
        Refresh-Grid
    } elseif (($script:trackingTimerTicks % 30) -eq 0) {
        # Pick up catalog edits synchronized from the other computer.
        Refresh-Grid
    } elseif ($sessions.Count -gt 0) {
        foreach ($tenantRow in @($tenants)) {
            $rowKey = [string]$tenantRow.tenant
            if ($sessions.ContainsKey($rowKey)) {
                $tenantRow.elapsedDisplay = Format-Duration (Get-SessionTrackedSeconds $sessions[$rowKey] $nowUtc)
            }
        }
        $grid.Items.Refresh()
    }
})
$trackingTimer.Start()
[void]$window.ShowDialog()
