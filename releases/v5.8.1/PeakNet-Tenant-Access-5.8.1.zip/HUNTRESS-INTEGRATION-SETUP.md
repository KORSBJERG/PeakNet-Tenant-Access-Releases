# Huntress security and billing integration

PeakNet Tenant Access 5.7 adds a read-only Huntress operations and billing dashboard.

## Create the API credential

1. Sign in to the Huntress Partner Portal with an account-level administrator.
2. Open the menu in the upper-right corner and choose **API Credentials**.
3. Under **User API Credentials**, choose **Add**.
4. Select a dedicated read-only user and name the key `PeakNet Tenant Access`.
5. Copy the API Key and API Secret immediately. Huntress shows the secret only once.
6. In PeakNet Tenant Access, choose **Huntress security & billing**, open **Settings**, and save both values.

Use a user-based API key with only the read permissions needed for Organizations, Incident Reports and product usage. Old account API keys are deprecated by Huntress and may return incomplete data.

The credential is protected with Windows DPAPI for the current Windows user and is stored only on that computer. It is never written to the shared Clients folder. Repeat the credential step once on a second computer.

## Shared data and billing

Pricing, cached usage, exports and customer matches are stored below:

`Clients\_PeakNet Tenant Access\Huntress`

Enter PeakNet's monthly contract cost in EUR for EDR, ITDR, SIEM, ESPM and ISPM. The application converts it with the documented EUR/DKK rate, rounds the DKK unit cost to two decimals and sets the sales price to exactly twice that rounded cost. It then calculates monthly cost, sales and margin per customer and can export the billing table to CSV.

Organizations are matched to the local customer catalog by Microsoft tenant ID first and normalized customer name second. A Huntress organization whose name begins with `DS`, or a locally matched customer whose name begins with `DS`, is assigned to **DSData** and appears in the dedicated DSData license statement. The statement keeps EDR, ITDR, SIEM, ESPM and ISPM totals separate and shows billable versus total identities where Huntress provides both.

Huntress currently documents native organization usage for EDR, ITDR, SIEM and ISPM. ESPM / Email Security is read automatically if Huntress exposes an `espm` or `email_security` usage object. Otherwise the dashboard shows `N/A` and excludes that product from billing instead of inventing a quantity.

Synchronization is read-only. The integration does not close incidents, isolate hosts, change organizations or modify Huntress subscriptions.
